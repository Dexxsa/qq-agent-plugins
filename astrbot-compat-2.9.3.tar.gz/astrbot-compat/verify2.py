#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A 档抽检：直接跑 runner.py 验「装上能不能回话」，不写进控制台 plugins/。

为什么要绕开控制台：
  上次抽检是「真装一遍再探」，安装物会落到 plugins/ab-*，重名时会覆盖线上
  已装插件（imgbb 就被覆盖过一次）。这里让 runner 直接吃仓库目录，效果等价
  （同一个 runner、同一个 venv、同一套 shim），但不产生任何 ab-* 目录。

判定口径（和用户的标准一致：下载下来就能用）：
  ok = 启动成功 且 ready 里报出至少一条命令 且 发该命令后有非空回包
  其它情况都算 fail，并记录卡在哪一步。
"""

import json
import os
import re
import selectors
import shutil
import signal
import subprocess
import sys
import tempfile
import time

PY_DIR = '/root/DSH/qq-agent/plugins/astrbot-compat/py'
RUNNER = os.path.join(PY_DIR, 'runner.py')
VENV_PY = '/root/DSH/qq-agent/data/plugins/astrbot-compat/venv/bin/python'
PROBE_ROOT = '/root/DSH/_probe'
OUT = '/root/DSH/_probe/verify2.jsonl'

REPOS = [
    ('XziXmn/astrbot_plugin_tarot', 'astrbot_plugin_tarot'),
    ('onniemi/astrbot_plugin_qinglong', '青龙面板管理'),
    ('Heyh520/astrbot_plugin_LetAI_sendemojis', 'astrbot_plugin_LetAI_sendemojis'),
    ('warrior-dl/astrbot_plugin_cheer_mate', '陪伴夸夸机器人'),
    ('Bugelll/astrbot_plugin_unturned_servers', 'Unturned 服务器查询'),
    ('tanggetian/astrbot_plugin_MiniMax_CLI', 'MiniMax CLI'),
    ('enldm/astrbot_plugin_autobackup', 'AstrBot 自动备份插件'),
    ('iamfromchangsha/astrbot_plugin_niji', 'Niji Diary Sync'),
    ('FGXYX/astrbot_plugin_ImgBB_Subscriber', 'ImgBB助手'),
    ('Xhan258/astrbot_plugin_ha_control_layer', 'Home Assistant 控制器'),
    ('Wayzinx/httpposter', 'httpposter'),
    ('Omnisch/astrbot_plugin_image_censor', 'astrbot_plugin_image_censor'),
]

STDLIB = {
    're', 'os', 'sys', 'json', 'time', 'datetime', 'random', 'math', 'typing', 'pathlib',
    'base64', 'hashlib', 'urllib', 'subprocess', 'logging', 'collections', 'itertools',
    'functools', 'io', 'asyncio', 'threading', 'queue', 'string', 'copy', 'uuid', 'traceback',
    'inspect', 'shutil', 'tempfile', 'glob', 'csv', 'sqlite3', 'socket', 'ssl', 'http',
    'email', 'struct', 'binascii', 'unicodedata', 'secrets', 'platform', 'statistics',
    'decimal', 'fractions', 'enum', 'abc', 'dataclasses', 'contextlib', 'types', 'importlib',
}


def log(msg):
    print('[%s] %s' % (time.strftime('%H:%M:%S'), msg), flush=True)


def pip(args, timeout=240):
    py = VENV_PY if os.path.isfile(VENV_PY) else 'python3'
    try:
        r = subprocess.run([py, '-m', 'pip', *args, '--disable-pip-version-check', '-q'],
                           capture_output=True, text=True, timeout=timeout)
        return r.returncode == 0, (r.stderr or '')[-300:]
    except Exception as exc:
        return False, str(exc)[:200]


def install_requirements(repo_dir):
    path = os.path.join(repo_dir, 'requirements.txt')
    if not os.path.isfile(path):
        return 'none'
    pkgs = []
    for line in open(path, encoding='utf-8', errors='ignore'):
        line = line.split('#')[0].strip()
        if not line or line.startswith('-'):
            continue
        name = re.split(r'[<>=!\[;]', line)[0].strip()
        if name and name.lower() not in STDLIB and name not in STDLIB:
            pkgs.append(line)
    if not pkgs:
        return 'none'
    tmp = os.path.join(repo_dir, 'requirements.compat.txt')
    open(tmp, 'w', encoding='utf-8').write('\n'.join(pkgs))
    ok, err = pip(['install', '-r', tmp])
    return 'ok' if ok else ('fail:' + err.replace('\n', ' ')[:160])


class Proc:
    def __init__(self, repo_dir, data_dir):
        env = dict(os.environ, PYTHONUNBUFFERED='1', PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=PY_DIR)
        py = VENV_PY if os.path.isfile(VENV_PY) else 'python3'
        self.p = subprocess.Popen([py, RUNNER, '--dir', repo_dir, '--data', data_dir],
                                  cwd=repo_dir, env=env, stdin=subprocess.PIPE,
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                  text=True, bufsize=1, start_new_session=True)
        self.sel = selectors.DefaultSelector()
        self.sel.register(self.p.stdout, selectors.EVENT_READ)
        self.buf = ''

    def read_msg(self, timeout):
        end = time.time() + timeout
        while True:
            left = end - time.time()
            if left <= 0:
                return None
            if self.sel.select(timeout=min(left, 0.5)):
                line = self.p.stdout.readline()
                if not line:
                    return None
                line = line.strip()
                if not line:
                    continue
                try:
                    return json.loads(line)
                except Exception:
                    continue

    def send(self, obj):
        try:
            self.p.stdin.write(json.dumps(obj, ensure_ascii=False) + '\n')
            self.p.stdin.flush()
        except Exception:
            pass

    def kill(self):
        try:
            os.killpg(os.getpgid(self.p.pid), signal.SIGKILL)
        except Exception:
            try:
                self.p.kill()
            except Exception:
                pass
        try:
            self.p.wait(timeout=3)
        except Exception:
            pass


HELP_HINTS = ('menu', 'help', '帮助', '菜单', '说明', 'usage', '指令', '指南')


def pick_command(cmds):
    """挑一条「最不容易依赖外部网络/配置」的命令来试。

    原来固定取 cmds[0]，但注册顺序不代表用户第一条会发什么：
    leetcode 的 cmds[0] 是「lc今日」——要实时联网拉题，30 秒直接超时；
    而「lc菜单」纯本地拼字符串，秒回。按用户实际习惯优先试菜单/帮助类。
    """
    for c in cmds:
        low = str(c).lower()
        if any(h in low for h in HELP_HINTS):
            return c
    return cmds[0]


def run_one(slug, name):
    repo_dir = os.path.join(PROBE_ROOT, os.path.basename(slug))
    rec = {'slug': slug, 'name': name, 'ok': False, 'commands': [], 'error': '',
           'action': '', 'reply': '', 'req': '', 'sec': 0}
    t0 = time.time()
    if not os.path.isdir(repo_dir):
        rec['error'] = '仓库未克隆'
        return rec
    rec['req'] = install_requirements(repo_dir)

    data_dir = tempfile.mkdtemp(prefix='probe-')
    proc = None
    try:
        for attempt in range(4):
            proc = Proc(repo_dir, data_dir)
            ready = proc.read_msg(25)
            if ready is None:
                rec['error'] = '启动无响应或超时'
                break
            if ready.get('type') == 'fatal':
                err = str(ready.get('error') or '')
                rec['error'] = err
                # 缺包：补装一次再重试（与运行时 probePlugin 的策略一致）
                m = re.search(r"No module named '([\w.]+)'", err)
                if m and attempt < 3:
                    full = m.group(1)
                    mod = full.split('.')[0]
                    if mod.lower().startswith('astrbot'):
                        # 只在本地垫片里补，绝不从 PyPI 拉真 AstrBot
                        rec['error'] = '缺垫片模块:%s' % full
                        log('  缺垫片 %s，跳过 pip' % full)
                        break
                    ok, _ = pip(['install', mod])
                    log('  补装 %s -> %s' % (mod, ok))
                    proc.kill()
                    continue
                break
            if ready.get('type') == 'ready':
                rec['commands'] = ready.get('commands') or []
                rec['action'] = 'ready'
                rec['warnings'] = ready.get('warnings') or []
                cmds = rec['commands']
                if not cmds:
                    rec['error'] = '未注册任何命令'
                    break
                cmd = pick_command(cmds)
                proc.send({'type': 'event', 'id': 'p1', 'text': '/' + cmd,
                           'chat': {'kind': 'group', 'id': '999001'},
                           'user': {'id': '10001', 'name': '抽检'},
                           'selfId': '10000', 'messageId': 'm1', 'isAdmin': True})
                res = proc.read_msg(30)
                if res is None:
                    rec['error'] = '命令无响应（30 秒）'
                    break
                rec['matched'] = bool(res.get('matched'))
                acts = res.get('actions') or []
                text = ' '.join(
                    (a.get('text') or '') if a.get('kind') == 'text'
                    else ('[%s]' % a.get('kind')) for a in acts).strip()
                rec['reply'] = text[:200]
                rec['error'] = res.get('error') or ''
                rec['ok'] = bool(rec['matched']) and bool(acts) and len(text) > 0
                break
        return rec
    finally:
        if proc:
            proc.kill()
        shutil.rmtree(data_dir, ignore_errors=True)
        rec['sec'] = round(time.time() - t0, 1)


def main():
    only = sys.argv[1] if len(sys.argv) > 1 else ''
    results = []
    with open(OUT, 'w', encoding='utf-8') as fh:
        for slug, name in REPOS:
            if only and only not in slug:
                continue
            log('▶ %s' % name)
            rec = run_one(slug, name)
            log('  %s | cmds=%d | %s | %ss' % ('OK' if rec['ok'] else 'FAIL',
                                               len(rec['commands']),
                                               (rec['error'] or rec['reply'])[:90], rec['sec']))
            fh.write(json.dumps(rec, ensure_ascii=False) + '\n')
            fh.flush()
            results.append(rec)
            time.sleep(1)
    ok = sum(1 for r in results if r['ok'])
    log('==== 合计 %d/%d 可用（%.1f%%）====' % (ok, len(results), 100.0 * ok / max(1, len(results))))


if __name__ == '__main__':
    main()
