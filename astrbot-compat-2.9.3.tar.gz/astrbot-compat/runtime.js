// ══════════════════════════════════════════════════════════════
//  astrbot-compat · runtime —— AstrBot 插件的共享运行时
// ══════════════════════════════════════════════════════════════
//
//  设计（2026-10-22 重做）：
//    每个 AstrBot 插件 = plugins/ab-<slug>/ 下的一个**原生插件**，
//    在控制台插件页里就是一个正常条目：能启用 / 停用 / 配置 / 卸载 / 导出。
//    本文件只管两件事：把 Python 进程管起来、把命令接进 message 钩子。
//
//  为什么这里不维护"已装插件列表"：
//    列表的唯一真相是 plugins/ 目录本身（内核 loadAll 扫的就是它）。
//    以前那份 installed.json 会和目录不同步 —— 面板删了目录、列表还留着，
//    于是出现"幽灵插件"。现在只保留 astrbot.json 作元信息，随插件目录同生共死。
//
//  为什么运行时必须是单例：
//    每个 ab-* 的 index.js 都 import 同一个文件（解析到同一 URL），
//    ESM 模块缓存天然单例。否则 N 个插件会各起一套进程池、各算一份命令表。

import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { getConfig } from '../../src/config.js';

export const HERE = path.dirname(fileURLToPath(import.meta.url));
export const PY_DIR = path.join(HERE, 'py');
const RUNNER = path.join(PY_DIR, 'runner.py');

/** 运行时的私有数据根：store（插件源码）、venv（依赖）、config（配置） */
export const DATA_ROOT = path.resolve(HERE, '../../data/plugins/astrbot-compat');
export const STORE_DIR = path.join(DATA_ROOT, 'store');
export const VENV_DIR = path.join(DATA_ROOT, 'venv');
const CONFIG_DIR = path.join(DATA_ROOT, 'config');

/** 插件目录根（plugins/）——生成的原生插件都落在这里 */
export const PLUGINS_ROOT = path.resolve(HERE, '..');

const MARKET_URL = 'https://cdn.jsdelivr.net/gh/AstrBotDevs/AstrBot_Plugins_Collection@main/plugins.json';
/** 索引源按顺序回退：jsdelivr 在某些网络下整段不可达，后三个走 GitHub 代理 */
const MARKET_URLS = [
  MARKET_URL,
  'https://gh-proxy.com/https://raw.githubusercontent.com/AstrBotDevs/AstrBot_Plugins_Collection/main/plugins.json',
  'https://ghfast.top/https://raw.githubusercontent.com/AstrBotDevs/AstrBot_Plugins_Collection/main/plugins.json',
  'https://raw.githubusercontent.com/AstrBotDevs/AstrBot_Plugins_Collection/main/plugins.json'
];
const MARKET_TTL_MS = 6 * 3600 * 1000;
const REPO_RE = /^https:\/\/github\.com\/([\w.-]+)\/([\w.-]+?)(?:\.git)?\/?$/;

export const readJson = (p, dflt) => {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return dflt; }
};

export const writeJson = (p, data) => {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, JSON.stringify(data, null, 1), 'utf8');
};

/** 标准库名。作者把 `re`/`json` 写进 requirements.txt 是常见事故：
 *  pip 找不到同名包 → 整份 requirements 失败 → 后面真正需要的包也没装上。 */
const STDLIB = new Set([
  're', 'os', 'sys', 'json', 'time', 'datetime', 'random', 'math', 'typing', 'pathlib',
  'base64', 'hashlib', 'urllib', 'subprocess', 'logging', 'collections', 'itertools',
  'functools', 'io', 'asyncio', 'threading', 'queue', 'string', 'copy', 'uuid', 'traceback',
  'inspect', 'shutil', 'tempfile', 'glob', 'csv', 'sqlite3', 'socket', 'ssl', 'http',
  'email', 'struct', 'binascii', 'unicodedata', 'secrets', 'platform', 'statistics',
  'decimal', 'fractions', 'enum', 'abc', 'dataclasses', 'contextlib', 'types', 'importlib',
  'pickle', 'zlib', 'gzip', 'tarfile', 'zipfile', 'xml', 'html', 'webbrowser', 'argparse',
  'getpass', 'textwrap', 'difflib', 'operator', 'bisect', 'heapq', 'array', 'numbers',
  'cmath', 'calendar', 'locale', 'signal', 'errno', 'select', 'multiprocessing',
  'concurrent', 'unittest', 'doctest', 'pdb', 'profile', 'timeit', 'trace', 'gc',
  'weakref', 'warnings', 'builtins', 'ctypes', 'codecs', 'wave', 'audioop', 'shlex',
]);

/** 超大依赖黑名单：单个几百 MB 到几 GB 的 ML/CUDA 栈。这台 1 核 1.6G 内存的
 *  机器装了也跑不动，还会把磁盘（批量装插件时）迅速吃穿。跳过后插件若
 *  import 失败，装载会如实报错 —— 比假装装上然后在运行时 OOM 诚实。
 *  注意只拦真巨头（torch/tf 系）；scipy/pandas/matplotlib/opencv 这类
 *  几十兆的常用库不拦 —— 拦了会误伤大量正常插件。 */
const HEAVY_DEPS = new Set([
  'torch', 'torchvision', 'torchaudio', 'tensorflow', 'keras', 'onnxruntime',
  'cupy', 'triton', 'xgboost', 'lightgbm', 'sentence_transformers',
  'transformers', 'diffusers', 'accelerate', 'datasets',
  'gradio', 'streamlit',
  'nvidia_cublas_cu12', 'nvidia_cuda_runtime', 'nvidia_cudnn_cu12',
  'nvidia_cuda_nvrtc', 'nvidia_cusparse_cu12', 'nvidia_cufft_cu12',
]);

/** 去掉唤醒前缀（默认 /），保留命令名 —— 与 AstrBot 的 message_str 语义一致。 */
export function stripPrefix(text, prefix = '/') {
  const t = String(text || '').trim();
  const p = String(prefix || '/');
  if (p && t.startsWith(p)) return t.slice(p.length).trim();
  return t;
}

/** 命令匹配：整名相等或「名字 + 空格 + 参数」。长的优先，避免 /天气 吃掉 /天气预报。 */
export function matchCommand(body, entries) {
  const text = String(body || '').trim().toLowerCase();
  if (!text) return null;
  let best = null;
  for (const [cmd, id] of entries) {
    const c = String(cmd).toLowerCase();
    if (!c) continue;
    if (text === c || text.startsWith(c + ' ') || text.startsWith(c + '\u3000')) {
      if (!best || c.length > best.cmd.length) best = { cmd, id };
    }
  }
  return best;
}

/**
 * 剥掉消息开头的 @ 提及。
 * NapCat 的 at 段在文本里是 "@昵称"；别的实现可能是 "[CQ:at,qq=123]"。两种都吃掉。
 * 只剥**开头**连续的提及：句中 @ 他人是正常语义，不该动。
 */
export function stripLeadingMentions(text) {
  let out = String(text || '').trim();
  for (let i = 0; i < 8; i += 1) {
    const next = out
      .replace(/^\[CQ:at,[^\]]*\]\s*/u, '')
      .replace(/^\[at\]\s*/u, '')
      // 昵称里不会出现 "/"，所以遇到 "/" 就停 —— 否则 "@机器人/gs" 会把命令一起吃掉。
      // 全角 ＠ 一并处理：手机输入法经常给这个。
      .replace(/^[@＠][^\s\u3000/]{1,39}[\s\u3000]*/u, '')
      .trim();
    if (next === out) break;
    out = next;
  }
  return out;
}

/**
 * 命令解析：给出这条消息命中的命令（没命中返回 null）。
 * 依次尝试三种形态，任一命中即返回 —— 见 hook 里的注释（@机器人 /gs 必须能用）。
 * @returns {{body:string, cmd:string, id:string}|null}
 */
export function resolveCommand(text, entries, prefix = '/') {
  const p = String(prefix || '/');
  const base = String(text || '').trim();
  if (!base || !entries || entries.size === 0) return null;

  const cands = [];
  const push = (s) => {
    const v = stripPrefix(s, p);
    if (v && !cands.includes(v)) cands.push(v);
  };

  push(base);                                   // ① 原样
  const bare = stripLeadingMentions(base);
  if (bare !== base) push(bare);                // ② 去掉开头的 @
  // ③ 只在"这条消息确实是 @ 出来的"时才兜底取第一个空格后的部分。
  //    不加这个前提，一句普通聊天里出现 "/gs" 也会被插件抢走。
  const tail = base.replace(/^\S+[\s\u3000]+/u, '');
  if (tail !== base && tail !== bare && /^[@＠]|^\[at\]|^\[CQ:at,/i.test(base)) push(tail);

  for (const body of cands) {
    const hit = matchCommand(body, entries);
    if (hit) return { body, cmd: hit.cmd, id: hit.id };
  }
  return null;
}

/** AstrBot 插件名 → 合法原生插件 id（manifest 要求 3~40 位小写字母数字连字符）。 */export function slugOf(origin) {
  let s = String(origin || '').toLowerCase();
  s = s.replace(/^astrbot[_-]?plugin[_-]?/, '').replace(/^astrbot[_-]?/, '');
  s = s.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  if (!s) s = 'plugin';
  if (s.length > 30) s = s.slice(0, 30).replace(/-+$/g, '') || 'plugin';
  if (s.length < 2) s = s + 'x';
  return `ab-${s}`;
}

// ── 中文名：把英文插件名翻成中文 ─────────────────────────────
//
// 市场里 1300+ 个插件大半是英文名（astrbot_plugin_wordle / GitHub Trending），
// 一列排下来根本认不出谁是谁。这里按优先级找名字：
//   ① 精确表（zh-names.json 的 plugins）：包名 → 中文名，最准；
//   ② 插件自己声明的中文展示名（display_name 里带汉字）直接用；
//   ③ 逐词翻译（words + keep）：**所有词都认识才翻**，宁可留原文，
//      也不要产出「Wordle 猜word」这种半中半英的怪名。
const CJK = /[\u3400-\u9fff\uf900-\ufaff]/;
const NAME_FILE = path.join(HERE, 'zh-names.json');
/** 运行期覆盖表：放 data 下，升级插件不会丢，用户可自己加 */
const NAME_OVERRIDE = path.join(DATA_ROOT, 'zh-names.json');

/** 包名归一：astrbot_plugin_wordle_2_cmd → wordle-2-cmd，方便同一张表匹配各种写法 */
export function normNameKey(s) {
  return String(s || '').toLowerCase()
    .replace(/^astrbot[_-]?plugins?[_-]?/, '')
    .replace(/^astrbot[_-]?/, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

let nameTables = null;
let nameTablesStamp = -1;

function loadNameTables() {
  // 表很小，按 mtime 缓存：用户改了 zh-names.json 不用重启服务
  let stamp = 0;
  for (const f of [NAME_FILE, NAME_OVERRIDE]) {
    try { stamp += fs.statSync(f).mtimeMs; } catch { /* 没有覆盖文件是常态 */ }
  }
  if (nameTables && stamp === nameTablesStamp) return nameTables;

  const base = readJson(NAME_FILE, {}) || {};
  const over = readJson(NAME_OVERRIDE, {}) || {};
  const plugins = {};
  for (const src of [base.plugins, over.plugins]) {
    for (const [k, v] of Object.entries(src || {})) {
      if (v) plugins[normNameKey(k)] = String(v);
    }
  }
  nameTables = {
    plugins,
    rename: { ...(base.rename || {}), ...(over.rename || {}) },
    words: { ...(base.words || {}), ...(over.words || {}) },
    keep: { ...(base.keep || {}), ...(over.keep || {}) }
  };
  // rename 的键也归一下，跟着 plugins 一起按包名匹配
  const rename = {};
  for (const [k, v] of Object.entries(nameTables.rename)) {
    if (v) rename[normNameKey(k)] = String(v);
  }
  nameTables.rename = rename;
  nameTablesStamp = stamp;
  return nameTables;
}

/** 中文拼接：中文之间不留空格，中英之间留一个 */
function joinParts(parts) {
  let out = '';
  for (const p of parts) {
    if (!out) { out = p; continue; }
    const needSpace = /[A-Za-z0-9]$/.test(out) || /^[A-Za-z0-9]/.test(p);
    out += (needSpace ? ' ' : '') + p;
  }
  return out;
}

function translateName(raw, t) {
  const tokens = String(raw || '')
    .replace(/^astrbot[_-]?plugins?[_-]?/i, '')
    .replace(/^astrbot[_-]?/i, '')
    .split(/[_\-\s·]+/)
    .filter(Boolean);
  if (!tokens.length) return '';
  const parts = [];
  for (const tok of tokens) {
    const lower = tok.toLowerCase();
    if (/^v?\d+(\.\d+)*$/.test(lower)) continue;                  // 版本号不参与命名
    if (['plugin', 'plugins', 'astrbot', 'bot'].includes(lower)) continue;
    if (CJK.test(tok)) { parts.push(tok); continue; }
    if (t.keep[lower]) { parts.push(t.keep[lower]); continue; }
    if (t.words[lower]) { parts.push(t.words[lower]); continue; }
    return '';                                                    // 有生词 → 不翻，保留原文
  }
  const text = joinParts(parts);
  return CJK.test(text) ? text : '';
}

/**
 * 取中文名。
 * @param {string} origin AstrBot 包名（store 目录名）
 * @param {...string} cands 插件/市场声明的展示名，按优先级
 */
export function zhName(origin, ...cands) {
  const t = loadNameTables();
  // 名字里已经有中文的，尊重作者写法 —— 只有「一列英文名」才需要翻译
  const hasZh = cands.some((c) => CJK.test(String(c || '')));
  if (!hasZh) {
    const exact = t.plugins[normNameKey(origin)];
    if (exact) return exact;
  }
  for (const c of cands) {
    const s = String(c || '').trim();
    if (s && CJK.test(s)) return s;
  }
  const byOrigin = translateName(origin, t);
  if (byOrigin) return byOrigin;
  for (const c of cands) {
    const byCand = translateName(c, t);
    if (byCand) return byCand;
  }
  const fallback = cands.map((c) => String(c || '').trim()).find(Boolean);
  return fallback || prettifyName(origin);
}

/** 强制改名（原名就算是中文也照改）：只在 rename 表里明确写了才生效 */
export function forcedName(origin) {
  return loadNameTables().rename[normNameKey(origin)] || '';
}

/** 实在翻不出来时，至少把 astrbot_plugin_ 前缀去干净，别把包名原样怼到界面上 */
function prettifyName(origin) {
  return String(origin || '')
    .replace(/^astrbot[_-]?plugins?[_-]?/i, '')
    .replace(/^astrbot[_-]?/i, '')
    .replace(/[_-]+/g, ' ')
    .trim() || String(origin || '').trim();
}

// ── 运行器：一个插件一个子进程 ────────────────────────────────

class Runner {
  constructor(origin, storeDir, pluginLog) {
    this.origin = origin;
    this.storeDir = storeDir;
    this.log = pluginLog;
    this.llm = null;          // 由 Runtime.runnerOf 注入：把补全请求交给内核模型
    this.proc = null;
    this.info = null;
    this.pending = new Map();
    this.seq = 0;
    this.buf = '';
    this.ready = null;
    this.alive = true;
    this.cfgFingerprint = '';
  }

  get python() {
    const venv = path.join(VENV_DIR, 'bin', 'python');
    return fs.existsSync(venv) ? venv : 'python3';
  }

  spawnProc() {
    const dataDir = path.join(DATA_ROOT, 'run', this.origin);
    fs.mkdirSync(dataDir, { recursive: true });
    const cfgFile = path.join(CONFIG_DIR, `${this.origin}.json`);
    let args = [RUNNER, '--dir', this.storeDir, '--data', dataDir];
    if (fs.existsSync(cfgFile)) args = args.concat(['--config-file', cfgFile]);

    const proc = spawn(this.python, args, {
      cwd: this.storeDir,
      env: { ...process.env, PYTHONUNBUFFERED: '1', PYTHONDONTWRITEBYTECODE: '1', PYTHONPATH: PY_DIR },
      stdio: ['pipe', 'pipe', 'pipe'],
    });
    this.proc = proc;

    this.ready = new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        // 超时先打死进程再说：只 reject 不 kill 会留下一个空转的 Python，
        // 它既不回消息也不退出，机器上多几个就把 CPU 占满。
        try { proc.kill('SIGKILL'); } catch { /* ignore */ }
        reject(new Error('插件启动超时（45 秒）'));
      }, 45000);
      this._resolveReady = (info) => { clearTimeout(timer); resolve(info); };
      this._rejectReady = (err) => { clearTimeout(timer); reject(err); };
    });

    proc.stdout.setEncoding('utf8');
    proc.stdout.on('data', (chunk) => {
      this.buf += chunk;
      let idx;
      while ((idx = this.buf.indexOf('\n')) >= 0) {
        const line = this.buf.slice(0, idx).trim();
        this.buf = this.buf.slice(idx + 1);
        if (!line) continue;
        let msg;
        try { msg = JSON.parse(line); } catch { continue; }
        this.onMessage(msg);
      }
    });

    proc.stderr.setEncoding('utf8');
    proc.stderr.on('data', (t) => {
      for (const line of String(t).split('\n')) {
        if (line.trim()) this.log(`[${this.origin}] ${line.trim()}`);
      }
    });

    proc.on('exit', (code, sig) => {
      this.proc = null;
      this.info = null;
      if (this._rejectReady) this._rejectReady(new Error(`插件进程退出（code=${code} signal=${sig}）`));
      for (const [, item] of this.pending) item.reject(new Error('插件进程已退出'));
      this.pending.clear();
    });

    proc.on('error', (err) => {
      if (this._rejectReady) this._rejectReady(err);
    });
  }

  onMessage(msg) {
    if (msg.type === 'ready') {
      this.info = msg;
      if (this._resolveReady) this._resolveReady(msg);
      return;
    }
    if (msg.type === 'llm') {
      // 插件在 handler 里 await 模型回包，Python 侧等着 llm_result；
      // 这里必须异步处理，不能挡住后续消息的解析。
      this.handleLlm(msg).catch(() => {});
      return;
    }
    if (msg.type === 'config_save') {
      // 插件运行时改了配置（context/config.save_config）→ 合并落盘。
      // 注意不能动 cfgFp：指纹跟的是「控制台推来的配置」，一旦改成这份合并值，
      // 下一条消息的 syncConfig 就会判定「配置变了」把进程杀掉，把这次保存冲掉。
      try { this.onConfigSave?.(msg.config || {}); } catch { /* 落盘失败不影响插件执行 */ }
      return;
    }
    if (msg.type === 'fatal') {
      if (this._rejectReady) this._rejectReady(new Error(msg.error || '插件启动失败'));
      return;
    }
    if (msg.type === 'result' || msg.type === 'pong') {
      const item = this.pending.get(msg.id);
      if (item) {
        this.pending.delete(msg.id);
        clearTimeout(item.timer);
        item.resolve(msg);
      }
    }
  }

  /**
   * 把 Python 侧的补全请求转给内核的模型通道。
   *
   * 模型、密钥、主备通道、冷却全在内核里（src/llm.js），插件进程只拿到正文，
   * 不接触密钥。`this.llm` 由 Runtime.runnerOf 在创建 Runner 时注入。
   */
  async handleLlm(msg) {
    const id = msg.id;
    const reply = (obj) => {
      try { this.proc?.stdin?.write(`${JSON.stringify({ type: 'llm_result', id, ...obj })}\n`); }
      catch { /* 进程已经走了，Python 侧会超时，不用管 */ }
    };
    const messages = Array.isArray(msg.messages) ? msg.messages : [];
    if (!messages.length) { reply({ error: '空请求：messages 为空' }); return; }
    try {
      if (typeof this.llm !== 'function') throw new Error('兼容层未接入模型通道');
      const out = await this.llm({
        messages,
        tools: msg.tools || null,
        temperature: typeof msg.temperature === 'number' ? msg.temperature : null,
      });
      const text = String(out?.message?.content ?? '').trim();
      if (!text) {
        const reasoning = String(out?.message?.reasoning_content ?? '');
        throw new Error(`模型返回空正文${reasoning ? `（推理 ${reasoning.length} 字，疑似被截断）` : ''}`);
      }
      reply({ text, usage: out?.usage || null, model: out?.model || '' });
    } catch (e) {
      const err = String(e?.message || e).slice(0, 300);
      this.log(`[llm] ${this.origin} 调模型失败：${err}`);
      reply({ error: err });
    }
  }

  async ensure() {
    if (this.proc && this.info) { this.lastUsed = Date.now(); return this.info; }
    if (!this.proc) this.spawnProc();
    return this.ready;
  }

  async call(event, timeoutMs = 60000) {
    this.lastUsed = Date.now();
    await this.ensure();
    const id = `r${++this.seq}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error('插件处理超时'));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer });
      try {
        this.proc.stdin.write(JSON.stringify({ type: 'event', id, ...event }) + '\n');
      } catch (err) {
        clearTimeout(timer);
        this.pending.delete(id);
        reject(err);
      }
    });
  }

  /**
   * 关掉插件进程。返回 Promise：进程真正退出后才 resolve。
   *
   * 之前只发 SIGTERM 就返回，下一轮探测紧接着又起一个新进程 —— 插件卡在
   * 纯 C 循环里（正则回溯、死锁）时 SIGTERM 不生效，进程会一直挂着吃满 CPU。
   * 小机器上叠两三个这样的僵尸就能把 sshd 挤掉。所以这里三级：先 shutdown，
   * 再 SIGTERM，最后 SIGKILL，并且给一个总时长兜底，绝不无限等。
   */
  kill() {
    this.alive = false;
    const proc = this.proc;
    this.proc = null;
    this.info = null;
    if (!proc) return Promise.resolve();

    return new Promise((resolve) => {
      let done = false;
      const finish = () => { if (!done) { done = true; resolve(); } };
      proc.once('exit', finish);

      try { proc.stdin.write('{"type":"shutdown"}\n'); } catch { /* ignore */ }
      const t1 = setTimeout(() => { try { proc.kill('SIGTERM'); } catch { /* ignore */ } }, 800);
      const t2 = setTimeout(() => { try { proc.kill('SIGKILL'); } catch { /* ignore */ } }, 3000);
      const t3 = setTimeout(finish, 4500);

      proc.once('exit', () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); });
    });
  }
}

// ── 运行时 ────────────────────────────────────────────────────

class Runtime {
  constructor() {
    /** @type {Map<string, Runner>} origin -> runner */
    this.runners = new Map();
    /** 命令 -> origin，全局唯一性检查用 */
    this.owners = new Map();
    /** 已 attach 的 origin -> {ctx, commands} */
    this.attached = new Map();
    /** origin -> 上次同步给 Python 的配置指纹（判断是否要重启进程） */
    this.cfgFp = new Map();
    /** 空闲回收定时器 */
    this._reaper = null;
    // 默认 5 分钟；面板配置项 idleKillMinutes 可调，设 0 关闭回收
    const idleMin = Number(getConfig()?.plugins?.['astrbot-compat']?.idleKillMinutes ?? 5);
    if (idleMin > 0) this.startIdleReaper(idleMin * 60 * 1000);
  }

  /**
   * 回收闲置插件进程。
   *
   * 每个插件进程常驻约 25~50MB，12 个插件就是 350MB。这台机器只有 1.6G，
   * 装到二三十个插件就会把内存吃干，进而触发 swap、把整机拖死。插件进程
   * 本来就是懒启动的，杀掉不影响功能（下次发命令再拉起，代价约 0.5 秒）。
   */
  startIdleReaper(idleMs = 5 * 60 * 1000) {
    if (this._reaper) return;
    this._reaper = setInterval(() => {
      const now = Date.now();
      for (const [origin, runner] of [...this.runners]) {
        if (!runner.info) continue;                       // 没起成功的不算
        if (now - (runner.lastUsed || 0) < idleMs) continue;
        this.runners.delete(origin);
        Promise.resolve(runner.kill()).catch(() => {});
      }
    }, 60 * 1000);
    this._reaper.unref?.();                               // 别拖住进程退出
  }

  // ── 扫描：以 plugins/ 目录为唯一真相 ──────────────────────

  /** 已生成的原生插件条目（扫 plugins/ab-<slug>/astrbot.json） */
  installed() {
    const out = [];
    let names = [];
    try {
      names = fs.readdirSync(PLUGINS_ROOT, { withFileTypes: true })
        .filter((d) => d.isDirectory() && d.name.startsWith('ab-'))
        .map((d) => d.name);
    } catch { return out; }
    for (const slug of names) {
      const meta = readJson(path.join(PLUGINS_ROOT, slug, 'astrbot.json'), null);
      if (!meta || !meta.origin) continue;
      out.push({ slug, ...meta, storeExists: fs.existsSync(path.join(STORE_DIR, meta.origin)) });
    }
    return out;
  }

  byOrigin(origin) {
    return this.installed().find((x) => x.origin === origin) || null;
  }

  bySlug(slug) {
    return this.installed().find((x) => x.slug === slug) || null;
  }

  /**
   * 把已装插件的名字统一换成中文。
   * 只动 manifest.json / astrbot.json 的 name（和页签标题），不碰源码、不碰配置、不碰数据 ——
   * 所以随时可以再点一次，改了 zh-names.json 之后也是点一下就生效。
   */
  relocalizeNames() {
    const changed = [];
    for (const rec of this.installed()) {
      const dir = path.join(PLUGINS_ROOT, rec.slug);
      const mf = path.join(dir, 'manifest.json');
      const manifest = readJson(mf, null);
      if (!manifest) continue;
      const next = forcedName(rec.origin) || zhName(rec.origin, manifest.name);
      if (!next || next === manifest.name) continue;

      const from = manifest.name;
      manifest.name = next;
      if (manifest.uiTab && typeof manifest.uiTab === 'object') manifest.uiTab.label = next;
      writeJson(mf, manifest);

      // astrbot.json 是卡片元数据的来源（/meta 读它），漏改的话重建卡片又变回英文
      const metaFile = path.join(dir, 'astrbot.json');
      const meta = readJson(metaFile, null);
      if (meta) {
        meta.name = next;
        writeJson(metaFile, meta);
      }
      changed.push({ slug: rec.slug, origin: rec.origin, from, to: next });
    }
    return changed;
  }

  // ── 配置 ──────────────────────────────────────────────────

  /** 把控制台里的插件配置同步成 Python 侧读的 JSON（指纹没变就什么都不做）。 */
  syncConfig(origin, cfg) {
    const clean = {};
    for (const [k, v] of Object.entries(cfg || {})) {
      // enabled 是内核的启用标志；prefix 是兼容层自己的唤醒前缀。
      // 两者的使用者都在 Node 侧，传进 Python 会变成插件看不懂的陌生键。
      if (k === 'enabled' || k === '_origin' || k === 'prefix') continue;
      clean[k] = v;
    }
    const fp = JSON.stringify(clean);
    // 指纹单独放一张表，而不是挂在 Runner 上：
    // 配置变化要先重启进程，那时 Runner 正好被销毁，挂在它身上记不住上一次的值。
    if (this.cfgFp.get(origin) === fp) return;
    this.cfgFp.set(origin, fp);

    writeJson(path.join(CONFIG_DIR, `${origin}.json`), clean);
    const runner = this.runners.get(origin);
    if (runner) {
      // 配置变了 → 杀掉旧进程，下次调用时用新配置重新拉起
      runner.kill();
      this.runners.delete(origin);
    }
  }

  /** Python 侧 save_config 送来的配置：合并落盘（不动 cfgFp，不重启进程）。 */
  persistConfig(origin, cfg) {
    const file = path.join(CONFIG_DIR, `${origin}.json`);
    let cur = {};
    try { cur = JSON.parse(fs.readFileSync(file, 'utf8')) || {}; } catch { /* 首次保存，文件还没有 */ }
    writeJson(file, { ...cur, ...cfg });
  }

  runnerOf(origin) {
    let runner = this.runners.get(origin);
    if (!runner) {
      const meta = this.byOrigin(origin);
      const store = path.join(STORE_DIR, origin);
      runner = new Runner(origin, store, (m) => {
        const rec = this.attached.get(origin);
        rec?.ctx?.log?.(m);
      });
      // 模型通道：每次现取 attached 里的 ctx，因为 runnerOf 可能早于 attach
      runner.llm = (payload) => {
        const fn = this.attached.get(origin)?.ctx?.chatCompletion;
        if (typeof fn !== 'function') throw new Error('当前内核没有提供模型通道（ctx.chatCompletion 缺失）');
        return fn(payload);
      };
      // 配置保存通道：Python 侧 save_config 送来的增量，合并进 CONFIG_DIR 的 JSON。
      // 只合并不覆盖：控制台之后若改配置，syncConfig 会按「控制台优先」整体重写。
      runner.onConfigSave = (cfg) => this.persistConfig(origin, cfg);
      this.runners.set(origin, runner);
    }
    return runner;
  }

  // ── 挂载：一个 ab-* 插件 = 一份 attach ────────────────────

  /**
   * 把一个 AstrBot 插件接进内核。
   * @param {object} ctx 原生插件上下文（带 config / log / sender / http）
   * @param {string} origin AstrBot 原始插件名（store 目录名）
   */
  attach(ctx, origin) {
    const meta = this.byOrigin(origin);
    if (!meta) throw new Error(`没有登记 astrbot.json（${origin}），请重新从市场安装`);
    const storeDir = path.join(STORE_DIR, origin);
    if (!fs.existsSync(storeDir)) {
      throw new Error(`插件源码丢失（${storeDir}），请重新从市场安装`);
    }

    // 配置基线：先落盘一次，保证进程起来就能读到用户改过的值
    this.syncConfig(origin, ctx.config.get());

    // 命令表：安装时已由真实进程确认过，这里直接用，避免启动时再拉起 N 个进程
    const myEntries = new Map();
    const warnings = [];
    for (const cmd of meta.commands || []) {
      const owner = this.owners.get(cmd);
      if (owner && owner !== origin) {
        warnings.push(`命令 ${cmd} 已被 ${owner} 占用，本条不生效`);
        continue;
      }
      this.owners.set(cmd, origin);
      myEntries.set(cmd, origin);
    }
    if (warnings.length) ctx.log(`命令冲突：${warnings.join('；')}`);

    const rec = { ctx, commands: [...myEntries.keys()] };
    this.attached.set(origin, rec);

    const unHook = ctx.hooks.on('message', async (msg) => {
      const cfg = ctx.config.get() || {};
      if (cfg.enabled === false) return undefined;
      const text = String(msg.text || '').trim();
      if (!text || !myEntries.size) return undefined;

      // 关键：群友的习惯是「@机器人 /gs」。NapCat 把 at 段渲染成 "@昵称"，
      // 留在文本开头就会让整条匹配失败，命令漏给模型（模型只能瞎回一句）。
      // resolveCommand 会同时试「原文 / 去掉 @ 后 / 第一个空格后的部分」三种形态。
      const hit = resolveCommand(text, myEntries, cfg.prefix ?? '/');
      if (!hit) return undefined;
      const body = hit.body;

      try {
        this.syncConfig(origin, cfg);
        const res = await this.invoke(origin, msg, body);
        if (!res) return undefined;   // 命令名撞上了但这插件不认（权限/类型不符）
        if (res.error) {
          // 插件内部抛错：记日志，然后把这条消息接走。
          // 不发 traceback 到群里（运维噪声），也不能放给 LLM —— 那会变成瞎编。
          ctx.log(`执行出错（${res.handler || 'handler'}）：${res.error}`);
          return { handled: true };
        }
        await this.deliver(ctx, msg, res.actions, storeDir);
        return { handled: true };
      } catch (err) {
        ctx.log(`调用失败：${err?.message || err}`);
        return undefined;             // 出错就放给 LLM，别让用户干等
      }
    });

    // 本插件自己的元信息端点 → /api/plugins/<slug>/meta（供 ui.js 渲染配置表单）
    const unRoute = ctx.http.route('GET', '/meta', () => ({
      ok: true,
      origin,
      name: meta.name || origin,
      version: meta.version || '',
      commands: [...myEntries.keys()],
      warnings,
      store: storeDir,
      repo: meta.repo || '',
      schema: meta.schema || {},
      loadError: meta.loadError || '',
      deps: meta.deps || '',
      installedAt: meta.installedAt || '',
      readme: !!meta.readme,
      running: !!this.runners.get(origin)?.info,
    }));

    // 使用说明 → /api/plugins/<slug>/guide（卡片里「怎么用」那一段）
    // 内容 = 安装时从仓库 README 抽出来的 usage.md（已去图去标签），不是现场抓网。
    const unGuide = ctx.http.route('GET', '/guide', () => {
      const file = path.join(PLUGINS_ROOT, meta.slug || '', 'usage.md');
      let markdown = '';
      try { markdown = fs.readFileSync(file, 'utf8'); } catch { /* 老插件还没生成 */ }
      return {
        ok: true,
        prefix: String((ctx.config.get() || {}).prefix || '/'),
        commands: [...myEntries.keys()],
        markdown,
      };
    });

    return {
      dispose: () => {
        try { unHook(); } catch { /* ignore */ }
        try { unRoute(); } catch { /* ignore */ }
        try { unGuide(); } catch { /* ignore */ }
        for (const cmd of myEntries.keys()) {
          if (this.owners.get(cmd) === origin) this.owners.delete(cmd);
        }
        this.attached.delete(origin);
        const runner = this.runners.get(origin);
        if (runner) { runner.kill(); this.runners.delete(origin); }
      }
    };
  }

  async invoke(origin, msg, body) {
    const runner = this.runnerOf(origin);
    const masterQQ = String(getConfig().persona?.masterQQ || '');
    const res = await runner.call({
      text: body,
      chat: { key: msg.chatKey, kind: msg.kind, id: String(msg.chatId || '') },
      user: { id: String(msg.userId || ''), name: String(msg.senderName || '') },
      selfId: String(msg.selfId || ''),
      messageId: String(msg.messageId || ''),
      isAdmin: String(msg.userId || '') === masterQQ,
      components: (msg.media || []).map((m) => ({ type: m.kind, url: m.url })),
    });
    if (!res || res.matched !== true) return null;
    return res;   // res.error 由调用方决定怎么呈现（这里不抛，避免整条命令落到 LLM 手里）
  }

  async deliver(ctx, msg, actions, storeDir = '') {
    const texts = [];
    const images = [];
    const medias = [];
    for (const act of actions || []) {
      if (act.kind === 'text' && act.text) texts.push(act.text);
      else if (act.kind === 'image' && (act.url || act.file)) images.push(act.url || act.file);
      else if (act.kind === 'at' && act.qq) texts.unshift(`[CQ:at,qq=${act.qq}]`);
      else if ((act.kind === 'record' || act.kind === 'video') && (act.url || act.file)) {
        // 语音/视频：以前直接丢弃，插件明明回了但用户什么都收不到
        medias.push({ kind: act.kind, src: act.url || act.file, name: '' });
      } else if (act.kind === 'file' && (act.file || act.url)) {
        medias.push({ kind: 'file', src: act.file || act.url, name: act.name || '' });
      }
      // Nodes 展开后附带的图片/媒体（牌面图、战绩图走这条）
      for (const src of act.images || []) images.push(src);
      for (const m of act.medias || []) medias.push(m);
    }
    const body = texts.join('\n').trim();
    if (body) {
      try {
        await ctx.sender.sendTextBatch(msg.chatKey, body, {});
      } catch (err) {
        ctx.log(`发送失败：${err?.message || err}`);
      }
    }
    for (const raw of images) {
      // base64:// 是 OneBot 标准图片格式（NapCat 直接认），不少 AstrBot 插件
      // 用 Image.fromBase64 出图，这里必须一并放行，否则整类插件都发不出图。
      let src = raw;
      if (!/^(https?:\/\/|base64:\/\/)/i.test(src)) {
        // 插件给的是本地文件（resources/xxx.jpg 或绝对路径）：读成 base64 再发。
        // 相对路径按插件自己的 store 目录解析，跟 Python 侧 cwd 保持一致。
        const clean = String(src).replace(/^file:\/\//, '');
        const abs = path.isAbsolute(clean) ? clean : path.resolve(storeDir || '.', clean);
        try {
          const buf = fs.readFileSync(abs);
          if (buf.length > 8 * 1024 * 1024) {
            ctx.log(`图片过大（${Math.round(buf.length / 1024)}KB），已跳过：${clean}`);
            continue;
          }
          src = 'base64://' + buf.toString('base64');
        } catch {
          ctx.log(`图片读取失败（可能被插件删了或路径不对）：${abs}`);
          continue;
        }
      }
      try {
        await ctx.sender.sendImage(msg.chatKey, src, {});
      } catch (err) {
        ctx.log(`发图失败：${err?.message || err}`);
      }
    }
    for (const m of medias) {
      if (!m || !m.src) continue;
      try {
        await ctx.sender.sendMedia(msg.chatKey, m.kind, m.src, m.name);
      } catch (err) {
        ctx.log(`发送 ${m.kind} 失败：${err?.message || err}`);
      }
    }
    return body.length > 0 || images.length > 0 || medias.length > 0;
  }

  // ── 安装 / 卸载 ───────────────────────────────────────────

  async install(repo) {
    const m = REPO_RE.exec(String(repo || '').trim());
    if (!m) throw new Error('只支持 GitHub 仓库地址，形如 https://github.com/owner/repo');
    const [, owner, name] = m;
    const tmp = path.join(DATA_ROOT, 'tmp', `${name}-${Date.now()}`);
    fs.mkdirSync(tmp, { recursive: true });

    let buf = null;
    let branch = '';
    for (const br of ['main', 'master']) {
      const url = `https://codeload.github.com/${owner}/${name}/tar.gz/refs/heads/${br}`;
      const resp = await fetch(url, { headers: { 'User-Agent': 'astrbot-compat' } });
      if (resp.ok) {
        buf = Buffer.from(await resp.arrayBuffer());
        branch = br;
        break;
      }
    }
    if (!buf) throw new Error('下载失败：main / master 分支都取不到（仓库不存在或私有）');

    const tgz = path.join(tmp, 'src.tar.gz');
    await fsp.writeFile(tgz, buf);
    const dest = path.join(tmp, 'src');
    fs.mkdirSync(dest, { recursive: true });
    await untar(tgz, dest);

    const metaPath = ['metadata.yaml', 'metadata.yml']
      .map((f) => path.join(dest, f)).find((p) => fs.existsSync(p));
    if (!metaPath) throw new Error('包内没有 metadata.yaml，不像是 AstrBot 插件');
    if (!fs.existsSync(path.join(dest, 'main.py'))) throw new Error('包内没有 main.py');

    const meta = parseMeta(metaPath);
    // metadata 的 name 偶尔被作者写成中文展示名（不是包名）。
    // 中文不能当目录名，退回仓库名；展示名仍然用 display_name 或原文。
    let origin = String(meta.name || '').trim();
    if (!/^[A-Za-z0-9_.-]{2,80}$/.test(origin)) origin = String(name).replace(/[^\w.-]/g, '_');
    if (!/^[A-Za-z0-9_.-]{2,80}$/.test(origin)) throw new Error(`插件名不合法：${meta.name || name}`);

    const target = path.join(STORE_DIR, origin);
    await fsp.rm(target, { recursive: true, force: true });
    fs.mkdirSync(STORE_DIR, { recursive: true });
    await fsp.rename(dest, target);

    // 依赖：requirements.txt 里有内容才装
    let deps = '';
    const reqPath = path.join(target, 'requirements.txt');
    if (fs.existsSync(reqPath) && fs.readFileSync(reqPath, 'utf8').trim()) {
      deps = await pipInstall(target, reqPath);
    }

    // 起一次进程拿真实命令表（比静态扫准），拿到就杀掉 —— 运行时按需懒启动
    const schema = readJson(path.join(target, '_conf_schema.json'), {});
    const probed = await probePlugin(origin, target);
    const info = probed.info;
    const loadError = probed.loadError;
    if (probed.deps) deps = deps ? `${deps}；${probed.deps}` : probed.deps;

    const commands = info?.commands || [];
    // 展示名：有中文就用中文（作者的 display_name / 中文名对照表），实在没有才留原文
    const displayName = forcedName(origin) || zhName(origin, info?.name, meta.display_name);
    const version = String(info?.version || meta.version || '0.0.0').replace(/^[vV]+/, '').trim() || '0.0.0';

    const saved = {
      origin,
      repo: String(repo).trim(),
      branch,
      name: displayName,
      version,
      commands,
      schema,
      deps,
      loadError,
      // 装的时候就记下 README 的清洗结果 —— 卡片「怎么用」直接用，不用再联网
      readme: tidyReadme(readmeOf(origin)),
      installedAt: new Date().toISOString(),
    };

    // 生成原生插件目录（三件套 + 可选 ui.js）
    const slug = await materialize(saved);
    await fsp.rm(tmp, { recursive: true, force: true }).catch(() => {});
    return { ...saved, slug };
  }

  async uninstallOrigin(origin) {
    const meta = this.byOrigin(origin);
    await fsp.rm(path.join(STORE_DIR, origin), { recursive: true, force: true }).catch(() => {});
    await fsp.rm(path.join(DATA_ROOT, 'run', origin), { recursive: true, force: true }).catch(() => {});
    await fsp.rm(path.join(CONFIG_DIR, `${origin}.json`), { force: true }).catch(() => {});
    const runner = this.runners.get(origin);
    // 等进程真的退出再继续：卸载会删掉源码目录，进程若还活着会读到半截文件
    if (runner) { await runner.kill(); this.runners.delete(origin); }
    return meta?.slug || '';
  }

  /** 清孤儿：store 里存在但 plugins/ 下没有对应 ab-* 的（用户从面板卸载留下的） */
  gc() {
    const alive = new Set(this.installed().map((x) => x.origin));
    const removed = [];
    let names = [];
    try { names = fs.readdirSync(STORE_DIR, { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => d.name); }
    catch { return removed; }
    for (const name of names) {
      if (alive.has(name)) continue;
      try {
        fs.rmSync(path.join(STORE_DIR, name), { recursive: true, force: true });
        fs.rmSync(path.join(DATA_ROOT, 'run', name), { recursive: true, force: true });
        fs.rmSync(path.join(CONFIG_DIR, `${name}.json`), { force: true });
        removed.push(name);
      } catch { /* ignore */ }
    }
    return removed;
  }

  async market(force = false) {
    const cachePath = path.join(DATA_ROOT, 'market.json');
    const cache = readJson(cachePath, null);
    const fresh = cache && (Date.now() - Number(cache.at || 0) < MARKET_TTL_MS);
    if (fresh && !force) return cache;

    const fails = [];
    for (const url of MARKET_URLS) {
      let host = url;
      try { host = new URL(url).host; } catch { /* ignore */ }
      try {
        const resp = await fetch(url, {
          headers: { 'User-Agent': 'astrbot-compat' },
          signal: AbortSignal.timeout(8000)
        });
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        const data = await resp.json();
        if (!data || !Object.keys(data).length) throw new Error('索引为空');
        const payload = { at: Date.now(), data };
        writeJson(cachePath, payload);
        return payload;
      } catch (err) {
        fails.push(`${host}: ${err.message}`);
      }
    }

    // 所有源都失败：有旧缓存就继续用（标记 stale），面板照常展示，不弹红字
    if (cache) { cache.stale = true; return cache; }
    throw new Error('所有索引源均不可达（' + fails.join(' / ') + '）');
  }
}

// ── 生成原生插件 ─────────────────────────────────────────────

/** index.js 模板：薄壳，只把控制权交给 runtime */
function tplIndex(origin) {
  return `// 本文件由 astrbot-compat 自动生成，请勿手改。
// 卸载/重装会整体覆盖；插件逻辑在 AstrBot 的 Python 源码里。
import { runtime } from '../astrbot-compat/runtime.js';

export async function activate(ctx) {
  return runtime.attach(ctx, ${JSON.stringify(origin)});
}
`;
}

/** ui.js 模板：按 AstrBot 的 _conf_schema 自动渲染配置表单 */
const TPL_UI = `// 本文件由 astrbot-compat 自动生成，请勿手改。
// 配置表单由插件自己的 _conf_schema.json 驱动，保存走内核既有的 /api/plugins/config。

// 极简 Markdown → HTML（只够渲染 README：标题/列表/代码/粗体/链接/表格行）。
// 为什么自己写：插件面板不能依赖外部 CDN，也不值得为此装一个 md 库。
function mdToHtml(src, esc) {
  const lines = String(src || '').split('\\n');
  const out = [];
  let code = null;      // 代码块缓冲
  let inList = false;
  const inline = (t) => esc(t)
    .replace(/\`([^\`]+)\`/g, '<code>$1</code>')
    .replace(/\\*\\*([^*]+)\\*\\*/g, '<b>$1</b>')
    .replace(/\\[([^\\]]+)\\]\\((https?:[^)]+)\\)/g, '<a href="$2" target="_blank" rel="noreferrer">$1</a>');
  const closeList = () => { if (inList) { out.push('</ul>'); inList = false; } };
  for (const raw of lines) {
    const line = String(raw).replace(/\\s+$/, '');
    if (/^\\s*\`\`\`/.test(line)) {
      if (code === null) { closeList(); code = []; continue; }
      out.push('<pre style="margin:6px 0;padding:8px 10px;border-radius:6px;overflow:auto;font-size:11.5px;background:rgba(127,127,127,.14)"><code>' + esc(code.join('\\n')) + '</code></pre>');
      code = null; continue;
    }
    if (code !== null) { code.push(raw); continue; }
    if (!line.trim()) { closeList(); continue; }
    const h = /^(#{1,4})\\s+(.*)$/.exec(line);
    if (h) {
      closeList();
      const n = Math.min(h[1].length + 2, 6);
      out.push('<h' + n + ' style="margin:12px 0 4px;font-size:' + (n <= 3 ? 14 : 13) + 'px">' + inline(h[2]) + '</h' + n + '>');
      continue;
    }
    if (/^\\s*([-*_])\\1{2,}\\s*$/.test(line)) { closeList(); out.push('<hr style="border:0;border-top:1px solid rgba(127,127,127,.25);margin:10px 0">'); continue; }
    const li = /^\\s*[-*+]\\s+(.*)$/.exec(line);
    if (li) { if (!inList) { out.push('<ul style="margin:4px 0;padding-left:18px">'); inList = true; } out.push('<li style="margin:2px 0">' + inline(li[1]) + '</li>'); continue; }
    const ol = /^\\s*\\d+[.)]\\s+(.*)$/.exec(line);
    if (ol) { closeList(); out.push('<div style="margin:3px 0">• ' + inline(ol[1]) + '</div>'); continue; }
    if (/^\\s*\\|/.test(line)) { closeList(); out.push('<div style="font-size:11.5px;white-space:pre-wrap;font-family:ui-monospace,monospace">' + inline(line) + '</div>'); continue; }
    const quote = /^\\s*>\\s?(.*)$/.exec(line);
    if (quote) { closeList(); out.push('<div class="muted" style="margin:4px 0;padding-left:8px;border-left:2px solid rgba(127,127,127,.35)">' + inline(quote[1]) + '</div>'); continue; }
    closeList(); out.push('<div style="margin:4px 0">' + inline(line) + '</div>');
  }
  closeList();
  return out.join('');
}

export async function mountPanel(root, ctx) {
  const { api, esc, savePluginConfig, pluginConfigOf } = ctx;
  root.innerHTML = '<div class="muted" style="padding:16px">加载中…</div>';

  let meta;
  try {
    meta = await api('/api/plugins/' + encodeURIComponent(ctx.pluginId) + '/meta');
  } catch (e) {
    root.innerHTML = '<div style="padding:16px;color:#c33">读取插件信息失败：' + esc(e.message) + '</div>';
    return;
  }
  const schema = (meta && meta.schema) || {};
  const cur = (await pluginConfigOf(ctx.pluginId)) || {};
  const keys = Object.keys(schema);

  const label = (k, s) => esc(s && s.description ? s.description : k);
  const hint = (s) => (s && s.hint ? '<div class="muted" style="font-size:12px;margin-top:2px">' + esc(s.hint) + '</div>' : '');

  const field = (k, s) => {
    const v = cur[k] !== undefined ? cur[k] : (s && s.default !== undefined ? s.default : '');
    const t = (s && s.type) || 'string';
    const id = 'abf-' + k;
    let input;
    if (t === 'bool') {
      return '<label style="display:flex;gap:8px;align-items:center;margin:8px 0">' +
        '<input type="checkbox" id="' + id + '" data-k="' + esc(k) + '" data-t="bool"' + (v ? ' checked' : '') + '>' +
        '<span>' + label(k, s) + '</span></label>' + hint(s);
    }
    if (Array.isArray(s && s.options) && s.options.length) {
      input = '<select id="' + id + '" data-k="' + esc(k) + '" data-t="string" style="width:100%">' +
        s.options.map((o) => '<option value="' + esc(o) + '"' + (String(o) === String(v) ? ' selected' : '') + '>' + esc(o) + '</option>').join('') +
        '</select>';
    } else if (t === 'text' || t === 'dict' || t === 'list' || t === 'file') {
      const raw = typeof v === 'object' ? JSON.stringify(v, null, 2) : String(v == null ? '' : v);
      input = '<textarea id="' + id + '" data-k="' + esc(k) + '" data-t="' + (t === 'dict' ? 'dict' : t === 'list' ? 'list' : 'text') + '" rows="3" style="width:100%">' + esc(raw) + '</textarea>';
    } else {
      const type = (t === 'int' || t === 'float') ? 'number' : 'text';
      input = '<input id="' + id + '" data-k="' + esc(k) + '" data-t="' + (type === 'number' ? 'number' : 'string') + '" type="' + type + '" value="' + esc(String(v == null ? '' : v)) + '" style="width:100%">';
    }
    return '<div style="margin:10px 0"><div style="margin-bottom:4px">' + label(k, s) + '</div>' + input + hint(s) + '</div>';
  };

  const head = '<div class="card"><h3 style="margin:0 0 6px">' + esc(meta.name || meta.origin) + '　<span class="muted" style="font-size:12px">v' + esc(meta.version || '?') + '</span></h3>' +
    '<div class="muted" style="font-size:12px;line-height:1.7">AstrBot 原始名：' + esc(meta.origin) +
    (meta.repo ? '<br>来源：' + esc(meta.repo) : '') +
    '<br>命令：' + (meta.commands && meta.commands.length ? esc(meta.commands.map((c) => '/' + c).join('　')) : '（无命令）') +
    (meta.loadError ? '<br><span style="color:#c33">加载失败：' + esc(meta.loadError) + '</span>' : '') +
    '</div></div>';

  // ── 怎么用 ────────────────────────────────────────────────
  // 卡片必须自己讲清楚用法：从市场装完的人不该再去翻 AstrBot 文档。
  let guide = null;
  try { guide = await api('/api/plugins/' + encodeURIComponent(ctx.pluginId) + '/guide'); } catch (e) { guide = null; }
  const cmds = (meta.commands && meta.commands.length) ? meta.commands : [];
  const prefix = (guide && guide.prefix) || '/';

  const usage = '<div class="card"><h3 style="margin:0 0 6px">怎么用</h3>' +
    '<ol class="muted" style="font-size:12px;line-height:1.8;margin:6px 0 10px;padding-left:18px">' +
      '<li>在群里直接发命令：<code>' + esc(prefix) + '命令</code>。<b>不用 @ 机器人</b>；@ 了也能识别。</li>' +
      '<li>命令在唤醒模型<b>之前</b>就被接走：不烧 token，也不会被人设改写、不会跟聊天抢话。</li>' +
      '<li>只在这个插件被<b>启用</b>时生效；停用后同样的话会当作普通聊天交给模型。</li>' +
    '</ol>' +
    (cmds.length
      ? '<div class="muted" style="font-size:12px;margin-bottom:6px">可用命令（共 ' + cmds.length + ' 条，发任意一条都算触发）：</div>' +
        '<div style="display:flex;flex-wrap:wrap;gap:6px">' + cmds.map(function (c) {
          return '<code style="padding:2px 7px;border-radius:5px;font-size:12.5px;background:rgba(127,127,127,.16)">' + esc(prefix + c) + '</code>';
        }).join('') + '</div>'
      : '<div class="muted" style="font-size:12px">这个插件没有注册命令，靠事件触发（入群/退群/消息监听等），启用后自动生效。</div>') +
    (meta.loadError ? '<div style="font-size:12px;color:#c33;margin-top:8px">注意：这个插件当前加载失败（见上方红字），命令发出去不会有反应。多数是缺 <code>call_action</code> / LLM 桥接。</div>' : '') +
    ((guide && guide.markdown) ? '<details style="margin-top:10px"><summary style="cursor:pointer;font-size:12px;color:#888">插件说明书（装的时候从仓库 README 存下来的）</summary><div style="font-size:12.5px;line-height:1.75;margin-top:8px">' + mdToHtml(guide.markdown, esc) + '</div></details>' : '') +
    '</div>';

  const form = keys.length
    ? '<div class="card"><h3 style="margin:0 0 4px">配置</h3>' +
      '<div class="muted" style="font-size:12px;margin-bottom:8px">改完保存后，下一次调用命令时自动生效（进程会用新配置重启）。</div>' +
      keys.map((k) => field(k, schema[k])).join('') +
      '<div style="margin-top:12px"><button class="btn" id="absave">保存配置</button> ' +
      '<span id="abmsg" class="muted" style="margin-left:8px"></span></div></div>'
    : '<div class="card"><div class="muted">这个插件没有声明配置项（_conf_schema.json 为空）。</div></div>';

  root.innerHTML = head + usage + form;

  const btn = root.querySelector('#absave');
  if (!btn) return;
  btn.addEventListener('click', async () => {
    const msg = root.querySelector('#abmsg');
    const patch = {};
    root.querySelectorAll('[data-k]').forEach((el) => {
      const k = el.dataset.k;
      const t = el.dataset.t;
      if (t === 'bool') { patch[k] = !!el.checked; return; }
      if (t === 'number') { patch[k] = el.value === '' ? 0 : Number(el.value); return; }
      if (t === 'dict' || t === 'list') {
        try { patch[k] = JSON.parse(el.value || 'null'); }
        catch { throw new Error(k + ' 不是合法 JSON'); }
        return;
      }
      patch[k] = el.value;
    });
    try {
      msg.textContent = '保存中…';
      await savePluginConfig(ctx.pluginId, patch);
      msg.textContent = '已保存';
      setTimeout(() => { msg.textContent = ''; }, 2500);
    } catch (e) {
      msg.textContent = '保存失败：' + e.message;
    }
  });
}
`;

/** 选一个不与现有插件冲突的 slug */
function pickSlug(origin) {
  const base = slugOf(origin);
  let slug = base;
  let n = 2;
  while (fs.existsSync(path.join(PLUGINS_ROOT, slug))) {
    const meta = readJson(path.join(PLUGINS_ROOT, slug, 'astrbot.json'), null);
    if (meta && meta.origin === origin) return slug;   // 重装同一个插件
    slug = `${base}-${n++}`;
    if (n > 20) break;
  }
  return slug;
}

/** 生成（或覆盖）plugins/ab-<slug>/ 四件套 */
export async function materialize(rec) {
  const slug = pickSlug(rec.origin);
  const dir = path.join(PLUGINS_ROOT, slug);
  fs.mkdirSync(dir, { recursive: true });

  const defaults = {};
  for (const [k, s] of Object.entries(rec.schema || {})) {
    if (s && typeof s === 'object' && s.default !== undefined) defaults[k] = s.default;
  }

  // 重建卡片时保留用户已经改过的配置：materialize 会被「重建卡片」「重装」反复调用，
  // 若无脑写回默认值，用户填的 token / 开关就没了。
  const prev = readJson(path.join(dir, 'manifest.json'), null);
  const prevCfg = (prev && prev.config) || {};

  const cmdLine = (rec.commands || []).slice(0, 3).map((c) => '/' + c).join(' ');
  // 卡片名统一走中文名解析：重建卡片、重装、名称中文化三条路都从这里过
  const name = forcedName(rec.origin) || zhName(rec.origin, rec.name) || rec.origin;
  // 卡片描述 =「这个插件是干嘛的 + 怎么用」——用户在插件列表里不点开配置就该能看懂。
  // 用法行优先取 README「使用/用法/命令」段里的 /命令 示例，没有再退回探测到的命令表。
  const readmeEarly = rec.readme ?? tidyReadme(readmeOf(rec.origin));
  const { brief, usage } = usageOf(readmeEarly, rec.commands || []);
  const manifest = {
    id: slug,
    name,
    // 版本号统一存裸版本，展示层加 "v"；插件写法五花八门（v1.2 / vv1.0.2）
    version: String(rec.version || '0.0.0').replace(/^[vV]+/, '').trim() || '0.0.0',
    apiVersion: 1,
    description: [
      brief,
      usage ? `用法：${usage}` : '事件型插件（无命令，按消息自动触发）',
      `（源码 ${rec.origin}）`,
    ].filter(Boolean).join(' ｜ '),
    author: 'AstrBot',
    entry: 'index.js',
    ui: 'ui.js',
    uiTab: { id: slug, label: name, inline: true },
    priority: 70,
    defaultEnabled: true,
    hooks: ['message'],
    category: 'AstrBot',
    summary: cmdLine ? `命令 ${cmdLine}` : '事件型（无命令）',
    // prefix 放在每个插件自己的配置里：原生插件自治，不必回头依赖市场的配置
    config: { prefix: '/', ...defaults, ...prevCfg },
    deps: { system: ['python3'] },
    setup: '由「插件市场」自动安装。改配置在本卡片内完成，代码在 data/plugins/astrbot-compat/store/。'
  };

  writeJson(path.join(dir, 'manifest.json'), manifest);
  fs.writeFileSync(path.join(dir, 'index.js'), tplIndex(rec.origin), 'utf8');
  fs.writeFileSync(path.join(dir, 'ui.js'), TPL_UI, 'utf8');
  // 使用说明：安装时就从仓库里把 README 抽出来落盘。
  // 不在卡片里现场抓 GitHub —— 断网、仓库删了、README 改了，卡片就会变成空白，
  // 而"装上时它怎么说"才是用户当时需要的那份说明。
  const readme = readmeEarly;
  fs.writeFileSync(path.join(dir, 'usage.md'), readme || '', 'utf8');
  // astrbot.json 也要写归一后的版本号：卡片元数据（/meta）读的是这份，
  // 只归一 manifest 的话卡片上仍会显示 "vv1.1.0"。
  writeJson(path.join(dir, 'astrbot.json'), { ...rec, version: manifest.version, readme: readme ? 'usage.md' : '' });
  return slug;
}

/** 从 store 里的插件源码目录找 README（大小写/中英文都试一遍） */
export function readmeOf(origin) {
  const dir = path.join(STORE_DIR, origin);
  const names = [
    'README.md', 'readme.md', 'Readme.md', 'README.MD',
    'README_CN.md', 'README.zh-CN.md', 'README_zh.md', 'README.zh.md',
    'README.markdown', 'README.rst', 'README.txt',
  ];
  for (const n of names) {
    const p = path.join(dir, n);
    try { if (fs.existsSync(p)) return fs.readFileSync(p, 'utf8'); } catch { /* ignore */ }
  }
  // 有的仓库放在 docs/ 下
  for (const n of names) {
    const p = path.join(dir, 'docs', n);
    try { if (fs.existsSync(p)) return fs.readFileSync(p, 'utf8'); } catch { /* ignore */ }
  }
  return '';
}

/** README 清洗：去徽章图/HTML/注释，压空行，截断。给卡片渲染用，不追求还原排版。 */
export function tidyReadme(md) {
  return String(md || '')
    .replace(/\r\n/g, '\n')
    .replace(/<!--[\s\S]*?-->/g, '')
    .replace(/!\[[^\]]*\]\([^)]*\)/g, '')
    .replace(/<img[^>]*>/gi, '')
    .replace(/<\/?(?:div|p|br|hr|center|table|tr|td|th|thead|tbody|span|a|b|i|u|strong|em|details|summary)\b[^>]*>/gi, '')
    .replace(/\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)/g, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
    .slice(0, 8000);
}

/** 按已装插件重建卡片（补 usage.md / 换新模板），不动 store、不动配置 */
export async function reguide(slug = '') {
  const done = [];
  for (const rec of runtime.installed()) {
    if (slug && rec.slug !== slug) continue;
    let next = { ...rec, readme: tidyReadme(readmeOf(rec.origin)) };

    // 之前探测失败的，重建时补探一次：兼容层补了 shim 之后插件可能已经能跑了，
    // 不该让它一直挂着「加载失败」的旧结论。
    if (!(rec.commands || []).length || rec.loadError) {
      const target = path.join(STORE_DIR, rec.origin);
      if (fs.existsSync(target)) {
        const probed = await probePlugin(rec.origin, target);
        if (probed.info) {
          next = {
            ...next,
            commands: probed.info.commands || [],
            name: probed.info.name || next.name,
            version: probed.info.version || next.version,
            loadError: '',
          };
        } else {
          next = { ...next, loadError: probed.loadError };
        }
      }
    }

    try {
      await materialize(next);
      done.push(rec.slug);
    } catch { /* 单个失败不影响其他 */ }
  }
  return done;
}

// ── 工具函数 ─────────────────────────────────────────────────

/** 从 README 抽「功能一句话 + 用法命令行」，写进卡片描述。
 *
 * 用法行的来源优先级：README 的「使用/用法/命令/指令」小节里以 / 开头的示例行
 * （代码块内外都认）→ 整份 README 里以 / 开头的行 → 探测到的命令表。
 * 命令示例比光秃秃的命令名有用："/梅花 [数字] [问题]" 一眼就知道怎么发。
 */
function usageOf(readme, commands) {
  const text = String(readme || '');
  // 「使用」段：从标题行到下一个同级/更高级标题
  const secRe = /^#{1,4}\s*(使用|用法|命令|指令|如何使用|快速开始)[^\n]*$/m;
  let scope = text;
  const m = text.match(secRe);
  if (m) {
    const start = m.index + m[0].length;
    const rest = text.slice(start);
    const next = rest.match(/^#{1,3}\s+/m);
    scope = next ? rest.slice(0, next.index) : rest;
  }
  const cmdLineRe = /^\/\S/;
  const pick = (s) => {
    const out = [];
    for (let line of s.split('\n')) {
      line = line.replace(/^[>*\-\s]+/, '').replace(/`/g, '').replace(/\s+/g, ' ').trim();
      if (!cmdLineRe.test(line)) continue;
      const item = line.slice(0, 70);
      if (!out.includes(item)) out.push(item);
      if (out.length >= 6) break;
    }
    return out;
  };
  let cmds = pick(scope);
  if (!cmds.length) cmds = pick(text);
  if (!cmds.length) cmds = (commands || []).slice(0, 6).map((c) => '/' + c);
  // 功能一句话：README 第一段非标题、非命令、非徽章的正文
  let brief = '';
  for (let line of text.split('\n')) {
    const t = line.trim();
    if (!t || t.startsWith('#') || t.startsWith('![') || t.startsWith('[')
      || t.startsWith('```') || t.startsWith('|') || t.startsWith('-')
      || cmdLineRe.test(t.replace(/^[>*\-\s]+/, '').replace(/`/g, ''))
      || /^(star|fork|license|version|install|安装|简介|描述)/i.test(t)) continue;
    brief = t.replace(/\[([^\]]*)\]\([^)]*\)/g, '$1')   // [文本](链接) → 文本
      .replace(/[*_`>]/g, '')
      .replace(/^astr\s*bot[\s_]*插件[：:]?\s*/i, '')
      .replace(/^astrbot[\s_-]*plugin[：:]?\s*/i, '')
      .slice(0, 90);
    break;
  }
  return { brief, usage: cmds.join('　') };
}

function untar(tgz, dest) {
  return new Promise((resolve, reject) => {
    const proc = spawn('tar', ['xzf', tgz, '-C', dest, '--strip-components=1'], { stdio: ['ignore', 'ignore', 'pipe'] });
    let err = '';
    proc.stderr.on('data', (t) => { err += t; });
    proc.on('close', (code) => (code === 0 ? resolve() : reject(new Error(`解压失败：${err.slice(0, 300)}`))));
    proc.on('error', reject);
  });
}

function parseMeta(file) {
  const out = {};
  for (const line of fs.readFileSync(file, 'utf8').split('\n')) {
    const m = /^([A-Za-z0-9_-]+)\s*:\s*(.*)$/.exec(line.replace(/\r$/, ''));
    if (!m) continue;
    let v = m[2].trim();
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (v) out[m[1]] = v;
  }
  return out;
}

async function pipInstall(pluginDir, reqPath) {
  // 和探测共用同一把串行闸门：并发跑两个 pip 会争同一个 venv，第二个必失败
  return withProbeLock(() => pipInstallInner(pluginDir, reqPath));
}

async function pipInstallInner(pluginDir, reqPath) {
  const acfg = getConfig().plugins?.['astrbot-compat'] || {};
  if (acfg.autoInstallDeps === false) return '已跳过（市场配置里关闭了依赖安装）';

  // 过滤标准库条目，写成临时 requirements 再装
  let filtered = reqPath;
  try {
    const raw = await fsp.readFile(reqPath, 'utf8');
    const kept = [];
    const dropped = [];
    for (const line of raw.split('\n')) {
      const t = line.trim();
      if (!t || t.startsWith('#')) { kept.push(line); continue; }
      const name = (t.split(/[<>=!~;\s\[]/)[0] || '').toLowerCase().replace(/-/g, '_');
      if (STDLIB.has(name)) { dropped.push(name); continue; }
      if (HEAVY_DEPS.has(name)) { dropped.push(`${name}(超大依赖，本机不装)`); continue; }
      kept.push(line);
    }
    if (dropped.length) {
      filtered = path.join(pluginDir, 'requirements.compat.txt');
      await fsp.writeFile(filtered, kept.join('\n'), 'utf8');
    }
  } catch { /* 过滤失败就按原文件装 */ }

  const pip = path.join(VENV_DIR, 'bin', 'pip');
  if (!fs.existsSync(pip)) {
    await new Promise((resolve, reject) => {
      const p = spawn('python3', ['-m', 'venv', VENV_DIR], { stdio: ['ignore', 'ignore', 'pipe'] });
      let err = '';
      p.stderr.on('data', (t) => { err += t; });
      p.on('close', (c) => (c === 0 ? resolve() : reject(new Error(`创建 venv 失败：${err.slice(0, 200)}`))));
      p.on('error', reject);
    });
  }
  return pipRun(pluginDir, ['install', '-r', filtered]);
}

/** 在 venv 里跑一次 pip，返回 'ok' 或失败原因。 */
function pipRun(pluginDir, args) {
  fs.mkdirSync(VENV_DIR, { recursive: true });
  const pip = path.join(VENV_DIR, 'bin', 'pip');
  return new Promise((resolve) => {
    // --no-cache-dir：本机磁盘紧（批量装插件时 pip 缓存能吃掉几个 G），
    // 缓存对「每个包装一次」的场景也没收益。
    const p = spawn(pip, [...args, '--disable-pip-version-check', '--no-cache-dir', '-q'],
      { cwd: pluginDir, stdio: ['ignore', 'ignore', 'pipe'] });
    let err = '';
    p.stderr.on('data', (t) => { err += t; });
    const timer = setTimeout(() => { try { p.kill(); } catch { /* ignore */ } }, 240000);
    p.on('close', (code) => {
      clearTimeout(timer);
      resolve(code === 0 ? 'ok' : `失败：${err.slice(-200)}`);
    });
    p.on('error', (e) => { clearTimeout(timer); resolve(`失败：${e.message}`); });
  });
}

/**
 * 全局串行闸门：同一时刻只允许一个"探测 + 装依赖"在跑。
 *
 * 一次安装要真起 Python 拿命令表，插件漏声明依赖时还要补装重试，最坏情况
 * 连着起好几个进程。并发装几个插件时这些进程会叠在一起 —— 1 核 1.6G 的小
 * 机器直接被拖到 sshd 发不出 banner。排队执行虽然慢一点，但不会把主机搞挂。
 */
let probeChain = Promise.resolve();
function withProbeLock(fn) {
  const next = probeChain.then(fn, fn);
  probeChain = next.catch(() => {});
  return next;
}

/**
 * 起一次进程拿真实命令表。插件漏声明依赖很常见
 * （用了 aiofiles 却没写进 requirements.txt），
 * 这类 ModuleNotFoundError 自动补装后重试，最多补 2 个模块。
 */
function probePlugin(origin, target) {
  return withProbeLock(() => probePluginInner(origin, target));
}

async function probePluginInner(origin, target) {
  let info = null;
  let loadError = '';
  let deps = '';
  const fixed = [];
  for (let round = 0; round < 3; round += 1) {
    const probe = new Runner(origin, target, () => {});
    try {
      info = await probe.ensure();
      loadError = '';
    } catch (err) {
      info = null;
      loadError = String(err?.message || err);
    } finally {
      // 等进程真的退出再进下一轮，否则上一轮的空转进程会和下一轮叠加
      await probe.kill();
    }
    if (info) break;
    const m = /No module named '([A-Za-z0-9_.]+)'/.exec(loadError);
    if (!m) break;
    const mod = m[1].split('.')[0];
    // HEAVY_DEPS 同样拦补装通道：否则 torch 会从这里溜进来（4G+ CUDA 全家桶）
    if (!mod || fixed.includes(mod) || STDLIB.has(mod) || HEAVY_DEPS.has(mod)) break;
    const r = await pipRun(target, ['install', mod]);
    if (r !== 'ok') break;
    fixed.push(mod);
  }
  if (fixed.length) deps = (deps ? deps + '；' : '') + '补装漏声明依赖：' + fixed.join(', ');
  return { info, loadError, deps };
}

export const runtime = new Runtime();
export { Runner, STDLIB };
