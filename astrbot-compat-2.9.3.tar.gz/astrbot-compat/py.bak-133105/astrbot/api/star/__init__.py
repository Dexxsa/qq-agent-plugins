"""astrbot.api.star —— Star 基类、Context、注册器、StarTools。"""

import inspect
import os


class Star:
    """所有插件的基类。构造函数签名在不同版本插件里不一致，见 runner 的容错。"""

    def __init__(self, context=None, config=None):
        self.context = context
        if config is not None:
            self.config = config

    async def terminate(self):
        return None

    async def initialize(self):
        return None

    async def html_render(self, tmpl=None, data=None, **kw):
        """AstrBot 用它把 HTML 模板渲染成图片（内部依赖 playwright + chromium）。
        服务器上没有浏览器运行环境，明确抛错，让插件走它自己的降级分支；
        静默返回空图会让插件以为成功了，问题更难查。
        """
        raise NotImplementedError('兼容层不支持 HTML 渲染（缺 playwright/chromium）')


class Context:
    """插件与内核交互的入口。

    只实现了 A 档需要的那部分：发消息、取平台名。
    其余（LLM、会话、知识库、Web 面板）一律显式抛错，
    这样插件作者一眼能看出「是兼容层不支持」，而不是数据莫名不对。
    """

    def __init__(self, bridge=None):
        self._bridge = bridge
        self._registered = []
        self._llm_tools = []
        self.platform_manager = _EmptyPlatformManager()
        self.provider_manager = _Unsupported('provider_manager')
        self.conversation_manager = _Unsupported('conversation_manager')
        self.persona_manager = _Unsupported('persona_manager')
        self.kb_manager = _Unsupported('kb_manager')

    async def send_message(self, umo, message_chain):
        """主动发消息。message_chain 是组件列表或单个组件。"""
        chain = message_chain if isinstance(message_chain, (list, tuple)) else [message_chain]
        if self._bridge is not None:
            self._bridge.enqueue(chain)
        return True

    def get_platform(self, *a, **k):
        raise NotImplementedError('兼容层未提供平台对象（event.bot / platform 属于 C 档）')

    def get_all_platforms(self, *a, **k):
        raise NotImplementedError('兼容层未提供平台对象')

    async def llm_generate(self, *a, **k):
        raise NotImplementedError('兼容层暂未桥接 LLM（属于 B 档能力）')

    def get_provider(self, *a, **k):
        raise NotImplementedError('兼容层暂未桥接 LLM 提供方（属于 B 档能力）')

    # 以下两个是"查询"类接口，故意返回 None 而不是抛错。
    # 很多插件是「先 yield 命令结果 → 再调 LLM 补充」，若这里抛错，
    # 前半段已经算好的结果会跟着整条丢弃，用户什么都拿不到。返回 None 后
    # 插件自己会走「模型不可用」分支（通常包在 try 里），命令结果照常发出。
    def get_provider_by_id(self, *a, **k):
        return None

    def get_using_provider(self, *a, **k):
        return None

    def register_web_api(self, *a, **k):
        raise NotImplementedError('兼容层未提供 Web 面板（属于 C 档能力）')

    def register_task(self, *a, **k):
        raise NotImplementedError('兼容层未提供定时任务（属于 B 档能力）')

    def register_llm_tool(self, *a, **k):
        # 不抛错：很多插件在 __init__ 里登记工具，一抛整个插件就装不上。
        # 工具本身不会交给模型（未桥接 LLM），但插件自己的命令仍然可用。
        self._llm_tools.extend(a)
        return True

    def add_llm_tools(self, *tools):
        self._llm_tools.extend(tools)
        return True

    def add_llm_tool(self, tool):
        self._llm_tools.append(tool)
        return True


class _Unsupported:
    """占位对象：一被使用就抛错，并说明所属档位。"""

    def __init__(self, name):
        self._name = name

    def __getattr__(self, item):
        raise NotImplementedError('兼容层未提供 %s.%s' % (self._name, item))


class _EmptyPlatformManager:
    """空的平台管理器。

    事件型插件（入群欢迎、消息监听）习惯用
    ``context.platform_manager.get_insts()`` 遍历已接入的平台去取 bot client。
    这里返回空列表，让它们走「当前没有可用平台」的正常分支 ——
    总比每次遍历都抛 AttributeError、在日志里刷一屏异常要好。
    """

    def get_insts(self, *a, **k):
        return []

    def get_inst(self, *a, **k):
        return None

    def __iter__(self):
        return iter(())

    def __len__(self):
        return 0


def register(*_args, **_kwargs):
    """@register(...) 注册装饰器。兼容层里是空操作 —— 类靠子类关系自动发现。"""

    def deco(cls):
        return cls

    if _args and inspect.isclass(_args[0]):
        return _args[0]
    return deco


class StarTools:
    """插件常用的工具方法。"""

    @staticmethod
    def get_data_dir(plugin_name=''):
        """返回 **pathlib.Path** —— 真 AstrBot 就是 Path，
        插件普遍写成 get_data_dir("x") / "file.json"，返回 str 会直接 TypeError。
        """
        from pathlib import Path

        root = Path(os.environ.get('ASTRBOT_DATA_DIR', os.getcwd()))
        path = root / plugin_name if plugin_name else root
        try:
            path.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        return path

    @staticmethod
    def get_config_path(*a, **k):
        from pathlib import Path

        return Path(os.environ.get('ASTRBOT_DATA_DIR', os.getcwd()))

    @staticmethod
    def get_astrbot_version():
        return '4.0.0'

    @staticmethod
    async def create_target(*a, **k):
        raise NotImplementedError('兼容层未提供 create_target')


__all__ = ['Star', 'Context', 'register', 'StarTools']
