"""astrbot.api.event —— 事件对象与 filter 装饰器。"""

from .. import message_components as mc  # noqa: F401


class EventMessageType:
    ALL = 'all'
    GROUP_MESSAGE = 'group'
    FRIEND_MESSAGE = 'friend'
    PRIVATE_MESSAGE = 'private'
    OTHER_MESSAGE = 'other'


class PermissionType:
    ADMIN = 'admin'
    MEMBER = 'member'
    ALL = 'all'


class MessageEventResult:
    """handler 里 yield 的东西。等同于一条待发送的消息链。"""

    def __init__(self, chain=None):
        self.chain = list(chain or [])

    def message(self, text):
        self.chain.append(mc.Plain(text))
        return self

    def use_t2i(self, *_a, **_k):
        return self

    def to_actions(self):
        return [c.to_dict() if hasattr(c, 'to_dict') else {'type': 'plain', 'text': str(c)}
                for c in self.chain]


MessageChain = MessageEventResult


class _Sender:
    """message_obj.sender 的形状。"""

    def __init__(self, user_id='', nickname=''):
        self.user_id = str(user_id)
        self.nickname = nickname or str(user_id)


class _AstrBotMessage:
    """message_obj 的形状（插件常用 event.message_obj.message 拿组件）。"""

    def __init__(self, text='', components=None, sender=None, session_id='', message_id='',
                 group_id='', self_id=''):
        self.message_str = text
        self.message = list(components or [])
        self.sender = sender or _Sender()
        self.session_id = session_id
        self.message_id = message_id
        self.group_id = str(group_id) if group_id else ''
        self.self_id = str(self_id) if self_id else ''
        self.raw_message = None

    def get_plain_text(self):
        """纯文本内容。插件用它取整条消息的文字部分（会跳过图片、表情）。"""
        parts = []
        for comp in self.message:
            text = getattr(comp, 'text', None)
            if text:
                parts.append(str(text))
        return ''.join(parts) if parts else (self.message_str or '')


class AstrMessageEvent:
    def __init__(self, *, text='', chat=None, user=None, self_id='', message_id='',
                 components=None, is_admin=False, bridge=None):
        chat = chat or {}
        user = user or {}
        self._bridge = bridge
        self._stopped = False
        self._results = []
        self.message_str = text
        self.unified_msg_origin = '%s:%s' % (chat.get('kind') or 'group', chat.get('id') or '')
        self.role = PermissionType.ADMIN if is_admin else PermissionType.MEMBER
        depth = 0
        self._depth = depth
        sender = _Sender(user.get('id', ''), user.get('name', ''))
        self.message_obj = _AstrBotMessage(
            text=text,
            components=components or [],
            sender=sender,
            session_id=self.unified_msg_origin,
            message_id=message_id or '',
            group_id=chat.get('id') if (chat.get('kind') == 'group') else '',
            self_id=self_id,
        )
        self._chat = chat
        self._user = user
        self._self_id = str(self_id or '')

    # ── 取值 ─────────────────────────────────────────
    def get_message_str(self):
        return self.message_str

    def get_messages(self):
        return self.message_obj.message

    def get_sender_id(self):
        return self.message_obj.sender.user_id

    def get_sender_name(self):
        return self.message_obj.sender.nickname

    def get_group_id(self):
        return self.message_obj.group_id or None

    def get_self_id(self):
        return self._self_id

    def get_session_id(self):
        return self.unified_msg_origin

    def get_platform_name(self):
        return 'aiocqhttp'

    def get_platform_id(self):
        return 'aiocqhttp-compat'

    def is_admin(self):
        return self.role == PermissionType.ADMIN

    def is_private_chat(self):
        return self._chat.get('kind') == 'private'

    def is_group_chat(self):
        return self._chat.get('kind') == 'group'

    # ── 结果构造 ─────────────────────────────────────
    def plain_result(self, text):
        return MessageEventResult([mc.Plain(text)])

    def image_result(self, url):
        return MessageEventResult([mc.Image(url=url)])

    def chain_result(self, chain):
        return MessageEventResult(list(chain))

    def make_result(self):
        return MessageEventResult()

    # ── 直接发送 / 中断 ──────────────────────────────
    async def send(self, payload):
        chain = payload.chain if isinstance(payload, MessageEventResult) else (
            payload if isinstance(payload, (list, tuple)) else [mc.Plain(str(payload))])
        if self._bridge is not None:
            self._bridge.enqueue(list(chain))
        return True

    # ── LLM 流程控制 ─────────────────────────────────
    def should_call_llm(self, flag=True):
        """AstrBot 用它决定处理完后要不要继续走大模型。
        兼容层里命令命中就由插件接管，这里只记录意图，不影响后续流程。"""
        self._call_llm = bool(flag)
        return None

    def is_call_llm(self):
        return getattr(self, '_call_llm', False)

    # ── 事件附加数据（插件之间传递临时值用） ─────────
    def set_extra(self, key, value):
        if not hasattr(self, '_extras'):
            self._extras = {}
        self._extras[key] = value

    def get_extra(self, key=None, default=None):
        extras = getattr(self, '_extras', {})
        return extras.get(key, default) if key is not None else extras

    # ── 常用属性 ─────────────────────────────────────
    @property
    def is_at_or_wake_command(self):
        # 能走到处理函数就说明这条消息已经"叫到"机器人了
        return True

    @property
    def raw_message(self):
        return getattr(self.message_obj, 'raw_message', self.message_str)

    def get_message_obj(self):
        return self.message_obj

    def get_message(self):
        """整条消息对象。`event.get_message().get_plain_text()` 是常见写法。"""
        return self.message_obj

    def get_plain_text(self):
        return self.message_obj.get_plain_text()

    def get_messages(self):  # noqa: F811  (保持与旧版同名，覆盖上面那个也可)
        return self.message_obj.message

    def set_result(self, result):
        self._results.append(result)

    def get_result(self):
        return self._results[-1] if self._results else None

    def stop_event(self):
        self._stopped = True

    def is_stopped(self):
        return self._stopped

    def __repr__(self):
        return '<AstrMessageEvent %s %s: %r>' % (self.unified_msg_origin, self.get_sender_id(), self.message_str[:30])


class _CommandGroup:
    """命令组对象。被 `@filter.command_group(...)` 装饰后，插件用它登记子命令。"""

    def __init__(self, name, desc=None, parent=None):
        self.name = name
        self.desc = desc
        self.parent = parent

    def _full(self, sub=None):
        parts = [p for p in (self.parent, self.name) if p]
        if sub:
            parts.append(sub)
        return ' '.join(parts)

    def command(self, name=None, alias=None, desc=None, **_kw):
        full = self._full(name) if name else self._full()
        aliases = alias if isinstance(alias, (list, tuple)) else ([alias] if alias else [])

        def deco(fn):
            items = getattr(fn, '__astr_filters__', None)
            if items is None:
                items = []
                setattr(fn, '__astr_filters__', items)
            items.append({
                'kind': 'command',
                'name': full,
                'alias': [self._full(a) for a in aliases],
                'desc': desc or self.desc,
            })
            return fn

        return deco

    def group(self, name, desc=None):
        return _CommandGroup(name, desc, parent=self._full())

    def __call__(self, *a, **k):
        # 组本身不是 handler，真 AstrBot 里它也只是个空壳
        return None

    def __repr__(self):
        return '<CommandGroup %s>' % self.name


class _Filter:
    """filter 命名空间：所有装饰器都只是往函数上挂元数据，真正的匹配在 runner 里做。"""

    EventMessageType = EventMessageType
    PermissionType = PermissionType
    MessageEventResult = MessageEventResult
    MessageChain = MessageChain
    AstrMessageEvent = AstrMessageEvent

    @staticmethod
    def _attach(fn, item):
        items = getattr(fn, '__astr_filters__', None)
        if items is None:
            items = []
            setattr(fn, '__astr_filters__', items)
        items.append(item)
        return fn

    def command(self, name, alias=None, desc=None, **_kw):
        aliases = alias if isinstance(alias, (list, tuple)) else ([alias] if alias else [])

        def deco(fn):
            return self._attach(fn, {'kind': 'command', 'name': str(name), 'alias': [str(a) for a in aliases], 'desc': desc})

        return deco

    def command_group(self, name, desc=None, **_kw):
        """命令组。

        真 AstrBot 的用法是：

            @filter.command_group("天气")
            def weather(self): ...

            @weather.command("今天")
            async def today(self, event): ...

        也就是被装饰的函数会被**替换成一个组对象**，后面用 `组.command()`
        继续登记子命令。所以这里不能只挂元数据就返回原函数，
        否则插件会在 `@weather.command` 这一行炸掉（AttributeError）。
        """
        def deco(fn):
            return _CommandGroup(str(name), desc)

        return deco

    def command_group_entry(self, name, desc=None):
        return _CommandGroup(str(name), desc)

    def event_message_type(self, message_type, desc=None):
        def deco(fn):
            return self._attach(fn, {'kind': 'event_message_type', 'value': message_type, 'desc': desc})

        return deco

    def permission_type(self, permission_type, desc=None):
        def deco(fn):
            return self._attach(fn, {'kind': 'permission_type', 'value': permission_type, 'desc': desc})

        return deco

    def regex(self, pattern, desc=None):
        def deco(fn):
            return self._attach(fn, {'kind': 'regex', 'pattern': pattern, 'desc': desc})

        return deco

    def on_llm_request(self, *_a, **_k):
        def deco(fn):
            return self._attach(fn, {'kind': 'unsupported', 'what': 'on_llm_request'})

        return deco

    def llm_tool(self, name=None, desc=None):
        def deco(fn):
            return self._attach(fn, {'kind': 'unsupported', 'what': 'llm_tool', 'name': name})

        return deco

    def on_astrbot_loaded(self, *_a, **_k):
        def deco(fn):
            return self._attach(fn, {'kind': 'hook', 'what': 'on_astrbot_loaded'})

        return deco

    def on_decorating_result(self, *_a, **_k):
        """消息即将发出前的最后一道钩子。

        图片审查、敏感词过滤、回复改写类插件都挂在这里：拿 `event.get_result()`
        改 `result.chain`，改完的链才会真正发出去。runner 在拼完动作后调用它。
        """
        def deco(fn):
            return self._attach(fn, {'kind': 'decorating_result', 'what': 'on_decorating_result'})

        return deco

    def on_llm_response(self, *_a, **_k):
        def deco(fn):
            return self._attach(fn, {'kind': 'hook', 'what': 'on_llm_response'})

        return deco

    def on_waiting_llm_request(self, *_a, **_k):
        def deco(fn):
            return self._attach(fn, {'kind': 'hook', 'what': 'on_waiting_llm_request'})

        return deco

    def on_platform_loaded(self, *_a, **_k):
        def deco(fn):
            return self._attach(fn, {'kind': 'hook', 'what': 'on_platform_loaded'})

        return deco

    def on_after_message_sent(self, *_a, **_k):
        def deco(fn):
            return self._attach(fn, {'kind': 'hook', 'what': 'on_after_message_sent'})

        return deco

    def after_message_sent(self, *_a, **_k):
        """别名：`@filter.after_message_sent()`（清理临时文件之类）。"""
        return self.on_after_message_sent(*_a, **_k)


filter = _Filter()


__all__ = ['filter', 'AstrMessageEvent', 'EventMessageType', 'PermissionType',
           'MessageEventResult', 'MessageChain', '_AstrBotMessage', '_Sender']
