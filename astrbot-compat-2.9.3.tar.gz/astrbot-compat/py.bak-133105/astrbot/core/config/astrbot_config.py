"""`from astrbot.core.config.astrbot_config import AstrBotConfig` 的落点。"""

from astrbot.api import AstrBotConfig  # noqa: F401

__all__ = ['AstrBotConfig']
