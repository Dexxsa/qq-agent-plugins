"""astrbot.core.config —— 旧版路径的配置模块。

插件里两种写法都很常见：

    from astrbot.core.config.astrbot_config import AstrBotConfig
    from astrbot.core.config import AstrBotConfig

真 AstrBot 里 AstrBotConfig 定义在 astrbot.core.config.astrbot_config，
再由 astrbot.api 再导出一次。兼容层只有 api 那一份实现，这里做转发即可
（只能是单向转发：core → api，反向会在 import 期成环）。
"""

from astrbot.api import AstrBotConfig  # noqa: F401

__all__ = ['AstrBotConfig']
