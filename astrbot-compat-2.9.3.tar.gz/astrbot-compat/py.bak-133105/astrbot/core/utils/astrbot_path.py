"""路径工具（astrbot.core.utils.astrbot_path）。

插件通常用它拿数据目录来存缓存/配置：

    from astrbot.core.utils.astrbot_path import get_astrbot_data_path
"""

import os

__all__ = ['get_astrbot_data_path', 'get_astrbot_path', 'get_astrbot_plugin_path',
           'get_astrbot_config_path']


def get_astrbot_data_path():
    """数据根目录。runner 启动时会把 ASTRBOT_DATA_DIR 指到插件自己的 data 目录。"""
    env = os.environ.get('ASTRBOT_DATA_DIR')
    if env:
        return env
    path = os.path.join(os.getcwd(), 'data')
    os.makedirs(path, exist_ok=True)
    return path


def get_astrbot_path():
    return os.path.abspath(os.path.join(get_astrbot_data_path(), os.pardir))


def get_astrbot_plugin_path(name=''):
    root = os.path.join(get_astrbot_path(), 'plugins')
    return os.path.join(root, name) if name else root


def get_astrbot_config_path(*_a, **_k):
    return os.path.join(get_astrbot_path(), 'config')
