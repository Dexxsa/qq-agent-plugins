"""astrbot.core.utils —— 插件常用的工具模块集合。

目前只补了真正影响「能不能跑起来」的两块：

  · session_waiter —— 多轮对话等待器（抽卡、占卜、点单类插件的标配）
  · astrbot_path   —— 数据目录/插件目录取值

刻意不做 `from astrbot.core.utils import *` 式的兜底：把不存在的模块
伪装成"能用"，只会把报错推迟到运行中期，插件反而更难排查。
"""

__all__ = []
