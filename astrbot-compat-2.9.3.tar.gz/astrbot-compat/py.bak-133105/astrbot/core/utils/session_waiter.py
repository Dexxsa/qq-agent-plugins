"""多轮对话等待器（astrbot.core.utils.session_waiter）。

插件里的典型写法：

    from astrbot.core.utils.session_waiter import session_waiter, SessionController

    @session_waiter(timeout=60)
    async def waiter(controller: SessionController, event: AstrMessageEvent):
        ...
        controller.keep(timeout=60, reset_timeout=True)   # 继续等下一句
        # 或 controller.stop()                             # 结束

    await waiter(event)

真 AstrBot 里这个装饰器会把「下一条同会话消息」送回同一个协程。兼容层的
进程模型是「一条消息进、一批动作出」，中途没有二次投递通道，所以这里做
**单轮降级**：第一次调用照常执行（用户能看到回复），controller.keep() 被
记录但不会真的再等下去，并在插件日志里留一行提示。

为什么不直接抛 NotImplementedError：
    抛错会让整条命令的结果一起丢掉（插件的回复往往在 keep() 之前已经 yield），
    用户看到的就是"没反应"。单轮降级至少把第一段结果发出去。
"""

import functools
import sys

__all__ = ['session_waiter', 'SessionController', 'SessionFilter']


def _note_usage():
    """给 runner 留个记号，好在插件卡片上提示"多轮会话按单轮处理"。"""
    try:
        import astrbot
        astrbot._compat_session_waiter_used = True
    except Exception:
        pass


class SessionFilter:
    """会话过滤器。真实现里可以设条件决定是否接受下一条消息。

    参数兼容两种写法：`SessionFilter(fn)` 或 `SessionFilter(filter_func=fn)`。
    """

    def __init__(self, filter_func=None, **_kw):
        self.filter_func = filter_func or _kw.get('func')

    def filter(self, event):
        if not self.filter_func:
            return True
        try:
            return bool(self.filter_func(event))
        except Exception:
            return False

    def __call__(self, event):
        return self.filter(event)


class SessionController:
    """会话控制权。插件通过 keep()/stop() 表达"还要不要继续听"。"""

    def __init__(self, timeout=None, handler=None):
        self.timeout = timeout
        self.handler = handler
        self.history_chains = []
        self._stopped = False
        self._kept = False

    def keep(self, timeout=None, reset_timeout=False):
        self._kept = True
        self._stopped = False
        if timeout is not None:
            self.timeout = timeout
        return True

    def stop(self):
        self._stopped = True
        self._kept = False
        return True

    def is_stopped(self):
        return self._stopped

    def get_history_chains(self):
        return list(self.history_chains)

    def __repr__(self):
        return '<SessionController timeout=%s kept=%s stopped=%s>' % (
            self.timeout, self._kept, self._stopped)


def session_waiter(timeout=60, record_history_chains=False, session_filter=None):
    """装饰器：把 `async def f(controller, event)` 变成 `await f(event)`。"""

    def decorator(func):
        _note_usage()

        @functools.wraps(func)
        async def wrapper(event, *args, **kwargs):
            controller = SessionController(timeout=timeout, handler=func)
            try:
                await func(controller, event, *args, **kwargs)
            except Exception as exc:
                sys.stderr.write('[compat] session_waiter 内抛错: %s: %s\n'
                                 % (type(exc).__name__, exc))
                sys.stderr.flush()
                raise
            if controller._kept and not controller._stopped:
                sys.stderr.write(
                    '[compat] 该插件想继续等待下一条消息（session_waiter），'
                    '兼容层按单轮处理：本次回复已发出，后续消息不会再进这个会话\n')
                sys.stderr.flush()
            return None

        return wrapper

    return decorator
