"""astrbot.core.provider —— 兼容 `from astrbot.core.provider.entities import ProviderRequest`。

这是 AstrBot 4.x 内部模块路径，部分插件直接从这里取 ProviderRequest。
统一转发到 api 层，保证 `isinstance` 判断两边是同一个类。
"""

from ...api.provider import LLMResponse, Provider, ProviderRequest, ProviderType

from . import entities  # noqa: F401  （保持子模块可导入）

__all__ = ['Provider', 'ProviderType', 'LLMResponse', 'ProviderRequest', 'entities']
