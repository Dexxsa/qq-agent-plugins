"""`astrbot.core.provider.entities` —— 只放实体类，转发到 api.provider。

两个路径必须是**同一个类对象**：插件里常见
`from astrbot.core.provider.entities import ProviderRequest` 之后做 isinstance 判断，
如果各自定义一份，判断恒为 False，行为会莫名其妙地不通。
"""

from ...api.provider import LLMResponse, ProviderRequest

__all__ = ['ProviderRequest', 'LLMResponse']
