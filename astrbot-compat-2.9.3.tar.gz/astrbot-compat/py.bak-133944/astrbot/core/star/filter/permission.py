"""`astrbot.core.star.filter.permission` —— 兼容旧导入路径。

部分插件写的是单数形式的模块名（permission），另一批写 permission_type。
两个路径都指向同一份实现，避免「同一个装饰器两种行为」。
"""

from ....api.event import PermissionType, filter

permission_type = filter.permission_type

__all__ = ['permission_type', 'PermissionType']
