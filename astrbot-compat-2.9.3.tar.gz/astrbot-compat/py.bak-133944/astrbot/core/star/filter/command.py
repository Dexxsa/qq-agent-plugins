from ....api.event import filter

# 真 AstrBot 里 CommandFilter 是「命令过滤器」类型，插件常拿它做 isinstance 判断。
# 这里用 filter 对象的类型顶上，语义上等价于「装饰器命名空间」。
CommandFilter = type(filter)


class GreedyStr(str):
    """「吃掉剩余全部参数」的类型标注。

    插件这么写，是希望 `@cmd 你好 世界` 里的 `你好 世界` 整体进一个参数，
    而不是按空格切成两个。runner 看到这个标注会把剩余参数用空格拼回来，
    所以这里只要是个 str 子类即可（继承 str 让插件内部的字符串操作照常可用）。
    """


command = filter.command

__all__ = ['command', 'CommandFilter', 'GreedyStr']
