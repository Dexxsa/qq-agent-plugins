"""astrbot.api.provider —— LLM 提供方的形状。

真正的调用能力仍属 B 档（兼容层暂不桥接 provider），但**数据形状必须齐**：
插件在 `@filter.on_llm_request` 里做的是「拿到 req，改 prompt / 加图片 / 拼上下文」，
只要这些字段在，插件就能正常装载并跑通前半段，而不是 ImportError 直接挂掉。
"""


class Provider:
    def __init__(self, *a, **k):
        raise NotImplementedError('兼容层未桥接 LLM 提供方（属于 B 档能力）')


class ProviderType:
    CHAT_COMPLETION = 'chat_completion'
    TEXT_TO_SPEECH = 'text_to_speech'
    SPEECH_TO_TEXT = 'speech_to_text'
    EMBEDDING = 'embedding'


class LLMResponse:
    def __init__(self, role='assistant', completion_text=''):
        self.role = role
        self.completion_text = completion_text


class ProviderRequest:
    """一次 LLM 请求的载荷。

    字段名对齐 AstrBot 4.x：prompt / contexts / system_prompt / image_urls / func_tool。
    刻意给全默认值 —— 插件里有大量 `req.system_prompt += '...'` 这类原地拼接，
    字段缺失会抛 AttributeError，比「功能不完整」更难排查。
    """

    def __init__(self, prompt='', contexts=None, system_prompt='', image_urls=None,
                 func_tool=None, session_id='', conversation=None, **extra):
        self.prompt = prompt
        self.contexts = list(contexts or [])
        self.system_prompt = system_prompt
        self.image_urls = list(image_urls or [])
        self.func_tool = func_tool
        self.session_id = session_id
        self.conversation = conversation
        for key, value in extra.items():
            setattr(self, key, value)

    def __repr__(self):
        return '<ProviderRequest prompt=%r contexts=%d images=%d>' % (
            str(self.prompt)[:40], len(self.contexts), len(self.image_urls))


__all__ = ['Provider', 'ProviderType', 'LLMResponse', 'ProviderRequest']
