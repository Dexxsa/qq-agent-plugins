"""`astrbot.api.event.filter` 子模块。

## 为什么需要这个文件

新版插件（以及不少 2025 年后的仓库）按**模块路径**导入装饰器：

    from astrbot.api.event.filter import command, llm_tool, PlatformAdapterType

而老插件写的是：

    from astrbot.api.event import filter
    @filter.command("xx")

兼容层里 `filter` 本来是 `astrbot.api.event` 包里的一个**实例**。一旦有人按模块路径导入，
Python 会把包的 `filter` 属性替换成这个模块对象 —— 之后 `from astrbot.api.event import filter`
拿到的是模块。所以本模块必须把实例上的装饰器**全部再导出**，两种写法才不会行为分叉。

实现上只做转发：所有装饰器都指向 `_FILTER` 这一个实例，
`__astr_filters__` 元数据格式和 runner 完全一致，不存在第二套实现。
"""

from astrbot.api.event import (  # noqa: F401
    _FILTER,
    AstrMessageEvent,
    EventMessageType,
    MessageEventResult,
    PermissionType,
    PlatformAdapterType,
)

# 与 `from astrbot.api.event import filter` 保持同一对象
filter = _FILTER

# 把实例上的公有可调用成员逐个搬进来（command / command_group / llm_tool / ...）
_exported = []
for _name in dir(_FILTER):
    if _name.startswith('_'):
        continue
    _value = getattr(_FILTER, _name)
    if callable(_value):
        globals()[_name] = _value
        _exported.append(_name)

__all__ = sorted(set(_exported + [
    'filter', 'AstrMessageEvent', 'EventMessageType', 'MessageEventResult',
    'PermissionType', 'PlatformAdapterType',
]))

del _name, _value
