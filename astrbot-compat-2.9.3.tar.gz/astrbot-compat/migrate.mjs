// 把老版本（installed.json 管列表）里已经装好的 AstrBot 插件，
// 迁移成 plugins/ab-<slug>/ 的原生插件。跑一次就够，可重复执行（幂等）。
import fs from 'node:fs';
import path from 'node:path';

import { DATA_ROOT, STORE_DIR, readJson, materialize } from './runtime.js';

const oldPath = path.join(DATA_ROOT, 'installed.json');
const old = readJson(oldPath, { items: {} });
const items = Object.entries(old.items || {});

if (!items.length) {
  console.log('installed.json 为空或不存在，改扫 store 目录');
  let names = [];
  try {
    names = fs.readdirSync(STORE_DIR, { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => d.name);
  } catch { /* 没有 store */ }
  for (const name of names) items.push([name, { name, commands: [] }]);
}

let done = 0;
for (const [origin, rec] of items) {
  const store = path.join(STORE_DIR, origin);
  if (!fs.existsSync(store)) {
    console.log(`跳过 ${origin}：源码目录不存在`);
    continue;
  }
  const schema = readJson(path.join(store, '_conf_schema.json'), {});
  const saved = {
    origin,
    repo: rec.repo || '',
    branch: rec.branch || '',
    name: rec.name || origin,
    version: rec.version || '0.0.0',
    commands: rec.commands || [],
    schema,
    deps: rec.deps || '',
    loadError: rec.error || '',
    installedAt: rec.installedAt || new Date().toISOString(),
  };
  const slug = await materialize(saved);
  console.log(`迁移 ${origin} -> plugins/${slug}（命令 ${(saved.commands || []).join(',') || '无'}）`);
  done += 1;
}
console.log(`完成：${done} 个插件已生成为原生插件。重启 qq-agent 后由 loadAll 自动装载。`);
