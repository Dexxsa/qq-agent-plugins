"""astrbot.api —— 兼容层的公共入口。"""

import logging
import sys


class _Logger:
    """把插件的日志转发到 stderr，由 Node 侧收进插件日志。

    不走 logging 的 handler 配置：插件里的 logger 调用量很大，
    交给 logging 会带上默认格式和多余前缀，反而不好读。
    """

    def __init__(self):
        self.level = logging.INFO
        self._extra = {}

    def _emit(self, level, msg, *args, **kwargs):
        text = str(msg)
        if args:
            try:
                text = text % args
            except Exception:
                text = text + ' ' + ' '.join(str(a) for a in args)
        try:
            sys.stderr.write('[py:%s] %s\n' % (level, text))
            sys.stderr.flush()
        except Exception:
            pass

    def debug(self, msg, *a, **k):
        self._emit('debug', msg, *a)

    def info(self, msg, *a, **k):
        self._emit('info', msg, *a)

    def warning(self, msg, *a, **k):
        self._emit('warn', msg, *a)

    warn = warning

    def error(self, msg, *a, **k):
        self._emit('error', msg, *a)

    def exception(self, msg, *a, **k):
        self._emit('error', msg, *a)

    def critical(self, msg, *a, **k):
        self._emit('error', msg, *a)

    def setLevel(self, *_a, **_k):
        return None

    def addHandler(self, *_a, **_k):
        return None


logger = _Logger()


class AstrBotConfig(dict):
    """插件配置。行为对齐 AstrBot：字典 + 属性访问 + save_config()。

    值来自两处合并：插件目录的 _conf_schema.json 里的 default，
    加上用户在控制台面板里改过的值（后者覆盖前者）。
    """

    def __init__(self, data=None, schema=None):
        super().__init__(data or {})
        object.__setattr__(self, '_schema', schema or {})

    def __getattr__(self, name):
        try:
            return self[name]
        except KeyError:
            raise AttributeError(name)

    def __setattr__(self, name, value):
        if name.startswith('_'):
            object.__setattr__(self, name, value)
        else:
            self[name] = value

    def save_config(self):
        # 兼容层不落盘：配置由 Node 侧面板管理，这里只做内存态
        return True

    @property
    def schema(self):
        return object.__getattribute__(self, '_schema')


__all__ = ['logger', 'AstrBotConfig']


# ── 顶层再导出几个装饰器 ────────────────────────────────────
# 有些插件写成 `from astrbot.api import llm_tool` 直接用装饰器，
# 不经过 astrbot.api.event.filter。这里补上，免得 ImportError。
from . import event as _event_mod  # noqa: E402

llm_tool = _event_mod.filter.llm_tool
on_llm_request = _event_mod.filter.on_llm_request
on_astrbot_loaded = _event_mod.filter.on_astrbot_loaded

__all__ = ['logger', 'AstrBotConfig', 'llm_tool', 'on_llm_request', 'on_astrbot_loaded']
