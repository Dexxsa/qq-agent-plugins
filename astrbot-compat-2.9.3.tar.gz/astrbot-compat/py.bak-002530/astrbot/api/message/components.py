"""astrbot.api.message.components —— 转发到 astrbot.api.message_components。

历史上有插件写 ``from astrbot.api.message.components import ...``（多一层 message），
AstrBot 里并没有这个路径，但既然是同一批类，转发一下不会有害。
"""

from ..message_components import *  # noqa: F401,F403
from .. import message_components as _mc

__all__ = [n for n in dir(_mc) if not n.startswith('_')]
