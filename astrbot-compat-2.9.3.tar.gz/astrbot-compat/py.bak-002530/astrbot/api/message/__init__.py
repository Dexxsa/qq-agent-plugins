"""astrbot.api.message —— 见 components.py。"""

from .. import message_components as _mc


def __getattr__(name):
    if hasattr(_mc, name):
        return getattr(_mc, name)
    raise AttributeError(f"module 'astrbot.api.message' has no attribute {name!r}")
