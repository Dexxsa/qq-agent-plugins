"""astrbot.api.provider —— 只提供形状，不提供能力（B 档才桥接 LLM）。"""


class Provider:
    def __init__(self, *a, **k):
        raise NotImplementedError('兼容层未桥接 LLM 提供方（属于 B 档能力）')


class ProviderType:
    CHAT_COMPLETION = 'chat_completion'
    TEXT_TO_SPEECH = 'text_to_speech'
    SPEECH_TO_TEXT = 'speech_to_text'
    EMBEDDING = 'embedding'


class LLMResponse:
    def __init__(self, role='assistant', completion_text=''):
        self.role = role
        self.completion_text = completion_text


__all__ = ['Provider', 'ProviderType', 'LLMResponse']
