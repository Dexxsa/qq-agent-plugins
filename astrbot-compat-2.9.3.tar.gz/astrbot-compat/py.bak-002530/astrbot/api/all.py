"""astrbot.api.all —— 插件里 `from astrbot.api.all import *` 的入口。"""

from . import AstrBotConfig, logger
from .event import (AstrMessageEvent, EventMessageType, MessageChain,
                    MessageEventResult, PermissionType, filter)
from .message_components import (At, Component, Face, File, Forward, Image, Json,
                                 Node, Plain, Record, Reply, Video)
from .star import Context, Star, StarTools, register

# 真 AstrBot 的 astrbot.api.all 会把 filter 里的装饰器平铺导出。
# 插件普遍写成 `from astrbot.api.all import *` 之后直接 `@command("x")`，
# 少这几个就会在 import 阶段 NameError。
command = filter.command
command_group = filter.command_group
event_message_type = filter.event_message_type
permission_type = filter.permission_type
regex = filter.regex
llm_tool = filter.llm_tool
on_llm_request = filter.on_llm_request
on_astrbot_loaded = filter.on_astrbot_loaded

__all__ = [
    'AstrBotConfig', 'logger',
    'Star', 'Context', 'register', 'StarTools',
    'filter', 'AstrMessageEvent', 'EventMessageType', 'PermissionType',
    'MessageEventResult', 'MessageChain',
    'command', 'command_group', 'event_message_type', 'permission_type',
    'regex', 'llm_tool', 'on_llm_request', 'on_astrbot_loaded',
    'Component', 'Plain', 'Image', 'At', 'Reply', 'Node', 'Face',
    'Record', 'Video', 'File', 'Forward', 'Json',
]
