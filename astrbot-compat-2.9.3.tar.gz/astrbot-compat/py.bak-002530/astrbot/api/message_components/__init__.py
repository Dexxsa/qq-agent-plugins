"""astrbot.api.message_components —— 消息组件。"""

import base64
import mimetypes
import os
import urllib.request


class Component:
    type = 'component'

    def __init__(self, **kwargs):
        self.data = dict(kwargs)

    def to_dict(self):
        return {'type': self.type, **{k: v for k, v in self.data.items() if v is not None}}

    def __repr__(self):
        return '<%s %s>' % (type(self).__name__, self.data)


class Plain(Component):
    type = 'plain'

    def __init__(self, text=''):
        super().__init__()
        self.text = text if text is not None else ''

    def to_dict(self):
        return {'type': 'plain', 'text': self.text}

    def __str__(self):
        return str(self.text)


class Image(Component):
    type = 'image'

    def __init__(self, file=None, url=None, path=None, **_kw):
        super().__init__()
        self.file = file or path
        self.url = url
        self._b64 = _kw.get('base64')
        # base64 与 url 二选一：OneBot 的 image 段接受 base64:// 前缀，
        # 所以直接折进 url，后续序列化只走一条路径。
        if self._b64 and not self.url:
            self.url = 'base64://' + str(self._b64)

    @classmethod
    def fromURL(cls, url):
        return cls(url=url)

    @classmethod
    def fromFileSystem(cls, path):
        return cls(file=path)

    @classmethod
    def fromBase64(cls, data):
        """AstrBot 用它把内存里的图片直接当消息发（很多出图插件依赖）。"""
        if isinstance(data, (bytes, bytearray)):
            import base64 as _b64mod
            data = _b64mod.b64encode(bytes(data)).decode('ascii')
        s = str(data).strip()
        if s.startswith('data:'):
            s = s.split(',', 1)[-1]
        return cls(url='base64://' + s)

    def to_dict(self):
        out = {'type': 'image'}
        if self.url:
            out['url'] = self.url
        if self.file:
            out['file'] = self.file
        return out

    @property
    def src(self):
        return self.url or self.file

    async def convert_to_base64(self):
        if self._b64:
            return self._b64
        source = self.file or self.url
        if not source:
            return ''
        if str(source).startswith(('http://', 'https://')):
            data = urllib.request.urlopen(source, timeout=20).read()
        else:
            with open(source, 'rb') as fh:
                data = fh.read()
        self._b64 = base64.b64encode(data).decode()
        return self._b64

    def to_dict(self):
        return {'type': 'image', 'url': self.url, 'file': self.file, 'base64': self._b64}


class At(Component):
    type = 'at'

    def __init__(self, qq=None, name=None, **_kw):
        super().__init__()
        self.qq = str(qq) if qq not in (None, '') else ''
        self.name = name

    def to_dict(self):
        return {'type': 'at', 'qq': self.qq, 'name': self.name}


class Reply(Component):
    type = 'reply'

    def __init__(self, id=None, chain=None, **_kw):
        super().__init__()
        self.id = id if id is not None else _kw.get('message_id')
        self.chain = chain or []

    def to_dict(self):
        return {'type': 'reply', 'id': self.id}


class Node(Component):
    """合并转发节点。兼容层把它降级成纯文本（内核没有合并转发能力）。"""

    type = 'node'

    def __init__(self, content=None, name=None, uin=None, **_kw):
        super().__init__()
        self.content = content or []
        self.name = name
        self.uin = uin

    def to_dict(self):
        return {'type': 'node', 'content': [c.to_dict() if hasattr(c, 'to_dict') else str(c) for c in self.content],
                'name': self.name, 'uin': self.uin}


class Face(Component):
    type = 'face'

    def __init__(self, id=None, **_kw):
        super().__init__()
        self.id = id

    def to_dict(self):
        return {'type': 'face', 'id': self.id}


class Record(Component):
    type = 'record'

    def __init__(self, file=None, url=None, path=None, **_kw):
        super().__init__()
        self.file = file or path
        self.url = url

    def to_dict(self):
        return {'type': 'record', 'file': self.file, 'url': self.url}


class Video(Component):
    type = 'video'

    def __init__(self, file=None, url=None, path=None, **_kw):
        super().__init__()
        self.file = file or path
        self.url = url

    def to_dict(self):
        return {'type': 'video', 'file': self.file, 'url': self.url}


class File(Component):
    type = 'file'

    def __init__(self, name=None, file=None, url=None, **_kw):
        super().__init__()
        self.name = name
        self.file = file
        self.url = url

    def to_dict(self):
        return {'type': 'file', 'name': self.name, 'file': self.file, 'url': self.url}


class Forward(Node):
    pass


class Json(Component):
    type = 'json'

    def __init__(self, data=None, **_kw):
        super().__init__()
        self.data = data

    def to_dict(self):
        return {'type': 'json', 'data': self.data}


__all__ = ['Component', 'Plain', 'Image', 'At', 'Reply', 'Node', 'Face',
           'Record', 'Video', 'File', 'Forward', 'Json']
