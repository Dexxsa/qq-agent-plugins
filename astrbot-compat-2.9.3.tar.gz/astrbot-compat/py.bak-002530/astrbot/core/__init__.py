"""astrbot.core —— 只保留插件会 import 的少量路径。

注意：这里**故意不提供** astrbot.core.platform.*。
那类插件直接操作 aiocqhttp 的内部对象（C 档），
给个空壳反而会让它在运行中期莫名失败，不如在 import 阶段就明确报不支持。
"""

# 有些插件写的是 `from astrbot.core import AstrBotConfig`（旧版路径），
# 而在 AstrBot 里这个类也确实从 core 再导出过一次。用 PEP 562 惰性转发，
# 避免 core ↔ api 在 import 期互相吃对方。
_CORE_EXPORTS = ('AstrBotConfig',)


def __getattr__(name):
    if name in _CORE_EXPORTS:
        from astrbot.api import AstrBotConfig
        return AstrBotConfig
    raise AttributeError(f"module 'astrbot.core' has no attribute {name!r}（兼容层未实现）")
