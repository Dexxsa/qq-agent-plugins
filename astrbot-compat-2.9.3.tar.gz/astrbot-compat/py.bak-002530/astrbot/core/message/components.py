"""astrbot.core.message.components —— 老路径转发。

AstrBot 3.x 把消息组件挪到了 ``astrbot.api.message_components``，但市场里
大量插件仍写着 ``from astrbot.core.message.components import Plain, Reply``。
这里整体转发同一批类（不是重新定义），这样 isinstance 判断、类型分发都不会出错。
"""

from ...api.message_components import *  # noqa: F401,F403
from ...api import message_components as _mc

__all__ = [n for n in dir(_mc) if not n.startswith('_')]
