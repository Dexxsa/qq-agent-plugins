"""astrbot.core.message —— 消息相关类型的转发。

有些插件直接写 ``from astrbot.core.message import Plain``（不走 .components），
所以这里也做一层属性转发，指到同一批组件类上。
"""

from ...api import message_components as _mc


def __getattr__(name):
    if hasattr(_mc, name):
        return getattr(_mc, name)
    raise AttributeError(f"module 'astrbot.core.message' has no attribute {name!r}")
