"""老版本插件从这里 import MessageChain / MessageEventResult。"""

from ...api.event import MessageChain, MessageEventResult

__all__ = ['MessageChain', 'MessageEventResult']
