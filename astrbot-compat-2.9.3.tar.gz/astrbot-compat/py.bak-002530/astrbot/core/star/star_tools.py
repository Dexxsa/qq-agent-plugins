"""新版本插件从 astrbot.core.star.star_tools import StarTools。"""

from ...api.star import StarTools

__all__ = ['StarTools']
