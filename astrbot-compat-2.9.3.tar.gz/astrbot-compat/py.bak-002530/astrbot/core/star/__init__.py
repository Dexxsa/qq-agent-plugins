"""老版本插件从 astrbot.core.star import Star。"""

from ...api.star import Context, Star, StarTools, register

__all__ = ['Star', 'Context', 'register', 'StarTools']
