"""新版本插件从 astrbot.core.star.star import Star。"""

from ...api.star import Star

__all__ = ['Star']
