"""新版本插件从 astrbot.core.star.context import Context。"""

from ...api.star import Context

__all__ = ['Context']
