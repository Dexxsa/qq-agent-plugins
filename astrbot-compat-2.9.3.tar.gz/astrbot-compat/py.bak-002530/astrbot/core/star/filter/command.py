from ....api.event import filter

CommandFilter = type(filter)
command = filter.command

__all__ = ['command', 'CommandFilter']
