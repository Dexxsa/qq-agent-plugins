from ....api.event import EventMessageType, filter

event_message_type = filter.event_message_type

__all__ = ['event_message_type', 'EventMessageType']
