"""AstrBot 兼容包（BG-QQagent · astrbot-compat）

目的：让 AstrBot 的命令型插件（Star + filter.command + plain_result）
能在这个 Node 内核里原样 import 并运行，不需要改插件一行代码。

只实现「A 档」API 面：Star / Context / AstrMessageEvent / filter /
message_components / logger / AstrBotConfig / StarTools。
触及 LLM、平台内部对象、Web 面板、知识库的调用会显式抛 NotImplementedError，
不会被静默忽略 —— 静默忽略会让插件行为看起来"偶发失灵"，比直接报错难查得多。
"""

__version__ = '4.0.0+compat'
__compat__ = True
