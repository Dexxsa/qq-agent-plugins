// 配置管理：data/config.json，UI 可写。所有字段都有默认值。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { PERSONAS } from './personas.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(__dirname, '..');
// 测试/便携场景可重定向数据目录
export const DATA_DIR = process.env.QQ_AGENT_DATA_DIR || path.join(ROOT, 'data');
export const CONFIG_FILE = path.join(DATA_DIR, 'config.json');

export const DEFAULT_CONFIG = {
  // OpenAI 兼容 API（必填才能跑）
  api: {
    baseUrl: 'http://127.0.0.1:8787/v1',   // 例如本机 buddy2api 网关或任何 OpenAI 兼容端点
    apiKey: '',
    model: '',                              // UI 里选择/填写
    provider: '',                           // 当前模型所属提供商（多提供商目录的选中项）
    vision: true,                           // 模型是否支持图片输入（关掉则移除看图工具）
    temperature: 0.8,
    maxRounds: 12,                          // 单次运行的最多工具轮数
    timeoutMs: 180000,
    // 展示用单价（元 / 百万 token），不参与任何请求
    priceInputPerM: 0,
    priceOutputPerM: 0
  },
  // 多提供商模型目录（设置页手动维护）
  providers: [],
  providersSourceYaml: '',
  providersImported: true,
  // 联网搜索
  //   provider: 'auto'      = 有 AnySearch key 就用它，失败自动回退 Bing（推荐）
  //             'anysearch' = 只用 AnySearch（需配置 key，结果更全）
  //             'bing'      = 只用 Bing 网页抓取（无需 key）
  webSearch: {
    enabled: true,
    provider: 'auto',
    searchUrl: 'https://cn.bing.com/search',
    maxResults: 6,
    // AnySearch 的 API key（可选；也可用环境变量 ANYSEARCH_API_KEY / _2 注入，env 优先）
    // 支持多个 key 轮换：某个 key 返回 429 时自动换下一个
    anysearchKeys: []
  },
  // 插件自动更新（打开控制台即检查；见 src/core/plugin-updater.js）
  pluginUpdates: {
    enabled: true,                 // 关掉则完全不出网
    source: '',                    // 留空 = 用内置默认源；也可填自建静态目录
    intervalMinutes: 30,           // 两次检查的最小间隔
    autoApply: true,               // 查到新版本就直接装（false = 只在面板提示）
    installNew: false              // true 时连「本地没装的插件」也自动装
  },
  // 安全例外（默认全部关闭）
  security: {
    allowPrivateImageHosts: false           // true 时图片下载允许内网地址（仅本地测试/自建图床）
  },
  // SnowLuma / OneBot v11
  snowluma: {
    dir: '',                   // SnowLuma 程序目录；留空 = 自动探测项目内 ./snowluma
    autoLaunch: false,         // 应用启动时自动拉起 SnowLuma（未运行时）
    wsUrl: 'ws://127.0.0.1:3001',
    httpUrl: 'http://127.0.0.1:3000',
    accessToken: '',           // WebSocket 令牌
    httpAccessToken: ''        // HTTP API 令牌（SnowLuma 可与 WS 不同；留空沿用 accessToken）
  },
  // 人设与行为
  persona: {
    botName: '小鲸鱼',
    selfNickname: '',                       // 在群里的展示名（留空用 QQ 昵称）
    roleText: PERSONAS.xiaojingyu.text,     // 默认人设：原版"小鲸鱼"角色卡（适配版）
    participation: 'medium',                // low | medium | high —— 参与度参考
    customRules: ''                         // 追加自定义规则（可选）
  },
  // 用户自定义人设库（保存在配置里，可在设置页添加/选择）
  customPersonas: [],
  // 多身份：按会话绑定人设。key = chatKey（可含模式后缀，如 private:123456:tutor），
  // value = 人设 id（'builtin:xxx' 内置 / 'persona:<name>' 自定义人设名，见 resolvePersona）
  personaBindings: {},
  // 身份模式（学习模式等）：按会话记录当前激活的身份
  // { "<chatKey>": { "mode": "tutor"|"assistant", "personaRef": "...", "switchedAt": 123 } }
  personaModes: {},
  // 身份模式定义：每个模式一套完整配置（人设 + 工具 + 提示注入）
  identityModes: {
    // 示例（默认留空，由实际项目配置填充）：
    // tutor: { label: '教师模式', personaRef: '', extraPrompt: '', masterOnly: true }
  },
  // 接入白名单
  allow: { groups: [], private: [] },
  deny: { groups: [], private: [] },
  allowAllWhenEmpty: false,
  // 群聊未提及机器人时的触发概率（0.05 = 5%；@/提及/图片/提问必触发）
  groupMentionProbability: 0.05,
  // 群聊免艾特门槛（2026-10-22）：没 @ 机器人的消息，必须像提问才唤醒模型
  groupGate: {
    requireQuestion: true,  // false = 退回旧的"所有免艾特消息都唤醒"
    exemptMaster: true,     // 主人（persona.masterQQ）免艾特发言仍然放行，便于下指令
    // 2026-10-24《落地调整方案》：主人免 @ 也要求命中指令词，避免"随口吐槽一句也回"
    masterRequireCommand: false,
    masterAskPass: false,   // 主人没下指令但明显在提问时也放行（比死等指令词自然）
    masterCommands: [],     // 留空 = 用 question.js 里的内置词表（安静/查一下/排查/唤醒…）
    // 群友提问的放行概率：1 = 全放（旧行为），0.15 = 约六分之一
    strangerRate: 1,
    // 群级冷却：说过话之后多少秒内不再被群友提问唤醒（0 = 关闭；@ 与主人指令不受影响）
    cooldownSec: 0
  },
  // 运行节奏
  wakeDelayMs: 2000,        // 空闲时收到消息到发起运行的防抖窗口（等连发聚成一批）
  drainDelayMs: 1200,       // 一次运行结束后发现还有未读，到下一次运行的间隔
  maxConcurrentRuns: 2,     // 全局同时进行的 agent 运行数
  // 发送保护
  send: {
    minGapMs: 400,          // 相邻两条消息最小间隔（气泡间"打字"停顿下限）
    maxGapMs: 1000,         // 最大间隔
    byLengthMs: 40,         // 按上一句字数附加的间隔（毫秒/字），20 字即封顶
    maxPerMinute: 0,   // 0 = 不限速（已取消频率限制）
    maxPerHour: 0,    // 0 = 不限速（已取消频率限制）
    hardSplitAt: 4000,      // QQ 硬限制切分（0 = 不限制）
    splitBubbles: true,     // 多气泡：一条回复按行拆成多条独立消息
    maxBubbleChars: 220,    // 单个气泡软上限，超出按句末标点再切
    allowQuote: false       // 默认不挂 [CQ:reply] 引用框（true = 恢复旧行为）
  },
  // 主动开话题（可选）
  proactive: {
    enabled: false,
    checkIntervalMinMs: 1800000,
    checkIntervalMaxMs: 5400000,
    idleThresholdMs: 1800000,   // 群里静默多久才算"冷场"
    probability: 0.25
  },
  // 表情包
  sticker: {
    enabled: true,
    promptMaxStickers: 10,
    collectEnabled: true,
    maxCollectPerHour: 10
  },
  // 存储
  store: {
    maxMessagesPerChat: 2000,   // 单群 JSON 最大保留条数（0 = 无限）
    pastStateLimit: 80,         // 提示词里"过去状态"最多带多少条
    pastStateMaxChars: 6000,    // "过去状态"文本预算
    keepSessionFiles: 300       // 保留最近多少个会话记录文件
  },
  // 记忆自动整理：条数超阈值且距上次超过冷却时间时，在运行结束后后台合并/去重/删过时
  memory: {
    consolidateEnabled: true,
    consolidateMinIntervalMs: 21600000  // 默认 6 小时
  },
  // 桌面端/控制台
  server: {
    port: 3210,
    token: '',                // 留空 = 只监听 127.0.0.1
    autoStart: false,         // 开机自启（仅 Electron 桌面端生效）
    closeToTray: true         // 点关闭 = 最小化到托盘
  },
  // 外观（2026-10-21 上游）：皮肤 + 自定义背景
  // skin: default | paper-warm | midnight | forest | sakura | ocean
  // background.dataUrl 存 base64；opacity = 面板不透明度（0.30~1.00，越小背景越透）
  appearance: {
    skin: 'default',
    background: {
      dataUrl: '',      // 空 = 不启用背景图
      opacity: 0.92,
      blur: 0,
      mode: 'cover'     // cover | contain | repeat
    }
  },
  // 预算保险丝：今日估算成本达到上限（元）自动暂停；0 = 不限制
  budget: {
    dailyCostYuan: 0
  },
  // 广告/推广自动禁言（2026-10-03）。默认关闭：禁言影响真实群友，
  // 建议先开 dryRun 观察一段时间再正式开启。详见 src/anti-ad.js 顶部说明。
  antiAd: {
    enabled: false,             // 总开关
    dryRun: false,              // true = 只记录不处罚（正式开启前观察用）
    muteSeconds: 600,           // 禁言时长：10 分钟
    exemptUsers: [],            // 豁免名单（永不处理）
    cooldownMs: 1800000,        // 同一人冷却期 30 分钟（避免重复处罚）
    windowMs: 600000,           // 频率窗口 10 分钟
    maxPerWindow: 5             // 窗口内最多处罚人数（防批量误伤）
  },
  // 关键词广告注入（2026-10-20）。默认关闭：命中即自动发预设内容，
  // 配错会刷屏。建议先开 dryRun 观察。
  // 与 antiAd 相反：antiAd 是"检测群友发广告→禁言"，adInject 是"检测关键词→机器人发内容"。
  adInject: {
    enabled: false,
    dryRun: false,
    cooldownMs: 300000,          // 同一人同一广告冷却 5 分钟
    maxPerDayPerGroup: 3,        // 同一广告单群每天最多 3 次
    maxPerHourPerChat: 10,       // 单会话每小时上限
    maxAdsPerMessage: 1,         // 一条消息最多触发几条广告
    maxTextLength: 240,          // 超长文本不匹配
    allowPrivate: false,
    skipWhenAtBot: true,
    failureBackoffMs: 60000,
    regexMaxLength: 200,
    ads: [],                     // 广告列表（面板 CRUD）
  },
  // 群友福利发放（2026-10-04）。默认关闭 —— 开启即意味着发放真实权益。
  // 领取走确定性代码路径（welfare.js），入群满 minJoinHours 小时 + 每人限一次。
  welfare: {
    enabled: false,
    sourceGroups: [],           // 哪些群的成员可领（通常填白名单群）
    minJoinHours: 24,           // 入群满多少小时才可领
    tokenKeys: [],              // 可发放的 API key（轮询分配）
    tokenQuota: 20000000,       // 名义额度（本地记账用，上游无法强制）
    baseUrl: 'https://zp.597457.xyz/v1',
    model: 'GLM-5.3-Flash',
    coupons: [],                // 优惠券码（先到先得，发完为止）
    shopUrl: 'https://www.16688.com.cn/shop/XYGPT'
  }
};

function deepMerge(base, override) {
  if (override === null || override === undefined) return structuredClone(base);
  if (typeof base !== 'object' || base === null || Array.isArray(base)) return structuredClone(override);
  const out = Array.isArray(base) ? [...base] : { ...base };
  for (const [key, value] of Object.entries(override)) {
    if (value && typeof value === 'object' && !Array.isArray(value) && base[key] && typeof base[key] === 'object' && !Array.isArray(base[key])) {
      out[key] = deepMerge(base[key], value);
    } else if (value !== undefined) {
      out[key] = structuredClone(value);
    }
  }
  return out;
}

export function loadConfig() {
  let cfg;
  try {
    let text = fs.readFileSync(CONFIG_FILE, 'utf8');
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
    const parsed = JSON.parse(text);
    cfg = deepMerge(DEFAULT_CONFIG, parsed);
  } catch {
    cfg = structuredClone(DEFAULT_CONFIG);
  }
  return withPersonaSwitchModes(cfg);
}

/**
 * 自动补齐「人设切换」用的 identityModes（2026-10-05）。
 *
 * 设计：16 个可选人设不逐个手写进 config.json，而是**由代码按需生成**：
 *   每个人设 → 一个 mode（id = `persona:<key>`），带 label / personaRef / enter 口令。
 * 好处：
 *   · 新增人设只改 personas.js，切换能力自动跟着有，不会漏配
 *   · config.json 保持干净（不用塞 16 段重复的 enter/exit）
 *   · 面板下拉切换与群内口令切换走**同一套 mode 机制**，行为一致
 *
 * 口令设计原则：
 *   · enter 用「切换X」「换X」「X模式」等自然说法；短口令（如"傻妞"）也收，
 *     但要过下面的一致性检查，避免和日常聊天撞车。
 *   · 已显式配置过的同名 mode 不覆盖（以用户在面板/配置里的为准）。
 *   · kind:'persona' 标记用于切换时区分文案（见 orchestrator 的"换人设"分支）。
 */
function withPersonaSwitchModes(cfg) {
  const modes = { ...(cfg.identityModes || {}) };
  // 只在开启「可选人设」时才注入，避免用户没这个需求时空增 16 个 mode
  const enabled = cfg.features?.personaSwitch !== false;
  if (!enabled) return cfg;
  for (const [key, p] of Object.entries(PERSONAS)) {
    if (key === 'blank') continue;              // 空白模板不作为可切换人设
    const modeId = `persona:${key}`;
    if (modes[modeId]) continue;                // 已有显式配置 → 不覆盖
    const short = String(p.name || '').replace(/（.*?）/g, '').trim();
    modes[modeId] = {
      kind: 'persona',
      label: `人设·${short}`,
      personaRef: `builtin:${key}`,
      extraPrompt: '',
      // 口令：切换X / 换X / X模式 / 用人设X
      enter: [`切换${short}`, `换${short}`, `${short}模式`, `用人设${short}`, `切到${short}`],
      exit: ['换回来', '恢复默认', '回到默认', '切换默认', '退出人设', '换回小白鲸']
    };
    // 小白鲸（默认人设）用「换回来」即可，不需要"切换小白鲸"
    if (key === 'xiaojingyu') {
      modes[modeId].enter = ['切换小白鲸', '换小白鲸', '小白鲸模式', '回到小白鲸'];
    }
  }
  return { ...cfg, identityModes: modes };
}

let currentConfig = null;
let saveTimers = new Map();

/** 取当前生效配置（未初始化时从磁盘读）。 */
export function getConfig() {
  if (!currentConfig) currentConfig = loadConfig();
  return currentConfig;
}

/**
 * 整段替换 config.plugins（插件配置专用出口）。
 *
 * 为什么需要单独一个函数：`updateConfig` 走 deepMerge，对对象型字段是**递归合并**，
 * 无法表达"删除一个键"（deepMerge 里 null 被当作"不覆盖"）。
 * 而插件配置必须能被清空（作用域覆盖表、广告列表）——否则用户改回不了默认。
 * 这里直接**整段替换**，语义干净，且不影响其它任何配置项。
 *
 * @param {object} nextPlugins 完整的新 plugins 段落（调用方负责基于旧值构造）
 */
export function replacePluginsConfig(nextPlugins) {
  const cur = getConfig();
  currentConfig = { ...cur, plugins: nextPlugins || {} };
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const tmp = `${CONFIG_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(currentConfig, null, 2), 'utf8');
  fs.renameSync(tmp, CONFIG_FILE);
  return currentConfig;
}

/** 更新并持久化配置（浅合并到当前值；patch 里传对象字段则整体替换该字段）。 */
export function updateConfig(patch) {
  currentConfig = deepMerge(getConfig(), patch);
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const tmp = `${CONFIG_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(currentConfig, null, 2), 'utf8');
  fs.renameSync(tmp, CONFIG_FILE);
  return currentConfig;
}

/** 内存态改动（不落盘）——用于运行期覆盖（如自测注入 mock）。 */
export function setRuntimeConfig(cfg) {
  currentConfig = cfg;
}

/** 防抖保存：高频小改动合并写盘。 */
export function scheduleConfigSave() {
  clearTimeout(saveTimers.get('cfg'));
  saveTimers.set('cfg', setTimeout(() => {
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      const tmp = `${CONFIG_FILE}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify(getConfig(), null, 2), 'utf8');
      fs.renameSync(tmp, CONFIG_FILE);
    } catch (error) {
      console.error('[config] 保存失败:', error);
    }
  }, 400));
}

// ── 多身份（身份模式 Identity Mode）──────────────────────────────────────
// 设计要点：
//   物理会话键 baseChatKey（如 private:123456）= 消息"从哪来"；
//   有效会话键 = baseChatKey + ':' + mode（如 private:123456:tutor）；
//   不同身份的历史/记忆/进度天然隔离（store/memory 都按 chatKey 分文件）。

export const DEFAULT_MODE = 'assistant';

/** 拆解 chatKey：kind / id / mode / base。 */
export function parseChatKey(chatKey) {
  const parts = String(chatKey || '').split(':');
  const kind = parts[0] || '';
  const id = parts[1] || '';
  const mode = parts[2] || '';
  return { kind, id, mode, base: `${kind}:${id}` };
}

/** 取某物理会话当前激活的身份模式（未配置或已删除的模式回退默认）。 */
export function getIdentityMode(baseChatKey) {
  const cfg = getConfig();
  const rec = cfg.personaModes?.[baseChatKey];
  const mode = rec?.mode || DEFAULT_MODE;
  if (mode !== DEFAULT_MODE && !cfg.identityModes?.[mode]) return DEFAULT_MODE;
  return mode;
}

/** 设置某物理会话的身份模式并持久化。
 *  注意：deepMerge 对同名字段做"深层合并"，删除 key 会失效，因此显式重建整个对象后整体覆盖。 */
export function setIdentityMode(baseChatKey, mode) {
  const cfg = getConfig();
  // 'default' 是口语化写法，归一成真正的 DEFAULT_MODE（'assistant'）。
  // ⚠️ 2026-09-20 踩过：传入 'default' 不等于 DEFAULT_MODE，delete 分支不生效，
  //    反而写入了 {mode:'default'} 这种无意义状态（虽因回退侥幸表现正确，但语义脏）。
  const raw = String(mode || DEFAULT_MODE);
  const m = (raw === 'default' || raw === 'daily' || raw === 'normal') ? DEFAULT_MODE : raw;
  const next = { ...(cfg.personaModes || {}) };
  if (m === DEFAULT_MODE) delete next[baseChatKey];
  else next[baseChatKey] = { mode: m, switchedAt: Date.now() };
  // 先清空再写入，绕开 deepMerge 的"保留旧键"行为
  getConfig().personaModes = {};
  updateConfig({ personaModes: next });
  return m;
}

/** 物理会话键 → 有效会话键（按当前身份模式追加后缀）。 */
export function resolveChatKey(baseChatKey) {
  const { mode } = parseChatKey(baseChatKey);
  if (mode) return String(baseChatKey);
  const m = getIdentityMode(baseChatKey);
  return m === DEFAULT_MODE ? String(baseChatKey) : `${baseChatKey}:${m}`;
}

/** personaRef → 完整 persona 对象。支持 builtin:<id> / custom:<名或custom_N>。 */
export function resolvePersonaRef(ref) {
  if (!ref) return null;
  const cfg = getConfig();
  const s = String(ref).trim();
  if (s.startsWith('builtin:')) {
    const key = s.slice(8);
    const p = PERSONAS[key];
    if (!p) return null;
    return { botName: p.name, selfNickname: '', roleText: p.text, participation: 'medium', customRules: '', ref: s, key };
  }
  const key = s.startsWith('custom:') ? s.slice(7) : (s.startsWith('persona:') ? s.slice(8) : s);
  const list = cfg.customPersonas || [];
  let found = list.find((p) => p && p.name === key);
  if (!found && /^custom_\d+$/.test(key)) found = list[Number(key.slice(7))];
  if (!found) return null;
  return {
    botName: found.botName || found.name || cfg.persona.botName,
    selfNickname: found.selfNickname ?? '',
    roleText: found.text || '',
    participation: found.participation || cfg.persona.participation,
    customRules: found.customRules || '',
    ref: s.startsWith('custom:') ? s : `custom:${key}`
  };
}

/**
 * 解析某会话键应使用的人设与模式信息。
 * 优先级：personaBindings[有效键] > personaBindings[物理键] > 模式映射表 > 模式人设 > 全局默认。
 */
export function resolvePersona(chatKey) {
  const cfg = getConfig();
  const { base, mode } = parseChatKey(chatKey);
  const activeMode = mode || getIdentityMode(base);
  const modeDef = activeMode === DEFAULT_MODE ? null : (cfg.identityModes?.[activeMode] || null);

  const bindings = cfg.personaBindings || {};
  const ref = bindings[String(chatKey)] || bindings[base] || modeDef?.personaRef || '';
  const fromRef = resolvePersonaRef(ref);

  const persona = fromRef || {
    botName: cfg.persona.botName,
    selfNickname: cfg.persona.selfNickname,
    roleText: cfg.persona.roleText,
    participation: cfg.persona.participation,
    customRules: cfg.persona.customRules,
    ref: ''
  };
  return { persona, mode: activeMode, modeDef, baseChatKey: base };
}
