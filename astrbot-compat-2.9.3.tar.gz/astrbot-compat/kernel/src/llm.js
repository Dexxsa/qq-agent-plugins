// OpenAI 兼容 Chat Completions 客户端（非流式；QQ 本身不支持流式，没必要）。
// 支持工具调用、usage 统计、可自选模型 —— 这是与 DSH 解耦后的"大脑"接口。
// 2026-10-23：新增主/备通道自动回退（api.fallback），主通道 5xx/超时/限流时自动改用备用模型，
//             避免上游抽风时机器人直接哑掉。
import { getConfig } from './config.js';

function joinUrl(base, path) {
  return `${String(base).replace(/\/+$/, '')}${path}`;
}

function authHeaders(apiKey) {
  return apiKey ? { authorization: `Bearer ${apiKey}` } : {};
}

function buildBody(cfg, { messages, tools, toolChoice, temperature }) {
  const body = {
    model: cfg.model,
    messages,
    stream: false
  };
  if (tools && tools.length > 0) {
    body.tools = tools;
    body.tool_choice = toolChoice;
  }
  const temp = temperature === null ? (cfg.temperature ?? 0.8) : temperature;
  if (temp !== null && temp !== undefined && Number.isFinite(Number(temp))) body.temperature = Number(temp);
  return body;
}

async function requestOnce(cfg, body, signal) {
  const timeoutMs = Math.max(5000, Number(cfg.timeoutMs) || 180000);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(new Error('请求超时')), timeoutMs);
  if (signal) {
    if (signal.aborted) controller.abort(signal.reason ?? new Error('aborted'));
    else signal.addEventListener('abort', () => controller.abort(signal.reason ?? new Error('aborted')), { once: true });
  }

  let res;
  try {
    res = await fetch(joinUrl(cfg.baseUrl, '/chat/completions'), {
      method: 'POST',
      headers: { 'content-type': 'application/json', ...authHeaders(cfg.apiKey) },
      body: JSON.stringify(body),
      signal: controller.signal
    });
  } catch (error) {
    clearTimeout(timer);
    if (error?.name === 'AbortError') throw new Error(`模型请求超时（${timeoutMs}ms）`);
    throw new Error(`模型请求失败：${error?.cause?.message ?? error?.message ?? error}`);
  }
  clearTimeout(timer);

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`模型 API HTTP ${res.status}：${text.slice(0, 500)}`);
  }
  const data = await res.json().catch(() => { throw new Error('模型 API 返回了无法解析的 JSON'); });
  const choice = data?.choices?.[0];
  if (!choice) throw new Error(`模型 API 响应缺少 choices：${JSON.stringify(data).slice(0, 300)}`);
  return {
    message: choice.message ?? {},
    finishReason: choice.finish_reason ?? null,
    usage: data.usage ?? null,
    model: data.model ?? cfg.model,
    raw: data
  };
}

/**
 * 单次对话请求。messages 为 OpenAI 格式；tools 为 OpenAI function 格式（可为空）。
 * 返回 { message, usage, raw }；usage 形如 { prompt_tokens, completion_tokens, total_tokens }。
 * 配置中存在 api.fallback（{ baseUrl, apiKey, model }）时，主通道失败会自动用它重试一次；
 * 失败后进入冷却（默认 5 分钟），期间直接走备用通道，避免每条消息都先撞一次墙。
 */
/**
 * 推理型模型（deepseek-v4-flash / v4-pro 等）先写 reasoning_content 再写 content。
 * 一旦思考把 token 用尽，接口照样 200，但 content 是空字符串 —— 表现为“已读不回”。
 * 这里把“空正文且无工具调用”当作失败，交给上层回退到备用通道，宁可换模型也不装哑。
 */
function assertUsable(out, label) {
  const msg = out?.message || {};
  const hasToolCall = Array.isArray(msg.tool_calls) && msg.tool_calls.length > 0;
  const text = String(msg.content ?? '').trim();
  if (text || hasToolCall) return out;
  const reasoning = String(msg.reasoning_content ?? msg.reasoning ?? '');
  throw new Error(`${label} 返回空正文${reasoning ? `（推理内容 ${reasoning.length} 字，疑似被 max_tokens 截断）` : ''}`);
}

const COOLDOWN_MS = Number(process.env.LLM_FALLBACK_COOLDOWN_MS) || 5 * 60 * 1000;
let cooldownUntil = 0;

export async function chatCompletion({ messages, tools = null, toolChoice = 'auto', temperature = null, signal = null }) {
  const cfg = getConfig().api;
  const body = buildBody(cfg, { messages, tools, toolChoice, temperature });
  const fb = cfg.fallback;
  const hasFallback = Boolean(fb && fb.model && fb.baseUrl);

  // 主通道处于冷却期：直接走备用，省掉一次必然失败的网络往返
  if (hasFallback && Date.now() < cooldownUntil) {
    try {
      const out = await requestOnce({ ...cfg, ...fb }, { ...body, model: fb.model }, signal);
      out.fallbackFrom = cfg.model;
      out.fallbackReason = '主通道冷却中（近期失败）';
      return assertUsable(out, `备用通道 ${fb.model}`);
    } catch (fallbackError) {
      throw new Error(`备用通道 ${fb.model} 请求失败（主通道 ${cfg.model} 冷却中）：${fallbackError?.message}`);
    }
  }

  try {
    const out = await requestOnce(cfg, body, signal);
    if (cooldownUntil) {
      cooldownUntil = 0;
      console.log(`[llm] 主通道 ${cfg.model} 已恢复，退出冷却`);
    }
    return assertUsable(out, `主通道 ${cfg.model}`);
  } catch (primaryError) {
    if (!hasFallback) throw primaryError;

    cooldownUntil = Date.now() + COOLDOWN_MS;
    const target = { ...cfg, ...fb };
    try {
      const out = await requestOnce(target, { ...body, model: fb.model }, signal);
      out.fallbackFrom = cfg.model;
      out.fallbackReason = String(primaryError?.message ?? primaryError).slice(0, 300);
      console.warn(`[llm] 主通道 ${cfg.model} 失败，已回退到 ${fb.model}（冷却 ${Math.round(COOLDOWN_MS / 1000)}s）：${out.fallbackReason.slice(0, 160)}`);
      return assertUsable(out, `备用通道 ${fb.model}`);
    } catch (fallbackError) {
      throw new Error(`主通道 ${cfg.model} 失败：${primaryError?.message}；备用通道 ${fb.model} 也失败：${fallbackError?.message}`);
    }
  }
}

/** 获取模型列表（GET /models）。返回 [{ id }]；失败抛错。 */
export async function listModels() {
  const cfg = getConfig().api;
  const res = await fetch(joinUrl(cfg.baseUrl, '/models'), {
    headers: authHeaders(cfg.apiKey),
    signal: AbortSignal.timeout(15000)
  });
  if (!res.ok) throw new Error(`获取模型列表失败：HTTP ${res.status}`);
  const data = await res.json();
  const list = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : []);
  return list.map((m) => ({ id: String(m.id ?? m.model ?? m) })).filter((m) => m.id);
}

/** 累加 usage。 */
export function addUsage(target, usage) {
  if (!usage) return target;
  target.promptTokens += Number(usage.prompt_tokens) || 0;
  target.completionTokens += Number(usage.completion_tokens) || 0;
  target.totalTokens += Number(usage.total_tokens) || (Number(usage.prompt_tokens) || 0) + (Number(usage.completion_tokens) || 0);
  return target;
}

export function emptyUsage() {
  return { promptTokens: 0, completionTokens: 0, totalTokens: 0, calls: 0 };
}

/** 按配置单价折算成本（元）。 */
export function estimateCost(usage) {
  const cfg = getConfig().api;
  const cost = (usage.promptTokens / 1e6) * (Number(cfg.priceInputPerM) || 0)
    + (usage.completionTokens / 1e6) * (Number(cfg.priceOutputPerM) || 0);
  return Math.round(cost * 1e4) / 1e4;
}
