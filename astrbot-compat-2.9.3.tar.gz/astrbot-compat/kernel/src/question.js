// 群聊免艾特提问门（2026-10-22）
//
// 背景：群里有插件的消息（"有插件啊"、"我传了个记忆与约定"、"等我看看"）以前
// 全都被当成"可以接的话题"唤醒模型，模型还把它们脑补成运维指令（"模块链路已闭"）。
//
// 现在两级过滤：
//   第一级（这里，代码硬门）：没 @ 机器人的群消息，必须带提问特征才唤醒模型。
//     纯陈述句 → 只入库当上下文（read:true），不进模型。
//   第二级（提示词 + [PASS]）：粗筛放行的消息，模型若判断仍是闲聊就输出 [PASS]，
//     由 tools/orchestrator 直接丢弃，不发任何消息。
//
// 为什么要有第二级：关键词必然误伤（"不知道为什么就挂了"这类陈述句里也有疑问词），
// 硬门只负责挡住最明显的陈述句，剩下的交给模型判断。

const QUESTION_PATTERNS = [
  { re: /[?？]/, tag: '问号' },
  // 疑问代词 / 选择问 / 正反问
  { re: /(怎么|怎样|如何|为什么|为啥|咋|什么|啥|哪些|哪个|哪儿|哪里|在哪|谁|是否|能不能|可不可以|行不行|对不对|有没有)/, tag: '疑问词' },
  // 数量/程度疑问（2026-10-24：'这台机器内存多少' 原来不算提问，主人提问被吞）
  { re: /(多少|多久|多大|多长|多高|多重|多远|多久|几个|几天|几次|几点|几年|几个月)/, tag: '数量疑问' },
  // 句尾疑问助词（"吧" 不算：多为祈使/推测，"你试试吧"不是提问）
  { re: /(吗|呢|么)\s*[?？]?\s*$/, tag: '句尾疑问' },
  // 求助句式：明确在找人帮忙
  { re: /(求问|请问|请教|求助|求解|有人会|有没有人|有人知道|有人懂|帮看|帮我看看|帮忙看|看一下这个|看下这个|怎么搞|咋搞)/, tag: '求助' },
  // 报错/故障类陈述，通常就是在求助（"它报错了"）
  { re: /(报错|崩了|挂了|不通|跑不起来|起不来|失败|异常)/, tag: '故障' }
];

/**
 * 是否具备提问特征。
 * @returns {{ask: boolean, tag: string}}
 */
export function detectAsk(text) {
  const s = String(text ?? '').replace(/\[CQ:[^\]]*\]/g, ' ').trim();
  if (s.length < 2) return { ask: false, tag: '' };
  for (const { re, tag } of QUESTION_PATTERNS) {
    if (re.test(s)) return { ask: true, tag };
  }
  return { ask: false, tag: '' };
}

export function isAskingQuestion(text) {
  return detectAsk(text).ask;
}

// 管理口令豁免：人设切换 / 模式切换这类口令不是提问，但必须能过门，
// 否则"切换到嘉欣人设"会被当成陈述句吞掉（orchestrator 的身份切换在唤醒之后才检测）。
const ADMIN_HINT_RE = /(切换|人设|人格|模式|上课|下课|进入学习|退出学习|暂停学习)/;

// 宿主的控制指令词（2026-10-24《落地调整方案》第 1 节 B 情况）。
// 主人免 @ 也放行是旧行为，副作用是"随口吐槽一句也回"；现在改成：没 @ 时只有
// 命中这些词才算指令，才唤醒模型，其余主人消息只入库当上下文。
const DEFAULT_MASTER_COMMANDS = [
  '安静', '闭嘴', '别说话', '下线', '静默', '别吵',
  '唤醒', '上线', '出来', '说话', '开工',
  '查一下', '查下', '查查', '核对', '核一下', '排查', '检查', '看一下', '看下', '看看这个',
  '读一下', '打开', '解析', '重启', '清理', '重置'
];

function hasCommand(text, words) {
  const s = String(text ?? '');
  if (!s) return false;
  return words.some((w) => w && s.includes(w));
}

// ── 群级冷却（进程内，不落盘）─────────────────────────────────
// 随机抽样回了一句之后，这个群进冷却，期间群友的提问一律不唤醒（@ 与主人指令照常）。
// 目的：群里两三个人同时提问时不连环抢话，保持"偶发露面、说完秒潜"。
const lastReplyAt = new Map();

/** 记录某个会话刚发过言（发送成功后调用）。 */
export function noteReply(chatKey) {
  if (!chatKey) return;
  lastReplyAt.set(String(chatKey), Date.now());
}

/** 该会话还在冷却里就返回剩余毫秒，否则 0。 */
export function cooldownLeft(chatKey, ms = 0) {
  const span = Number(ms) || 0;
  if (span <= 0) return 0;
  const t = lastReplyAt.get(String(chatKey)) || 0;
  const left = t + span - Date.now();
  return left > 0 ? left : 0;
}

/**
 * 群消息是否该唤醒模型。
 * @param {object} p
 * @param {'group'|'private'} p.kind
 * @param {boolean} p.atMe        是否 @ 了机器人（或 @全体）
 * @param {boolean} p.atOthersOnly 只 @ 了别人
 * @param {boolean} p.fromMaster  发言人是不是主人（masterQQ）
 * @param {string}  p.text
 * @param {boolean} p.requireQuestion 免艾特是否要求提问（config.groupGate.requireQuestion）
 * @param {boolean} p.exemptMaster    主人免艾特也放行（config.groupGate.exemptMaster）
 * @param {boolean} p.masterRequireCommand 主人免 @ 时是否要求命中指令词（config.groupGate.masterRequireCommand）
 * @param {boolean} p.masterAskPass 主人没下指令但明确在提问，是否也放行（config.groupGate.masterAskPass）
 * @param {string[]} p.masterCommands 指令词表（config.groupGate.masterCommands）
 * @param {number}  p.strangerRate    群友提问的放行概率 0~1（config.groupGate.strangerRate，1=全放）
 * @param {boolean} p.inCooldown      群是否在冷却期（config.groupGate.cooldownSec + noteReply）
 * @returns {{wake: boolean, reason: string, tag?: string}}
 */
export function decideWake({
  kind, atMe = false, atOthersOnly = false, fromMaster = false,
  text = '', requireQuestion = true, exemptMaster = true,
  masterRequireCommand = false, masterCommands = DEFAULT_MASTER_COMMANDS, masterAskPass = false,
  strangerRate = 1, inCooldown = false
}) {
  if (kind !== 'group') return { wake: true, reason: '私聊' };
  if (atMe) return { wake: true, reason: '被@' };
  // @ 别人优先：主人在叫别的 bot 时也不该抢答
  if (atOthersOnly) return { wake: false, reason: '@他人' };
  if (fromMaster) {
    if (!exemptMaster) return { wake: false, reason: '主人免艾特未放行' };
    if (!masterRequireCommand) return { wake: true, reason: '主人' };
    if (hasCommand(text, masterCommands)) return { wake: true, reason: '主人指令' };
    // 没命中指令词，但明显是在问（"这段代码怎么报错"），默认也放行 ——
    // 不然主人得先喊"查一下"才有人应声，太死板。
    if (masterAskPass) {
      const dm = detectAsk(text);
      if (dm.ask) return { wake: true, reason: '主人提问', tag: dm.tag };
    }
    return { wake: false, reason: '主人闲聊（非指令）' };
  }
  if (!requireQuestion) return { wake: true, reason: '免艾特直通（未启用提问门）' };
  if (ADMIN_HINT_RE.test(String(text))) return { wake: true, reason: '口令豁免' };
  const d = detectAsk(text);
  if (!d.ask) return { wake: false, reason: '陈述句' };
  // 群冷却：刚说过话就先闭嘴，避免连环抢话（@ 与主人指令已在上面放行）
  if (inCooldown) return { wake: false, reason: '群冷却' };
  const rate = Number(strangerRate);
  if (Number.isFinite(rate) && rate < 1 && Math.random() >= rate) {
    return { wake: false, reason: '抽样未中' };
  }
  return { wake: true, reason: '提问', tag: d.tag };
}

/** [PASS] 静默信号（半角/全角方括号都认，大小写不敏感）。 */
const PASS_RE = /[[【]\s*PASS\s*[\]】]/i;

export function isPassSignal(text) {
  return PASS_RE.test(String(text ?? ''));
}

/** 从一批待发文本里剔掉 [PASS]，返回真正要发的部分。 */
export function dropPassMessages(messages) {
  const list = Array.isArray(messages) ? messages : [messages];
  return list.map((m) => String(m ?? '')).filter((t) => !isPassSignal(t));
}
