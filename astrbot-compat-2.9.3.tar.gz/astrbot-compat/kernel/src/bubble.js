// 气泡拆分：把模型一次输出的整段文本，切成若干条独立 QQ 消息（多气泡）。
//
// 背景（2026-10-22）：以前整段回复塞进同一个气泡，多行靠 \n 硬换行，
// 手机端堆成一大片，观感极差。真人是"一句一个气泡"。
//
// 规则：
//   · 按换行切句，空行视为强断点
//   · ``` 代码块整块保留（不按行切碎），围栏本身会被 mdToPlain 去掉
//   · 连续表格行（| 开头）合并成一个气泡
//   · 单条超过 maxChars 再按句末标点二次切分
//   · 气泡数超过 maxBubbles 时把尾部合并，避免刷屏
//   · 兜底硬切（2026-10-23）：非代码单条超过 hardMax（默认 60 字）时，按空格/顿号等
//     软分隔切成 chunkMax（默认 25 字）以内的小条。模型偶尔一句话吐 70 字不分片，
//     规则 11 管不住的时候靠这里物理兜底。代码块、表格整块豁免，永不切。

const SENTENCE_RE = /[。！？!?；;…\n]/g;
// 软分隔：空格（含全角）、顿号逗号冒号分号、斜杠。中文短句基本靠空格断句，切开不留分隔符。
const SOFT_SEP_RE = /[\s\u3000、，,；;：:／/]/;

/** 超长单条按软分隔切成 ≤chunk 的小条（找不到分隔符就硬切，但不留 6 字以内的碎尾）。 */
function splitSoft(text, chunk) {
  const parts = [];
  let rest = String(text).trim();
  const size = Math.max(1, chunk);
  while (rest.length > size) {
    let cut = -1;
    // 先往前找：不超过 size 的最后一个软分隔
    for (let i = Math.min(size, rest.length - 1); i > 0; i--) {
      if (SOFT_SEP_RE.test(rest[i])) { cut = i; break; }
    }
    // 前面没有分隔符，就往后多吞最多 12 字去找一个，避免把词从中间切开
    if (cut <= 0) {
      for (let i = size + 1; i <= Math.min(size + 12, rest.length - 1); i++) {
        if (SOFT_SEP_RE.test(rest[i])) { cut = i; break; }
      }
    }
    if (cut <= 0) {
      // 整段一个分隔符都没有：硬切会切出「己姓什么」这种碎尾，宁可整条留着
      if (rest.length <= size + 6) { parts.push(rest); rest = ''; break; }
      cut = size;
    }
    const head = rest.slice(0, cut).trim();
    if (head) parts.push(head);
    rest = rest.slice(cut).replace(/^[\s\u3000]+/, '');
  }
  if (rest) parts.push(rest);
  return parts;
}

/** 超长单条按句末标点再切（找不到标点就硬切）。 */
function splitLong(text, max) {
  const parts = [];
  let rest = String(text);
  while (rest.length > max) {
    let cut = -1;
    SENTENCE_RE.lastIndex = 0;
    let m;
    while ((m = SENTENCE_RE.exec(rest)) !== null) {
      const end = m.index + 1;
      if (end > max) break;
      cut = end;
    }
    if (cut <= 0) cut = max; // 整段没标点，只能硬切
    const head = rest.slice(0, cut).trim();
    if (head) parts.push(head);
    rest = rest.slice(cut).trim();
  }
  if (rest.trim()) parts.push(rest.trim());
  return parts;
}

export function splitBubbles(raw, { maxChars = 220, maxBubbles = 8, hardMax = 60, chunkMax = 25 } = {}) {
  const text = String(raw ?? '').replace(/\r\n?/g, '\n').trim();
  if (!text) return [];
  if (!(maxChars > 0)) return [text];

  const out = [];   // [{ text, code }]；code=true 的气泡永不再切
  let buf = [];
  let fence = null; // 正在收集的代码块行

  const pushBubble = (t, code = false) => {
    const s = String(t || '').trim();
    if (s) out.push({ text: s, code });
  };
  const flush = () => {
    if (!buf.length) return;
    pushBubble(buf.join('\n'));
    buf = [];
  };

  const lines = text.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].replace(/\s+$/, '');
    const isFence = /^\s*```/.test(line);

    if (fence) {
      // 代码块内部：只找闭合围栏
      fence.push(line);
      if (isFence) {
        flush();                     // 围栏前的内容先独立成一条
        pushBubble(fence.join('\n'), true);
        fence = null;
      }
      continue;
    }
    if (isFence) {
      flush();
      fence = [line];
      continue;
    }
    if (!line.trim()) { flush(); continue; } // 空行 = 气泡边界

    // 一行 = 一个气泡（真人就是这么发的）。只有表格的连续行才攒在一起，
    // 否则表格会被切成一行一个气泡，完全看不懂。
    const isTable = /^\s*\|/.test(line);
    const nextIsTable = i + 1 < lines.length && /^\s*\|/.test(lines[i + 1].replace(/\s+$/, ''));
    buf.push(line);
    if (!(isTable && nextIsTable)) flush();
  }
  if (fence) { flush(); pushBubble(fence.join('\n'), true); } // 围栏没闭合
  flush();

  const final = [];
  let hasBlock = false;
  for (const item of out) {
    const t = item.text;
    // 代码块 / 表格（含换行的整体）整块豁免：规则 5、12 允许代码块单发一整个气泡
    if (item.code || t.includes('\n')) { final.push(t); hasBlock = true; continue; }
    if (hardMax > 0 && t.length > hardMax) final.push(...splitSoft(t, chunkMax));
    else if (t.length <= maxChars) final.push(t);
    else final.push(...splitLong(t, maxChars));
  }

  if (maxBubbles > 0 && final.length > maxBubbles) {
    // 超条数怎么办（2026-10-24 用户定的观感）：不并成一条长气泡（几十字一条难看），
    // 也不放开到 4 条 —— 直接把文字压进 maxBubbles 条、每条不超过 perCap。
    // 有代码块/表格时绝不压缩（代码不能剁成短句），退回旧的"尾部并入最后一条"。
    if (hasBlock) {
      const head = final.slice(0, maxBubbles - 1);
      head.push(final.slice(maxBubbles - 1).join('\n'));
      return head;
    }
    return compressBubbles(final, maxBubbles, chunkMax > 0 ? chunkMax : maxChars);
  }
  return final;
}

/** 把一条超预算的文字在软分隔处截断（不留半个词）。 */
function clipSoft(text, budget) {
  const s = String(text);
  if (s.length <= budget) return s;
  let cut = -1;
  const floor = Math.max(1, budget - 12);
  for (let i = Math.min(budget, s.length - 1); i >= floor; i--) {
    if (SOFT_SEP_RE.test(s[i])) { cut = i; break; }
  }
  if (cut <= 0) cut = budget;
  return s.slice(0, cut).trim();
}

/** 把多条文字压成 count 条：总量超预算就截，再均分成短句。 */
function compressBubbles(list, count, perCap) {
  const joined = list.join(' ').replace(/\s+/g, ' ').trim();
  const budget = count * perCap;
  const body = clipSoft(joined, budget);
  if (!body) return [];
  const size = Math.max(1, Math.min(perCap, Math.ceil(body.length / count)));
  const out = [];
  let rest = body;
  while (rest && out.length < count - 1) {
    const piece = (splitSoft(rest, size)[0] || rest.slice(0, size)).trim();
    if (!piece) break;
    out.push(piece);
    rest = rest.slice(piece.length).replace(/^[\s\u3000]+/, '');
  }
  if (rest) out.push(clipSoft(rest, perCap));   // 尾巴也走软分隔截断，不留半个词
  return out.filter(Boolean);
}

/** 按气泡字数估算"打字"停顿：400~1000ms。 */
export function bubbleDelay(text, { min = 400, max = 1000, perChar = 40 } = {}) {
  const lo = Math.max(0, Number(min) || 0);
  const hi = Math.max(lo, Number(max) || lo);
  const len = String(text || '').trim().length;
  const byLen = len * (Number(perChar) || 0);
  return Math.min(hi, Math.max(lo, byLen));
}
