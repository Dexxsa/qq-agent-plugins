// 发送队列：所有对 QQ 的出站消息都经过这里。
// - 每会话串行（sendChain），真人化间隔（随机区间 + 按字数附加）
// - 分钟/小时限频（超限直接拒绝，工具会把错误告诉模型）
// - Markdown → 纯文本、QQ 硬长度切分、CQ 转义
// - 发出的每一条记进 ChatStore（self=true，供下一次运行当"自己的发言"）
import { getConfig } from './config.js';
import { sleep, randInt, createSendChain, escapeCqText, formatClockTime } from './util.js';
import { mdToPlain, splitForQQ } from './md-to-plain.js';
import { splitBubbles, bubbleDelay } from './bubble.js';

export class SendQueue {
  constructor({ onebot, store, onSent = null }) {
    this.onebot = onebot;
    this.store = store;
    this.onSent = onSent;
    this.chains = new Map();      // chatKey -> enqueue fn
    this.minuteTimes = new Map(); // chatKey -> [ts]
    this.hourTimes = new Map();   // chatKey -> [ts]
  }

  #chain(chatKey) {
    if (!this.chains.has(chatKey)) this.chains.set(chatKey, createSendChain());
    return this.chains.get(chatKey);
  }

  #checkRate(chatKey) {
    const now = Date.now();
    const cfg = getConfig().send;
    const maxMin = Number(cfg.maxPerMinute) || 0;
    const maxHour = Number(cfg.maxPerHour) || 0;
    if (maxMin <= 0 && maxHour <= 0) return;   // 0/缺省 = 不限速（主人已取消频率限制）
    const minute = (this.minuteTimes.get(chatKey) || []).filter((t) => now - t < 60000);
    const hour = (this.hourTimes.get(chatKey) || []).filter((t) => now - t < 3600000);
    if (maxMin > 0 && minute.length >= maxMin) {
      throw new Error(`发送频率超限（每分钟最多 ${maxMin} 条），请等一会再发`);
    }
    if (maxHour > 0 && hour.length >= maxHour) {
      throw new Error(`发送频率超限（每小时最多 ${maxHour} 条）`);
    }
    minute.push(now);
    hour.push(now);
    this.minuteTimes.set(chatKey, minute);
    this.hourTimes.set(chatKey, hour);
  }

  // 气泡间隔：模拟真人打字节奏（2026-10-22）
  // 旧版是 1~3 秒的"思考停顿"，多气泡连发时显得拖沓；现在按上一句字数估时，
  // 默认 400~1000ms（20 字以内基本 400~800ms），人味更足也不磨蹭。
  #gap(text, isLast) {
    if (isLast) return 0;
    const cfg = getConfig().send;
    const min = Math.max(150, Number(cfg.minGapMs) || 400);
    const max = Math.max(min, Number(cfg.maxGapMs) || 1000);
    const perChar = Number.isFinite(Number(cfg.byLengthMs)) ? Number(cfg.byLengthMs) : 40;
    return bubbleDelay(text, { min, max, perChar });
  }

  /**
   * 发送一批文本消息（一条或多条）。
   * options: { replyToMessageId, atUserId }
   * 返回 { sent: [{text, messageId}], failed: [{text, error}] }；全部失败时抛错。
   */
  async sendTextBatch(chatKey, messages, options = {}) {
    const [kind, id] = String(chatKey).split(':');
    if (kind !== 'group' && kind !== 'private') throw new Error(`非法会话 key：${chatKey}`);
    const list = Array.isArray(messages) ? messages : [messages];
    if (!list.length) throw new Error('消息列表为空');
    const cfgSend = getConfig().send || {};
    const hardSplitAt = Number(cfgSend.hardSplitAt) || 0;
    // ── 多气泡（2026-10-22）──
    // 以前一条 LLM 回复 = 一个气泡，多行文字靠 \n 硬换行，手机端堆成一大坨。
    // 现在先按行/空行拆成多条，逐条独立发送（代码块整体保留，表格续行不切）。
    const doSplit = cfgSend.splitBubbles !== false;
    const maxBubbleChars = Number(cfgSend.maxBubbleChars) || 220;
    // ── 兜底硬切（2026-10-23）──
    // 规则 11 要求单条 10~25 字，但模型偶发「一句话吐 70 字不分片」。这里做物理保险：
    // 非代码单条超过 bubbleChunkAt（默认 60）就按空格/顿号切成 bubbleChunkChars（默认 25）以内。
    // 代码块、表格整块豁免。bubbleChunkAt = 0 关闭。
    const chunkAt = cfgSend.bubbleChunkAt === undefined ? 60 : (Number(cfgSend.bubbleChunkAt) || 0);
    const chunkChars = Number(cfgSend.bubbleChunkChars) || 25;
    // 单轮气泡硬上限（2026-10-24）：规则 12 要求一次最多 3 条，模型不听话时这里兜底。
    // 超过的部分并进第 3 条（不再发第 4 条），物理上刷不了屏。0/缺省 = 不限制（沿用旧的 8）。
    const maxPerReply = cfgSend.maxBubblesPerReply === undefined ? 8 : (Number(cfgSend.maxBubblesPerReply) || 0);
    const parts = [];
    for (const m of list) {
      const rawText = String(m ?? '');
      if (!rawText.trim()) continue;
      const bubbles = doSplit
        ? splitBubbles(rawText, { maxChars: maxBubbleChars, hardMax: chunkAt, chunkMax: chunkChars, maxBubbles: maxPerReply })
        : [rawText];
      for (const bubble of bubbles) {
        let plain = mdToPlain(bubble);
        if (!plain) continue;
        // 统一清洗模型偶尔夹带的 XML 工具调用残留（</parameter></invoke></tool_calls> 等）
        plain = plain
          .replace(/<\/?[a-zA-Z][^>]*>/g, '')
          .replace(/<\/?parameter>|<\/?invoke>|<\/?tool_calls>|<\/?function_calls>|<\/?search_attempts>/gi, '')
          .replace(/^\s*<\/?[a-zA-Z]+/gm, '')
          .replace(/[ \t]+\n/g, '\n')
          .replace(/\n{3,}/g, '\n\n')
          .trim();
        if (!plain) continue;
        if (hardSplitAt > 0 && plain.length > hardSplitAt) parts.push(...splitForQQ(plain, hardSplitAt));
        else parts.push(plain);
      }
    }
    if (!parts.length) throw new Error('消息内容为空');

    // ── 引用闸门（2026-10-22）──
    // 默认不再挂 [CQ:reply]：QQ 的灰色引用框在手机上极占地方，真人日常聊天几乎不引用。
    // 群内常规响应 = 纯文本，需要点名就只用 [CQ:at,qq=用户]。
    // 想要恢复旧行为：config.send.allowQuote = true。
    const allowQuote = cfgSend.allowQuote === true;
    const quoteId = allowQuote ? (options.replyToMessageId ?? null) : null;

    const chain = this.#chain(chatKey);
    const promises = [];
    for (let i = 0; i < parts.length; i++) {
      const text = parts[i];
      const isLast = i === parts.length - 1;
      const gap = this.#gap(text, isLast);
      promises.push(chain(async () => {
        this.#checkRate(chatKey);
        if (gap > 0) await sleep(gap);
        const data = await this.onebot.sendText(kind, id, text, {
          replyToMessageId: i === 0 ? quoteId : null, // 引用挂在第一条上（默认已关闭，见上方闸门）
          atUserId: i === 0 ? options.atUserId : null,
          // 群临时会话：非好友的群成员必须带 group_id 才能私聊
          extraGroupId: options.extraGroupId ?? null,
        });
        const ts = Date.now();
        this.store.appendSelf(chatKey, { text, ts });
        this.onSent?.({ chatKey, text, messageId: data?.message_id ?? null });
        return { text, messageId: data?.message_id ?? null, at: formatClockTime(ts) };
      }));
    }

    const settled = await Promise.allSettled(promises);
    const sent = [];
    const failed = [];
    for (const r of settled) {
      if (r.status === 'fulfilled') sent.push(r.value);
      else failed.push({ error: String(r.reason?.message ?? r.reason) });
    }
    if (sent.length === 0 && failed.length > 0) {
      throw new Error(failed.map((f) => f.error).join('；'));
    }
    return { sent, failed };
  }

  /**
   * 发送语音 / 视频 / 文件（AstrBot 兼容层用）。
   * 这几类以前在兼容层里被静默丢弃：插件回了语音，用户端一片安静。
   * 走 §chain + 限频，和文本/图片同一套排队规则，避免突发把号发风控。
   */
  sendMedia(chatKey, kind, src, name) {
    const [chatKind, id] = String(chatKey).split(':');
    if (chatKind !== 'group' && chatKind !== 'private') return Promise.reject(new Error(`非法会话 key：${chatKey}`));
    if (!src) return Promise.reject(new Error('媒体地址为空'));
    const chain = this.#chain(chatKey);
    return chain(async () => {
      this.#checkRate(chatKey);
      if (kind === 'file') {
        const data = await this.onebot.sendFile(chatKind, id, src, name);
        this.store.appendSelf(chatKey, { text: `[文件:${name || String(src).split('/').pop()}]`, ts: Date.now() });
        this.onSent?.({ chatKey, text: '[文件]', messageId: data?.file_id ?? null });
        return data;
      }
      if (!/^(https?:\/\/|base64:\/\/|file:\/\/)/i.test(String(src)) && !String(src).startsWith('/')) {
        throw new Error(`不支持的${kind}地址（只接受 http(s)/base64/file/绝对路径）：${String(src).slice(0, 60)}`);
      }
      const seg = kind === 'record' ? 'record' : 'video';
      const data = await this.onebot.sendSegments(chatKind, id, [{ type: seg, data: { file: String(src) } }]);
      const label = seg === 'record' ? '语音' : '视频';
      this.store.appendSelf(chatKey, { text: `[${label}]`, ts: Date.now() });
      this.onSent?.({ chatKey, text: `[${label}]`, messageId: data?.message_id ?? null });
      return data;
    });
  }

  /** 上传文件到当前会话（产物交付用）。 */
  sendFile(chatKey, filePath, fileName) {
    const [kind, id] = String(chatKey).split(':');
    const chain = this.#chain(chatKey);
    return chain(async () => {
      const data = await this.onebot.sendFile(kind, id, filePath, fileName);
      const ts = Date.now();
      this.store.appendSelf(chatKey, { text: `[文件:${fileName || String(filePath).split('/').pop()}]`, ts });
      this.onSent?.({ chatKey, text: '[文件]', messageId: data?.file_id ?? null });
      return data;
    });
  }

  /** 发送一张任意图片（独立气泡，URL 或本地路径）。 */
  sendImage(chatKey, imageUrl, options = {}) {
    const [kind, id] = String(chatKey).split(':');
    const chain = this.#chain(chatKey);
    return chain(async () => {
      this.#checkRate(chatKey);
      await sleep(randInt(500, 1200));
      const data = await this.onebot.sendImage(kind, id, imageUrl, {
        replyToMessageId: getConfig().send?.allowQuote === true ? (options.replyToMessageId ?? null) : null,
        atUserId: options.atUserId ?? null
      });
      const ts = Date.now();
      this.store.appendSelf(chatKey, { text: `[图片:${String(imageUrl).split('/').pop().slice(0, 60)}]`, ts });
      this.onSent?.({ chatKey, text: '[图片]', messageId: data?.message_id ?? null });
      return { message_id: data?.message_id ?? null };
    });
  }

  /** 发送一个收藏表情（独立气泡）。 */
  sendSticker(chatKey, sticker, options = {}) {
    const [kind, id] = String(chatKey).split(':');
    const chain = this.#chain(chatKey);
    return chain(async () => {
      this.#checkRate(chatKey);
      await sleep(randInt(600, 1500)); // 发表情前真人式的短暂停顿
      const data = await this.onebot.sendSticker(kind, id, sticker.url, {
        replyToMessageId: getConfig().send?.allowQuote === true ? (options.replyToMessageId ?? null) : null,
        atUserId: options.atUserId ?? null
      });
      const ts = Date.now();
      this.store.appendSelf(chatKey, { text: `[表情包:${sticker.desc || sticker.localNote || sticker.id}]`, ts });
      this.onSent?.({ chatKey, text: `[表情包]`, messageId: data?.message_id ?? null, sticker: sticker.id });
      return { message_id: data?.message_id ?? null };
    });
  }

  /** 拍一拍。发送成功后留档（self 记录），否则下一次运行不知道自己拍过。 */
  poke(chatKey, targetUserId) {
    const [kind, id] = String(chatKey).split(':');
    const chain = this.#chain(chatKey);
    return chain(async () => {
      await sleep(randInt(300, 900));
      const data = await this.onebot.sendPoke(kind, id, targetUserId);
      const ts = Date.now();
      const target = kind === 'group' && targetUserId != null ? ` ${targetUserId}` : '对方';
      this.store.appendSelf(chatKey, { text: `[拍一拍] 你拍了拍${target}`, ts });
      this.onSent?.({ chatKey, text: `[拍一拍]${target}`, messageId: null });
      return data;
    });
  }
}
