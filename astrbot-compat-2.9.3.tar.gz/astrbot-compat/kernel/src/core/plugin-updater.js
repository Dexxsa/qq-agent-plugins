// ── 插件内核 · 自动更新 ─────────────────────────────────────────────────
//
// 目标：**打开控制台就自动更新**，不用每次让人手动「导入插件包」。
//
// 工作方式：
//   1. 前端每次打开插件页都会 GET /api/plugins；
//   2. 该请求顺带触发 tick()（不阻塞响应，后台跑）；
//   3. tick() 从分发源拉 manifest.json，比对本地 plugins/<id>/manifest.json 的版本；
//   4. 有新版 → 下载 tar.gz → 校验 sha256 → 备份旧目录 → 覆盖安装 → 热重载；
//   5. 结果写进 data/plugin-update-state.json，随下一次 /api/plugins 返回给前端。
//
// 设计取舍：
//   · **只更新已装的插件，不自动装新的**。自动装新插件会让人莫名多出一堆功能，
//     而且 plugins.update.installNew 是显式开关。
//   · **节流**：默认 30 分钟最多查一次（manifest 很小，但不该每次刷新页面都出网）。
//   · **更新失败绝不影响现网**：先整目录备份，装失败自动回滚。
//   · 依赖目录（node_modules / .venv）在覆盖安装时**保留**，否则每次更新都要重装依赖。
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { request } from 'undici';
import { ROOT, DATA_DIR, getConfig } from '../config.js';

const PLUGINS_DIR = path.join(ROOT, 'plugins');
const DIST_DIR = path.join(DATA_DIR, 'plugin-dist');
const BACKUP_DIR = path.join(DATA_DIR, 'plugin-backup');
const STATE_FILE = path.join(DATA_DIR, 'plugin-update-state.json');

/** 内置默认分发源（维护者的机器）。可用 pluginUpdates.source 或环境变量覆盖。 */
const DEFAULT_SOURCE = 'http://47.109.200.113:8082/api/plugins/dist';

/** 覆盖安装时**保留**的目录：依赖不该被插件包覆盖掉。 */
const KEEP_ON_REPLACE = new Set(['node_modules', '.venv', 'venv', '__pycache__', '.git']);

const MAX_PACKAGE_BYTES = 32 * 1024 * 1024;

// ── 版本比较 ───────────────────────────────────────────────────────────

/**
 * 宽松版本比较（支持 1.2.3、0.2.0-qq.6、v2 这类写法）。
 * @returns {number} >0 表示 a 比 b 新
 *
 * 规则：按 . - _ + 切段；数字段按数值比，字符段按字典序；
 * 段数不同时**长者更新**（0.2.0-qq.6 > 0.2.0）。
 * 注意：这不符合 semver 的「预发布版本更小」，但对插件自更新足够——
 * 我们要的是"新号大于旧号"，而不是严格语义。
 */
export function compareVersion(a, b) {
  const tok = (v) => String(v ?? '').trim().replace(/^v/i, '')
    .split(/[.\-+_~]/).filter((s) => s !== '')
    .map((s) => (/^\d+$/.test(s) ? Number(s) : s));
  const ta = tok(a);
  const tb = tok(b);
  for (let i = 0; i < Math.max(ta.length, tb.length); i += 1) {
    const x = ta[i];
    const y = tb[i];
    if (x === undefined) return -1;
    if (y === undefined) return 1;
    if (typeof x === 'number' && typeof y === 'number') {
      if (x !== y) return x > y ? 1 : -1;
      continue;
    }
    if (typeof x === 'number') return -1;      // 数字段 < 字符段
    if (typeof y === 'number') return 1;
    if (x !== y) return x > y ? 1 : -1;
  }
  return 0;
}

function sha256(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex');
}

// ── HTTP ──────────────────────────────────────────────────────────────

async function httpGet(url, { binary = false, maxBytes = 8 * 1024 * 1024, timeout = 15000 } = {}) {
  const res = await request(url, {
    method: 'GET',
    headers: { 'user-agent': 'qq-agent/plugin-updater' },
    headersTimeout: timeout,
    bodyTimeout: timeout,
    maxRedirections: 3
  });
  if (res.statusCode !== 200) {
    try { res.body.dump(); } catch { /* 忽略 */ }
    throw new Error(`HTTP ${res.statusCode}`);
  }
  const chunks = [];
  let total = 0;
  for await (const chunk of res.body) {
    total += chunk.length;
    if (total > maxBytes) {
      try { res.body.destroy(); } catch { /* 忽略 */ }
      throw new Error(`响应超过 ${Math.round(maxBytes / 1024 / 1024)}MB`);
    }
    chunks.push(chunk);
  }
  const buf = Buffer.concat(chunks);
  return binary ? buf : buf.toString('utf8');
}

// ── 主逻辑 ────────────────────────────────────────────────────────────

export function createPluginUpdater({ host, install, log = () => {} }) {
  let running = false;
  let lastRunAt = 0;

  const state = loadState();

  /**
   * 源地址如果指向**本机**，改走 127.0.0.1:<控制台端口>。
   *
   * 为什么必须这么做：默认源写的是公网地址（别人机器要用），但对本机来说
   * 那就是绕一圈外网回自己家 —— 8082 前面有 nginx 的 HTTP Basic，
   * 服务自己当然没有密码，于是拿到 401，自动更新永远失败。
   */
  function localizeSource(base) {
    try {
      const u = new URL(base);
      const port = Number(getConfig()?.server?.port) || 3210;
      const selfNames = new Set(['127.0.0.1', 'localhost', '0.0.0.0', '::1', os.hostname()]);
      for (const list of Object.values(os.networkInterfaces() || {})) {
        for (const ni of list || []) {
          if (ni && ni.address) selfNames.add(ni.address);
        }
      }
      if (!selfNames.has(u.hostname)) return base;
      u.protocol = 'http:';
      u.hostname = '127.0.0.1';
      u.port = String(port);
      return u.toString().replace(/\/+$/, '');
    } catch {
      return base;
    }
  }

  function cfgOf() {
    const c = getConfig()?.pluginUpdates || {};
    const raw = process.env.QQ_AGENT_UPDATE_SOURCE || c.source || DEFAULT_SOURCE;
    const sources = (Array.isArray(raw) ? raw : [raw])
      .map((s) => String(s || '').trim().replace(/\/+$/, ''))
      .filter(Boolean)
      .map(localizeSource);
    return {
      enabled: c.enabled !== false,
      autoApply: c.autoApply !== false,
      installNew: c.installNew === true,
      intervalMs: Math.max(1, Number(c.intervalMinutes) || 30) * 60 * 1000,
      sources
    };
  }

  function loadState() {
    try {
      return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    } catch {
      return { lastCheckAt: 0, lastResult: 'never', lastError: '', pending: [], applied: [] };
    }
  }

  function saveState(patch) {
    Object.assign(state, patch);
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      const tmp = `${STATE_FILE}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify(state, null, 2), 'utf8');
      fs.renameSync(tmp, STATE_FILE);
    } catch (error) {
      log('[updater] 状态保存失败:', error?.message ?? error);
    }
  }

  /** 本地已装插件的 { id: version } */
  function localVersions() {
    const out = {};
    for (const rec of host.records.values()) {
      const v = rec?.manifest?.version;
      if (v) out[rec.id] = String(v);
      else if (fs.existsSync(path.join(PLUGINS_DIR, rec.id, 'manifest.json'))) {
        try {
          out[rec.id] = String(JSON.parse(fs.readFileSync(path.join(PLUGINS_DIR, rec.id, 'manifest.json'), 'utf8')).version || '0');
        } catch { /* 忽略 */ }
      }
    }
    return out;
  }

  /** 从分发源拉 manifest.json，返回 { base, manifest }；全部源失败则抛错。 */
  async function fetchManifest(sources) {
    const errors = [];
    for (const base of sources) {
      try {
        const text = await httpGet(`${base}/manifest.json?t=${Date.now()}`, { maxBytes: 2 * 1024 * 1024 });
        const data = JSON.parse(text);
        if (!data || typeof data !== 'object' || !data.plugins) {
          throw new Error('manifest 缺少 plugins 字段');
        }
        return { base, manifest: data };
      } catch (error) {
        errors.push(`${base}: ${error?.message ?? error}`);
      }
    }
    throw new Error(`所有更新源都不可用（${errors.join('；')}）`);
  }

  /** 只比对，不下载。 */
  async function check({ force = false } = {}) {
    const cfg = cfgOf();
    if (!cfg.enabled) return { ok: false, error: '自动更新已关闭', disabled: true };
    if (running) return { ok: false, error: '正在检查中' };

    running = true;
    try {
      const { base, manifest } = await fetchManifest(cfg.sources);
      const local = localVersions();
      const pending = [];
      const unknown = [];

      for (const [id, info] of Object.entries(manifest.plugins || {})) {
        const remote = String(info?.version || '');
        if (!remote || !info?.file) continue;
        const cur = local[id];
        if (cur === undefined) {
          if (cfg.installNew) pending.push({ id, from: '', to: remote, file: info.file, sha256: info.sha256 || '', note: info.note || '', isNew: true });
          else unknown.push(id);
          continue;
        }
        if (compareVersion(remote, cur) > 0) {
          pending.push({ id, from: cur, to: remote, file: info.file, sha256: info.sha256 || '', note: info.note || '' });
        }
      }

      saveState({
        lastCheckAt: Date.now(),
        lastResult: 'ok',
        lastError: '',
        source: base,
        pending,
        unknown
      });

      if (pending.length) {
        log(`[updater] 发现 ${pending.length} 个插件可更新：${pending.map((p) => `${p.id} ${p.from || '未装'}→${p.to}`).join('，')}`);
      }

      if (pending.length && cfg.autoApply) {
        return { ok: true, pending, applied: await applyPending(base, pending) };
      }
      return { ok: true, pending, applied: [] };
    } catch (error) {
      saveState({ lastCheckAt: Date.now(), lastResult: 'error', lastError: String(error?.message ?? error) });
      log('[updater] 检查失败:', error?.message ?? error);
      return { ok: false, error: String(error?.message ?? error) };
    } finally {
      running = false;
      lastRunAt = Date.now();
    }
  }

  /**
   * 覆盖安装前把旧目录整体挪走。
   * 不直接删：装失败要能原样放回去，否则一次失败的更新会把插件彻底搞没。
   */
  function backupPlugin(id) {
    const src = path.join(PLUGINS_DIR, id);
    if (!fs.existsSync(src)) return null;
    const dst = path.join(BACKUP_DIR, `${id}-${Date.now()}`);
    try {
      fs.mkdirSync(BACKUP_DIR, { recursive: true });
      fs.renameSync(src, dst);
      return dst;
    } catch (error) {
      log(`[updater] ${id} 备份失败:`, error?.message ?? error);
      return null;
    }
  }

  /** 把备份里旧的依赖目录塞回新装的插件（依赖不该被包覆盖）。 */
  function restoreDeps(id, backupDirPath) {
    if (!backupDirPath) return;
    const target = path.join(PLUGINS_DIR, id);
    for (const name of KEEP_ON_REPLACE) {
      const from = path.join(backupDirPath, name);
      if (!fs.existsSync(from)) continue;
      try {
        fs.cpSync(from, path.join(target, name), { recursive: true, force: true });
      } catch (error) {
        log(`[updater] ${id} 依赖目录 ${name} 迁移失败:`, error?.message ?? error);
      }
    }
  }

  async function applyOne(base, item) {
    const wasEnabled = host.records.get(item.id)?.status === 'enabled';
    // manifest 里的 file 允许是 "package?name=xxx" 这种相对路径
    const buf = await httpGet(`${base}/${String(item.file).replace(/^\/+/, '')}`, {
      binary: true, maxBytes: MAX_PACKAGE_BYTES, timeout: 60000
    });
    if (item.sha256 && sha256(buf) !== String(item.sha256).toLowerCase()) {
      throw new Error('sha256 校验失败（包可能损坏或被替换）');
    }

    // 先停用，避免旧代码还在跑的时候目录被换掉
    const rec = host.records.get(item.id);
    if (rec) await host.disable(item.id).catch(() => {});

    const backup = backupPlugin(item.id);
    let result;
    try {
      result = await install({ base64: buf.toString('base64'), mode: 'replace', preserveConfig: true });
    } catch (error) {
      result = { ok: false, error: String(error?.message ?? error) };
    }

    if (!result?.ok) {
      // 回滚：把备份放回去，重新装载旧版本
      if (backup) {
        try {
          fs.rmSync(path.join(PLUGINS_DIR, item.id), { recursive: true, force: true });
          fs.renameSync(backup, path.join(PLUGINS_DIR, item.id));
          const oldManifest = JSON.parse(fs.readFileSync(path.join(PLUGINS_DIR, item.id, 'manifest.json'), 'utf8'));
          await host.enable(oldManifest).catch(() => {});
          log(`[updater] ${item.id} 更新失败，已回滚到 ${item.from}`);
        } catch (error) {
          log(`[updater] ${item.id} 回滚失败（插件可能不可用，备份在 ${backup}）:`, error?.message ?? error);
        }
      }
      throw new Error(result?.error || '安装失败');
    }

    restoreDeps(item.id, backup);
    if (backup) fs.rmSync(backup, { recursive: true, force: true });

    // 原本是停用的，更新后不该偷偷启起来
    if (!wasEnabled && !item.isNew) {
      await host.disable(item.id).catch(() => {});
      host.records.get(item.id)?.config?.set({ enabled: false });
    }

    log(`[updater] ${item.id} 已更新 ${item.from || '（新装）'} → ${item.to}`);
    return { id: item.id, from: item.from, to: item.to, ok: true };
  }

  async function applyPending(base, pending) {
    const applied = [];
    for (const item of pending) {
      try {
        applied.push(await applyOne(base, item));
      } catch (error) {
        applied.push({ id: item.id, from: item.from, to: item.to, ok: false, error: String(error?.message ?? error) });
        log(`[updater] ${item.id} 更新失败:`, error?.message ?? error);
      }
    }
    const okCount = applied.filter((a) => a.ok).length;
    saveState({
      applied: [...applied.map((a) => ({ ...a, at: Date.now() })), ...(state.applied || [])].slice(0, 30),
      pending: applied.filter((a) => !a.ok).map((a) => pending.find((p) => p.id === a.id)).filter(Boolean),
      lastResult: okCount === applied.length ? 'ok' : 'partial'
    });
    return applied;
  }

  /** 手动触发（面板「立即检查」/「立即更新」）。 */
  async function checkNow() {
    return check({ force: true });
  }

  async function applyNow() {
    const cfg = cfgOf();
    if (running) return { ok: false, error: '正在更新中' };
    const pending = (state.pending || []).filter((p) => p && p.file);
    if (!pending.length) {
      const r = await check({ force: true });
      if (!r.ok) return r;
      return { ok: true, applied: r.applied || [], pending: r.pending || [] };
    }
    running = true;
    try {
      const applied = await applyPending(state.source || cfg.sources[0], pending);
      return { ok: true, applied };
    } finally {
      running = false;
      lastRunAt = Date.now();
    }
  }

  /**
   * 非阻塞的周期检查：控制台每次读插件列表都会调它。
   * 处理顺序：跑着就直接返回 → 未到间隔直接返回 → 后台起一次 check。
   */
  function tick() {
    const cfg = cfgOf();
    if (!cfg.enabled || running) return;
    if (Date.now() - (state.lastCheckAt || 0) < cfg.intervalMs) return;
    if (Date.now() - lastRunAt < 60 * 1000) return;      // 兜底：失败也别一分钟内反复重试
    // 故意不 await：不能让「打开插件页」卡在网络上。
    // running 由 check 自己同步置位（同一 tick 内没有 await，不会并发进来）。
    setImmediate(() => { check({ force: false }).catch(() => {}); });
  }

  /** 给前端看的摘要（不含内部路径）。 */
  function snapshot() {
    const cfg = cfgOf();
    const recent = (state.applied || []).filter((a) => Date.now() - (a.at || 0) < 10 * 60 * 1000);
    return {
      enabled: cfg.enabled,
      autoApply: cfg.autoApply,
      running,
      source: state.source || cfg.sources[0] || '',
      intervalMinutes: Math.round(cfg.intervalMs / 60000),
      lastCheckAt: state.lastCheckAt || 0,
      lastResult: state.lastResult || 'never',
      lastError: state.lastError || '',
      pending: (state.pending || []).map((p) => ({ id: p.id, from: p.from, to: p.to, note: p.note || '' })),
      recentApplied: recent.map((a) => ({ id: a.id, from: a.from, to: a.to, ok: a.ok !== false, error: a.error || '' }))
    };
  }

  return { tick, check, checkNow, applyNow, snapshot, compareVersion };
}

// ── 分发端（把本机插件打包成别人可拉取的静态目录）────────────────────
//
// 维护者改完插件后跑 `node scripts/publish-plugins.mjs`，
// 生成的 manifest.json + 包文件就落在这里，其它机器的 updater 直接 GET。

export const DIST_ROOT = DIST_DIR;

export function distManifestPath() {
  return path.join(DIST_DIR, 'manifest.json');
}
