#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AstrBot 插件运行器（BG-QQagent · astrbot-compat）

一个插件一个进程。stdin/stdout 走 JSON Lines 协议，stderr 当日志。

为什么要独立进程而不是把 Python 塞进 Node：
  · 插件依赖的 pip 包互相打架时，进程隔离是唯一的兜底
  · 插件写出死循环 / 崩掉，只影响它自己
  · 卸载插件 = 杀进程，不留残余 import 状态

协议（Node → Python）
  {"type":"event","id":"r1","text":"/古诗 李白","chat":{...},"user":{...},
   "selfId":"...","messageId":"...","isAdmin":false}
  {"type":"ping"} / {"type":"shutdown"}

协议（Python → Node）
  {"type":"ready","name":"...","version":"...","commands":["古诗"],
   "unsupported":["llm_tool"],"warnings":[...]}
  {"type":"result","id":"r1","matched":true,"actions":[...],"error":null}
  {"type":"log","level":"info","text":"..."}

关键设计（踩过的坑）
  · 插件里的 print() 会污染协议流 → 启动后把 fd 1 重定向到 stderr，
    协议只走 dup 出来的私有 fd。
  · 装饰器顺序不保证 → 同一个 handler 上可能有多个 filter，按「全部满足」判定。
"""

import argparse
import asyncio
import importlib.util
import inspect
import io
import json
import os
import re
import sys
import traceback
import types


# ══════════════════════════════════════════════════════════════
#  协议输出（独立 fd，插件看不到）
# ══════════════════════════════════════════════════════════════

class Channel:
    def __init__(self):
        self._fd = os.dup(1)
        self._out = io.TextIOWrapper(os.fdopen(self._fd, 'wb'), encoding='utf-8', newline='\n')

    def send(self, obj):
        try:
            self._out.write(json.dumps(obj, ensure_ascii=False) + '\n')
            self._out.flush()
        except Exception:
            pass


CH = None


def log(level, text):
    try:
        sys.stderr.write('[runner:%s] %s\n' % (level, text))
        sys.stderr.flush()
    except Exception:
        pass


def _schema_default(spec):
    """按 _conf_schema.json 的一项推出默认值。

    坑：`type: object` 的条目，"default" 往往是 null，真正的默认值写在
    `items` 子模式里（图片审查插件的 sightengine_config 就是这种）。
    只取 top-level default 的话，插件拿到 None 再来个 `.get()` 就崩在
    构造函数里 —— 表现为"插件装上了但一条命令都没有"。
    """
    if not isinstance(spec, dict):
        return None
    t = spec.get('type')
    val = spec.get('default', None)
    if val is not None:
        return val
    if t == 'object':
        items = spec.get('items') or {}
        return {k: _schema_default(v) for k, v in items.items()} if isinstance(items, dict) else {}
    if t == 'list':
        return []
    if t == 'template_list':
        # AstrBot 面板里的「模板列表」：default 常写成 null，插件会直接 for 遍历
        # （hydrus 的 tags_alias 就是这样，None 一遍历就崩在 __init__ 里）
        return []
    if t == 'bool':
        return False
    if t in ('int', 'float'):
        return 0
    if t == 'string':
        return ''
    return None


def _deep_merge(base, extra):
    """面板里的用户值覆盖默认值；嵌套字典逐层合并，不整块替换。"""
    out = dict(base or {})
    for k, v in (extra or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


# ══════════════════════════════════════════════════════════════
#  metadata.yaml 极简解析（不引入 PyYAML：很多插件 requirements 里没有它）
# ══════════════════════════════════════════════════════════════

def parse_metadata_lite(path):
    meta = {}
    try:
        with open(path, encoding='utf-8') as fh:
            for line in fh:
                raw = line.rstrip('\n')
                if not raw.strip() or raw.lstrip().startswith('#'):
                    continue
                m = re.match(r'^([A-Za-z0-9_\-]+)\s*:\s*(.*)$', raw)
                if not m:
                    continue
                key, val = m.group(1), m.group(2).strip()
                if val.startswith('|') or val.startswith('>'):
                    val = ''
                quoted = ((val.startswith('"') and val.endswith('"'))
                          or (val.startswith("'") and val.endswith("'")))
                if quoted:
                    val = val[1:-1]
                else:
                    # yaml 的行内注释：`#` 前面必须有空格。
                    # 不清掉的话 `version: v0.0.1  # 插件版本号` 会整段被当成版本号。
                    cut = val.find(' #')
                    if cut > 0:
                        val = val[:cut].rstrip()
                meta[key] = val
    except Exception as exc:
        log('warn', 'metadata.yaml 解析失败: %s' % exc)
    return meta


# ══════════════════════════════════════════════════════════════
#  桥：收集 context.send_message / event.send 直接发出去的内容
# ══════════════════════════════════════════════════════════════

class Bridge:
    def __init__(self):
        self.bucket = []
        # LLM 桥接：一次补全 = 一个 c-id + 一个 future
        self.llm_seq = 0
        self.llm_pending = {}

    def enqueue(self, chain):
        for comp in chain:
            self.bucket.append(comp)

    def drain(self):
        out = self.bucket
        self.bucket = []
        return out

    # ── LLM 桥接 ──────────────────────────────────────────────
    async def call_llm(self, messages, temperature=None, max_tokens=None,
                       tools=None, timeout=180.0):
        """把一次补全请求转给内核，等它把正文拿回来。

        为什么不在这里直接发 HTTP：模型地址与密钥都在内核的 config.json 里，
        插件进程不该有第二份，也不该为了调一次模型去读宿主的配置。
        走同一条 stdin/stdout 协议，还顺便继承了内核的主备通道切换与冷却逻辑。

        抛 RuntimeError 而不是静默返回空串：插件的 try/except 通常会把异常
        变成「模型暂时不可用」的提示，比返回空串让插件以为「模型答了个空」好排查。
        """
        loop = asyncio.get_running_loop()
        self.llm_seq += 1
        cid = 'c%d' % self.llm_seq
        fut = loop.create_future()
        self.llm_pending[cid] = fut
        CH.send({'type': 'llm', 'id': cid, 'messages': messages,
                 'temperature': temperature, 'maxTokens': max_tokens, 'tools': tools})
        try:
            res = await asyncio.wait_for(fut, timeout=timeout)
        except asyncio.TimeoutError:
            raise RuntimeError('模型响应超时（%d 秒）' % int(timeout))
        finally:
            self.llm_pending.pop(cid, None)
        if res.get('error'):
            raise RuntimeError(str(res.get('error')))
        return res.get('text') or ''

    def save_config(self, cfg):
        """把插件改过的配置送回 Node 落盘（context/config.save_config 用）。

        配置文件（CONFIG_DIR/<origin>.json）由 Node 独家写：Python 侧只发
        消息不同步写文件，避免两边同时写同一份 JSON。Node 收到后合并落盘
        并更新指纹，这样下次 syncConfig 不会拿旧内存态把它覆盖回去。
        """
        try:
            CH.send({'type': 'config_save', 'config': dict(cfg)})
            return True
        except Exception:
            return False


async def _read_loop(bridge, queue):
    """独立读循环。

    必须和「处理 event」分开：插件在 handler 里等模型回包时，主协程是挂起的，
    如果读 stdin 也挂在主协程里，llm_result 永远读不到 —— 死锁到超时。
    """
    loop = asyncio.get_running_loop()
    while True:
        line = await loop.run_in_executor(None, sys.stdin.readline)
        if not line:
            await queue.put(None)
            return
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except Exception:
            continue
        typ = req.get('type')
        if typ == 'shutdown':
            await queue.put(None)
            return
        if typ == 'ping':
            CH.send({'type': 'pong', 'id': req.get('id')})
            continue
        if typ == 'llm_result':
            fut = bridge.llm_pending.get(req.get('id'))
            if fut is not None and not fut.done():
                fut.set_result(req)
            continue
        if typ == 'event':
            await queue.put(req)



# ══════════════════════════════════════════════════════════════
#  组件 → 动作
# ══════════════════════════════════════════════════════════════

def _absorb(act, parts, images, medias):
    """把子动作归到对应桶里：文本进正文，图片进 images，语音/视频/文件进 medias。"""
    k = act.get('kind')
    if k == 'text' and act.get('text'):
        parts.append(act['text'])
    elif k == 'image':
        src = act.get('url') or act.get('file')
        if src:
            images.append(src)
        else:
            parts.append('[图片]')
    elif k in ('record', 'video', 'file'):
        src = act.get('url') or act.get('file')
        if src:
            medias.append({'kind': k, 'src': src, 'name': act.get('name') or ''})
    for extra in (act.get('images') or []):
        images.append(extra)
    for m in (act.get('medias') or []):
        medias.append(m)


def comp_to_action(comp):
    name = type(comp).__name__
    data = comp.to_dict() if hasattr(comp, 'to_dict') else {'type': 'plain', 'text': str(comp)}
    t = data.get('type')
    if t == 'plain':
        return {'kind': 'text', 'text': str(data.get('text') or '')}
    if t == 'image':
        return {'kind': 'image', 'url': data.get('url'), 'file': data.get('file')}
    if t == 'at':
        return {'kind': 'at', 'qq': data.get('qq'), 'name': data.get('name')}
    if t in ('node', 'forward', 'nodes'):
        parts = []
        # Nodes 是容器（type='nodes'），真正的组件藏在每个 Node.content 里。
        # 老代码只认 node/forward，遇到 Nodes 容器就掉进兜底 str(comp)，
        # 用户看到的是「<Nodes {}>」这种空壳。
        subs = []
        if t == 'nodes':
            for nd in (getattr(comp, 'nodes', None) or []):
                inner = getattr(nd, 'content', None)
                if isinstance(inner, list):
                    subs.extend(inner)
                elif isinstance(inner, str):
                    subs.append(inner)
                elif inner is not None:
                    subs.append(inner)
        else:
            subs = list(getattr(comp, 'content', None) or [])
        images = []
        medias = []
        for sub in subs:
            if isinstance(sub, str):
                parts.append(sub)
                continue
            # to_dict 展开后的裸字典（少数插件直接塞 dict）
            if isinstance(sub, dict):
                _ty = sub.get('type')
                _d = sub.get('data') or {}
                if _ty == 'text':
                    parts.append(str(_d.get('text') or sub.get('text') or ''))
                elif _ty == 'image':
                    _src = _d.get('file') or sub.get('url') or sub.get('file') or _d.get('url')
                    if _src:
                        images.append(_src)
                    else:
                        parts.append('[图片]')
                continue
            # 有的插件把 MessageEventResult 直接塞进 Node.content，
            # 这里要顺着 .chain 展开，否则会打出对象地址这种垃圾。
            inner = getattr(sub, 'chain', None)
            if isinstance(inner, list):
                for c2 in inner:
                    _absorb(comp_to_action(c2), parts, images, medias)
                continue
            if hasattr(sub, 'to_dict'):
                _absorb(comp_to_action(sub), parts, images, medias)
        out = {'kind': 'text', 'text': '\n'.join([p for p in parts if p])}
        if images:
            out['images'] = images
        if medias:
            out['medias'] = medias
        return out
    if t == 'record':
        return {'kind': 'record', 'file': data.get('file'), 'url': data.get('url')}
    if t == 'video':
        return {'kind': 'video', 'file': data.get('file'), 'url': data.get('url')}
    if t == 'file':
        return {'kind': 'file', 'name': data.get('name'), 'file': data.get('file')}
    if t == 'reply':
        return {'kind': 'reply', 'id': data.get('id')}
    if t == 'face':
        return {'kind': 'face', 'id': data.get('id')}
    if name == 'Image':
        return {'kind': 'image', 'url': getattr(comp, 'url', None), 'file': getattr(comp, 'file', None)}
    return {'kind': 'text', 'text': str(comp)}


# ══════════════════════════════════════════════════════════════
#  插件加载
# ══════════════════════════════════════════════════════════════

def load_plugin_module(plugin_dir):
    """按「包」的方式加载 main.py，这样插件里的 `from .apis import x` 才能工作。

    踩坑：先 spec 再覆盖 sys.modules 会让相对导入拿到一个空的包对象，
    必须把 module_from_spec 的结果本身注册成包（带 __path__）。
    """
    entry = os.path.join(plugin_dir, 'main.py')
    if not os.path.isfile(entry):
        raise RuntimeError('缺少 main.py')
    mod_name = 'astrbot_plugin_' + re.sub(r'\W', '_', os.path.basename(plugin_dir))
    spec = importlib.util.spec_from_file_location(
        mod_name, entry, submodule_search_locations=[plugin_dir])
    if spec is None or spec.loader is None:
        raise RuntimeError('无法为 main.py 建立加载器')
    mod = importlib.util.module_from_spec(spec)
    mod.__path__ = [plugin_dir]
    mod.__package__ = mod_name
    sys.modules[mod_name] = mod
    spec.loader.exec_module(mod)
    return mod


def find_plugin_class(mod):
    from astrbot.api.star import Star

    candidates = []
    for _, obj in inspect.getmembers(mod, inspect.isclass):
        if obj is Star:
            continue
        if issubclass(obj, Star) and obj.__module__ == mod.__name__:
            candidates.append(obj)
    if not candidates:
        # 有些插件把类写在子模块里，退化成"任何 Star 子类"
        for _, obj in inspect.getmembers(mod, inspect.isclass):
            if obj is not Star and issubclass(obj, Star):
                candidates.append(obj)
    if not candidates:
        raise RuntimeError('在 main.py 里找不到 Star 子类')
    return candidates[0]


def instantiate(cls, context, config):
    """构造函数签名不统一：有的 (context)，有的 (context, config)，有的还带 **kwargs。"""
    attempts = [
        lambda: cls(context, config),
        lambda: cls(context),
        lambda: cls(context=context, config=config),
        lambda: cls(),
    ]
    errors = []
    for attempt in attempts:
        try:
            return attempt()
        except TypeError as exc:
            msg = str(exc)
            # 只有「签名不匹配」才换下一种调用方式；插件内部自己抛的 TypeError
            # 必须原样冒出去 —— 否则真 bug 会被伪装成"构造函数对不上"。
            if 'argument' in msg or 'positional' in msg or '__init__' in msg.lower():
                errors.append(msg)
                continue
            raise
        except Exception:
            raise
    raise RuntimeError('插件实例化失败（构造函数签名都不匹配）：%s' % ' | '.join(errors[:2]))


def patch_instance(instance):
    """给插件实例补上「基类本该提供」的方法。

    AstrBot 的 Star 基类自带 get_kv_data / put_kv_data 等，但市场里有相当一部分
    插件**不继承 Star**（直接普通类，靠 runner 注入 context）。这类插件调
    `self.get_kv_data(...)` 就会 AttributeError（DUT_Notices / shitjournal_daily）。
    在这里按需绑定，比要求插件改代码现实。
    """
    from astrbot.api.star import Star

    for name in ('get_kv_data', 'put_kv_data', 'delete_kv_data', 'remove_kv_data',
                 'html_render', 'terminate', 'initialize'):
        if name in ('terminate', 'initialize'):
            continue  # 生命周期方法不存在时 runner 自己会跳过，不该硬塞
        if getattr(type(instance), name, None) is None and not hasattr(instance, name):
            try:
                setattr(instance, name, types.MethodType(getattr(Star, name), instance))
            except Exception:
                pass
    return instance


def collect_handlers(instance):
    """从实例上收集带 filter 元数据的方法。"""
    handlers = []
    for name, fn in inspect.getmembers(instance, predicate=inspect.ismethod):
        filters = getattr(fn, '__astr_filters__', None)
        if not filters:
            continue
        handlers.append({'method': name, 'fn': fn, 'filters': filters})
    return handlers


def handler_commands(filters):
    cmds = []
    for f in filters:
        if f['kind'] == 'command':
            cmds.append(f['name'])
            cmds.extend(f.get('alias') or [])
        elif f['kind'] == 'command_group':
            cmds.append(f['name'])
    return cmds


def filters_ok(filters, event, body):
    for f in filters:
        kind = f['kind']
        if kind == 'event_message_type':
            val = f.get('value')
            if val in (None, 'all', 'ALL'):
                continue
            if val in ('group', 'GROUP_MESSAGE') and not event.is_group_chat():
                return False
            if val in ('friend', 'private', 'FRIEND_MESSAGE', 'PRIVATE_MESSAGE') and not event.is_private_chat():
                return False
        elif kind == 'permission_type':
            val = f.get('value')
            if val in ('admin', 'ADMIN') and not event.is_admin():
                return False
        elif kind == 'regex':
            try:
                if not re.search(f['pattern'], body, re.I):
                    return False
            except Exception:
                continue
        elif kind == 'unsupported':
            continue
    return True


def match_handler(handlers, body, event):
    """返回 (handler, 命中方式) 或 (None, None)。

    优先级：命令（名字长的先）> 命令组 > 正则。
    命令必须是"整名匹配"或"名字 + 空格 + 参数"，避免 /天气 命中 /天气预报。
    """
    command_items = []
    regex_items = []
    for h in handlers:
        for f in h['filters']:
            if f['kind'] in ('command', 'command_group'):
                names = [f['name']] + list(f.get('alias') or [])
                for idx, nm in enumerate(names):
                    command_items.append((len(nm), h, nm, f['kind']))
            elif f['kind'] == 'regex':
                regex_items.append((h, f['pattern'], f.get('flags') or 0))
    command_items.sort(key=lambda x: -x[0])

    low = body.lower()
    for _, h, nm, kind in command_items:
        nm_low = nm.lower()
        if low == nm_low or low.startswith(nm_low + ' ') or low.startswith(nm_low + '\u3000'):
            if filters_ok(h['filters'], event, body):
                return h, kind, nm
    for h, pattern, flags in regex_items:
        try:
            if re.search(pattern, body, re.I | flags) and filters_ok(h['filters'], event, body):
                return h, 'regex', None
        except Exception:
            continue
    return None, None, None


# ══════════════════════════════════════════════════════════════
#  执行
# ══════════════════════════════════════════════════════════════

async def apply_decorators(decorators, event, chain):
    """跑 on_decorating_result 钩子，返回可能被改写过的消息链。

    插件里写的是 `result = event.get_result()` 然后原地改 `result.chain`，
    所以这里必须先把待发内容塞进 result 再调用它们。
    """
    if not decorators:
        return chain
    from astrbot.api.event import MessageEventResult

    result = None
    try:
        result = event.get_result()
        if result is None:
            result = MessageEventResult(list(chain))
            event.set_result(result)
        else:
            result.chain = list(chain)
    except Exception as exc:
        log('warn', '准备 decorating_result 上下文失败: %s' % exc)
        return chain

    for d in decorators:
        try:
            ret = d['fn'](event)
            if inspect.isasyncgen(ret):
                async for _ in ret:
                    pass
            elif inspect.isawaitable(ret):
                await ret
        except Exception as exc:
            # 过滤钩子挂掉不该连累消息本身 —— 原样发出，比什么都不发好。
            log('warn', 'on_decorating_result(%s) 抛错: %s: %s'
                % (d['method'], type(exc).__name__, exc))
    try:
        return list(result.chain)
    except Exception:
        return chain


async def run_handler(fn, event, bridge, args=None, decorators=None):
    """handler 有三种形态：async 生成器（最常见）、协程、普通函数。

    另外 AstrBot 允许把命令参数绑到函数形参上：

        @filter.command("skin")
        async def skin(self, event: AstrMessageEvent, username: str): ...

    所以这里要按签名补位置参数，否则会 TypeError。
    """
    args = list(args or [])
    call_args = [event]
    call_kwargs = {}
    try:
        params = list(inspect.signature(fn).parameters.values())[1:]  # 去掉 event
    except (TypeError, ValueError):
        params = []
    for idx, p in enumerate(params):
        if p.kind == inspect.Parameter.VAR_POSITIONAL:
            call_args.extend(args[idx:])
            break
        if p.kind == inspect.Parameter.VAR_KEYWORD:
            break
        # GreedyStr 标注：把剩余参数用空格拼回一段（`@cmd 你好 世界` → "你好 世界"）
        ann_name = getattr(p.annotation, '__name__', '') if p.annotation is not inspect.Parameter.empty else ''
        if ann_name == 'GreedyStr':
            call_args.append(' '.join(str(a) for a in args[idx:]))
            break
        if p.kind == inspect.Parameter.KEYWORD_ONLY:
            # `async def f(self, event, *, name: str)` 这类只收关键字参数（碧蓝航线插件）
            if idx < len(args):
                call_kwargs[p.name] = args[idx]
            elif p.default is inspect.Parameter.empty and ann_name != 'GreedyStr':
                call_kwargs[p.name] = ''
            continue
        if idx < len(args):
            call_args.append(args[idx])
        elif p.default is not inspect.Parameter.empty:
            break
        else:
            call_args.append('')

    actions = []
    ret = fn(*call_args, **call_kwargs)
    items = []
    partial_error = ''
    if inspect.isasyncgen(ret):
        try:
            async for item in ret:
                items.append(item)
        except Exception as exc:
            # 生成器半路抛错：已经 yield 出来的内容照常发出去，错误单独带回。
            # 「先给命令结果、再调 LLM 补充」这类插件最常见 —— 若整条丢弃，
            # 用户看到的是命令没反应，而实际上前半段早就算好了。
            partial_error = '%s: %s' % (type(exc).__name__, exc)
            log('warn', 'handler 中途异常（已保留 %d 段输出）: %s' % (len(items), partial_error))
    elif inspect.iscoroutine(ret):
        r = await ret
        if r is not None:
            items.append(r)
    elif ret is not None:
        items.append(ret)

    # 先把 yield 出来的东西统一摊成一条组件链，交给 on_decorating_result 过一遍，
    # 再转成动作。顺序不能反：图片审查/敏感词过滤改的是 result.chain，
    # 转成动作之后就没法再改了。
    from astrbot.api.message_components import Plain as _Plain

    chain = []
    for item in items:
        if item is None:
            continue
        if isinstance(item, str):
            chain.append(_Plain(item))
            continue
        sub = getattr(item, 'chain', None)
        if sub is None:
            chain.append(_Plain(str(item)))
            continue
        chain.extend(sub)

    chain = await apply_decorators(decorators, event, chain)

    for comp in chain:
        actions.append(comp_to_action(comp))

    for comp in bridge.drain():
        actions.append(comp_to_action(comp))

    # 合并相邻纯文本，减少消息条数
    merged = []
    for act in actions:
        if act.get('kind') == 'text' and merged and merged[-1].get('kind') == 'text':
            merged[-1]['text'] = (merged[-1]['text'] + '\n' + act['text']).strip()
        else:
            merged.append(act)
    return [a for a in merged if not (a.get('kind') == 'text' and not a.get('text'))], partial_error


# ══════════════════════════════════════════════════════════════
#  主循环
# ══════════════════════════════════════════════════════════════

async def main_async(args):
    from astrbot.api import AstrBotConfig
    from astrbot.api.event import AstrMessageEvent, _AstrBotMessage, _Sender
    from astrbot.api.message_components import At, Image, Plain
    from astrbot.api.star import Context

    plugin_dir = os.path.abspath(args.dir)
    sys.path.insert(0, plugin_dir)

    meta = parse_metadata_lite(os.path.join(plugin_dir, 'metadata.yaml'))
    if not meta:
        meta = parse_metadata_lite(os.path.join(plugin_dir, 'metadata.yml'))

    # 版本号写法五花八门："v1.2.2" / "1.2.2" / "vv1.0.2"。统一存裸版本号，
    # 展示层自己加 "v"，否则卡片上会出现 "vv1.0.2"。
    if meta.get('version'):
        meta['version'] = re.sub(r'^[vV]\s*', '', meta['version']).strip()

    # 配置：schema 默认值 + 面板传入值
    schema = {}
    schema_path = os.path.join(plugin_dir, '_conf_schema.json')
    if os.path.isfile(schema_path):
        try:
            with open(schema_path, encoding='utf-8') as fh:
                schema = json.load(fh)
        except Exception as exc:
            log('warn', '_conf_schema.json 解析失败: %s' % exc)
    defaults = {}
    for key, spec in (schema or {}).items():
        defaults[key] = _schema_default(spec)
    user_cfg = {}
    if args.config_file and os.path.isfile(args.config_file):
        try:
            with open(args.config_file, encoding='utf-8') as fh:
                user_cfg = json.load(fh) or {}
        except Exception as exc:
            log('warn', '插件配置读取失败: %s' % exc)
    config = AstrBotConfig(_deep_merge(defaults, user_cfg), schema)

    bridge = Bridge()
    # config.save_config() 要把改动送回 Node：把 bridge 挂在实例上（走
    # object.__setattr__，绕开 dict 的属性写入语义）。
    object.__setattr__(config, '_bridge', bridge)
    context = Context(bridge)
    # context.save_config() 不带参数时（mcsmanager 的写法）要知道存哪个配置。
    context._plugin_config = config

    mod = load_plugin_module(plugin_dir)
    cls = find_plugin_class(mod)
    instance = instantiate(cls, context, config)
    patch_instance(instance)
    handlers = collect_handlers(instance)

    commands = []
    unsupported = set()
    decorators = []
    for h in handlers:
        commands.extend(handler_commands(h['filters']))
        is_decorator = False
        for f in h['filters']:
            if f['kind'] == 'unsupported':
                unsupported.add(f.get('what'))
            elif f['kind'] == 'decorating_result':
                is_decorator = True
        if is_decorator:
            decorators.append(h)
    commands = sorted({c for c in commands if c})

    warnings = []
    if not commands:
        warnings.append('该插件没有注册任何命令（可能只提供 LLM 工具或事件钩子，属于 B/C 档）')
    if unsupported:
        warnings.append('以下能力未实现：' + '、'.join(sorted(unsupported)))
    try:
        import astrbot as _pkg
        if getattr(_pkg, '_compat_session_waiter_used', False):
            warnings.append('多轮对话（session_waiter）按单轮处理：首次回复正常，后续追问不会进同一会话')
    except Exception:
        pass

    CH.send({'type': 'ready', 'name': meta.get('display_name') or meta.get('name') or '',
             'version': meta.get('version') or '', 'pkg': meta.get('name') or '',
             'commands': commands, 'unsupported': sorted(unsupported), 'warnings': warnings})

    async def _events():
        """把「读 stdin」和「处理 event」拆成两个协程，再用 async generator 串起来。

        async for 的循环体缩进与原来 while 里的一致，事件仍然是串行处理
        （同一插件的两条消息不会交叉），但读循环一直在跑，所以插件
        await 模型回包的时候，llm_result 能立刻被派发到对应的 future。
        """
        q = asyncio.Queue()
        task = asyncio.create_task(_read_loop(bridge, q))
        try:
            while True:
                item = await q.get()
                if item is None:
                    return
                yield item
        finally:
            task.cancel()

    async for req in _events():
        ev_id = req.get('id')
        text = str(req.get('text') or '')
        body = text.lstrip('/／') if args.strip_prefix else text
        chat = req.get('chat') or {}
        user = req.get('user') or {}

        components = [Plain(text)]
        for comp in (req.get('components') or []):
            if comp.get('type') == 'image' and comp.get('url'):
                components.append(Image(url=comp['url']))
            elif comp.get('type') == 'at' and comp.get('qq'):
                components.append(At(qq=comp['qq']))

        event = AstrMessageEvent(
            text=body.strip(),
            chat=chat, user=user,
            self_id=req.get('selfId') or '',
            message_id=req.get('messageId') or '',
            components=components,
            is_admin=bool(req.get('isAdmin')),
            bridge=bridge,
        )

        handler, how, matched_name = match_handler(handlers, body.strip(), event)
        if handler is None:
            CH.send({'type': 'result', 'id': ev_id, 'matched': False, 'actions': [], 'error': None})
            continue

        arg_text = ''
        if matched_name:
            arg_text = body.strip()[len(matched_name):].strip()
        cmd_args = arg_text.split() if arg_text else []

        try:
            actions, partial_error = await run_handler(handler['fn'], event, bridge, cmd_args, decorators)
            CH.send({'type': 'result', 'id': ev_id, 'matched': True, 'handler': handler['method'],
                     'actions': actions, 'error': partial_error or None})
        except Exception as exc:
            detail = traceback.format_exc(limit=4)
            log('error', 'handler %s 抛错: %s' % (handler['method'], exc))
            CH.send({'type': 'result', 'id': ev_id, 'matched': True, 'handler': handler['method'],
                     'actions': [], 'error': '%s: %s' % (type(exc).__name__, exc), 'trace': detail})

    try:
        term = getattr(instance, 'terminate', None)
        if term:
            await term()
    except Exception:
        pass
    CH.send({'type': 'bye'})


def setup_fs_layout(plugin_dir, data_dir=''):
    """把「AstrBot 真实目录结构」在 cwd 下补齐。

    市场里有相当一批插件按绝对路径假设写死：
        open('data/cmd_config.json')                        # AnimeMagnet
        open('./data/plugins/<插件名>/guacfg.yaml')          # guaguale
        from data.plugins.<插件名>.xxx import y              # fishing ×2 / ebooks / beautiful_giri
    它们在自己的机器上都正常（AstrBot 从安装根目录启动），跑到我们的探针里就
    FileNotFoundError / ModuleNotFoundError —— 这不是插件坏，是**目录没摆对**。

    所以在 cwd 下建 data/plugins/<插件名> 软链指向插件真身，
    再把 data / data.plugins 注册成命名空间包，让 import 和相对路径都能通。
    """
    root = os.getcwd()
    name = os.path.basename(os.path.normpath(plugin_dir))
    link_dir = os.path.join(root, 'data', 'plugins')
    try:
        os.makedirs(link_dir, exist_ok=True)
        link = os.path.join(link_dir, name)
        if not os.path.exists(link):
            os.symlink(os.path.abspath(plugin_dir), link)
    except Exception:
        pass
    # 空的全局配置：有插件启动就读它
    try:
        cfg = os.path.join(root, 'data', 'cmd_config.json')
        if not os.path.isfile(cfg):
            with open(cfg, 'w', encoding='utf-8') as fh:
                fh.write('{}')
    except Exception:
        pass
    if data_dir:
        try:
            os.makedirs(data_dir, exist_ok=True)
        except Exception:
            pass

    # 注册 data / data.plugins 命名空间包（只在本进程内，不落盘）
    try:
        import types as _types

        data_pkg = sys.modules.get('data')
        if data_pkg is None:
            data_pkg = _types.ModuleType('data')
            data_pkg.__path__ = [os.path.join(root, 'data')]
            sys.modules['data'] = data_pkg
        plugins_pkg = sys.modules.get('data.plugins')
        if plugins_pkg is None:
            plugins_pkg = _types.ModuleType('data.plugins')
            plugins_pkg.__path__ = [link_dir]
            sys.modules['data.plugins'] = plugins_pkg
    except Exception:
        pass


def main():
    global CH
    ap = argparse.ArgumentParser()
    ap.add_argument('--dir', required=True)
    ap.add_argument('--data', default='')
    ap.add_argument('--config-file', default='')
    ap.add_argument('--strip-prefix', action='store_true', default=True)
    args = ap.parse_args()

    if args.data:
        os.environ['ASTRBOT_DATA_DIR'] = args.data

    setup_fs_layout(args.dir, args.data)

    # 🔴 关键：把 fd 1 让给协议，插件的 print 一律落到 stderr
    CH = Channel()
    os.dup2(2, 1)
    sys.stdout = sys.stderr

    try:
        asyncio.run(main_async(args))
    except Exception as exc:
        log('error', '启动失败: %s' % exc)
        CH.send({'type': 'fatal', 'error': '%s: %s' % (type(exc).__name__, exc),
                 'trace': traceback.format_exc(limit=6)})
        sys.exit(1)


if __name__ == '__main__':
    main()
