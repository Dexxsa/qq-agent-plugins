"""`astrbot.core.utils.io` —— 下载 / 读写小工具。

插件最常用的是 `download_image_by_url(url, path=...)`：
AstrBot 里它是 `async`，返回**落盘后的路径**（失败返回 None）。
这里用标准库实现（urllib + asyncio.to_thread），不额外依赖 aiohttp。
"""

import asyncio
import base64
import os
import urllib.request

from .astrbot_path import get_astrbot_temp_path

_DEFAULT_TIMEOUT = 30


def ensure_dir(path):
    if path:
        os.makedirs(path, exist_ok=True)
    return path


async def _fetch(url, timeout=_DEFAULT_TIMEOUT):
    def _run():
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read()
    return await asyncio.to_thread(_run)


async def download_image_by_url(url, path=None):
    """把图片下载到 path（不给就落到临时目录），返回文件路径；失败返回 None。"""
    url = str(url or '').strip()
    if not url:
        return None
    try:
        if url.startswith('base64://'):
            data = base64.b64decode(url[len('base64://'):])
        elif url.startswith('file://'):
            with open(url[len('file://'):], 'rb') as fh:
                data = fh.read()
        else:
            if not path:
                path = os.path.join(get_astrbot_temp_path(), 'img_%d.bin' % (abs(hash(url)) % 10 ** 12))
            ensure_dir(os.path.dirname(path))
            # 直接流式落盘，避免大图在内存里多留一份
            def _download():
                req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(req, timeout=_DEFAULT_TIMEOUT) as resp, open(path, 'wb') as out:
                    while True:
                        chunk = resp.read(64 * 1024)
                        if not chunk:
                            break
                        out.write(chunk)
                return path
            return await asyncio.to_thread(_download)

        if not path:
            path = os.path.join(get_astrbot_temp_path(), 'img_%d.bin' % (abs(hash(url)) % 10 ** 12))
        ensure_dir(os.path.dirname(path))
        with open(path, 'wb') as fh:
            fh.write(data)
        return path
    except Exception:
        return None


async def download_file(url, path=None, **_kw):
    """通用下载（图片之外的附件）。"""
    return await download_image_by_url(url, path=path)


def read_file(path, mode='r'):
    with open(path, mode, **({} if 'b' in mode else {'encoding': 'utf-8'})) as fh:
        return fh.read()


def save_file(path, content, mode='w'):
    ensure_dir(os.path.dirname(path))
    with open(path, mode, **({} if 'b' in mode else {'encoding': 'utf-8'})) as fh:
        fh.write(content)
    return path


def remove_dir(path):
    """递归删目录。插件拿它清临时文件（codemage 直接 import 这个名字）。"""
    import shutil

    try:
        shutil.rmtree(path, ignore_errors=True)
        return True
    except Exception:
        return False


async def save_temp_img(data=None, url=None, ext='png', **_kw):
    """把图片字节/URL 落到临时目录，返回路径。

    gemini_image 这类插件生成图片后要「先落地再发」，
    因为消息组件里的图片通常需要一个本地路径或 http URL。
    """
    if data is None and url:
        return await download_image_by_url(url)
    if data is None:
        return None
    path = os.path.join(get_astrbot_temp_path(), 'img_%d.%s' % (
        abs(hash(bytes(data) if isinstance(data, (bytes, bytearray)) else str(data))) % 10 ** 12, ext))
    ensure_dir(os.path.dirname(path))
    try:
        with open(path, 'wb') as fh:
            fh.write(data if isinstance(data, (bytes, bytearray)) else str(data).encode('utf-8'))
        return path
    except Exception:
        return None


__all__ = ['download_image_by_url', 'download_file', 'read_file', 'save_file',
           'ensure_dir', 'remove_dir', 'save_temp_img']
