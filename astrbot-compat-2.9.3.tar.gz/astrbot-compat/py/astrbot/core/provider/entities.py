"""`astrbot.core.provider.entities` —— 只放实体类，转发到 api.provider。

两个路径必须是**同一个类对象**：插件里常见
`from astrbot.core.provider.entities import ProviderRequest` 之后做 isinstance 判断，
如果各自定义一份，判断恒为 False，行为会莫名其妙地不通。
"""

from ...api.provider import LLMResponse, ProviderRequest


class _ProviderTypeMeta(type):
    """`ProviderType.XXX` 取任意名字都返回成员，同时能当字符串比较。"""

    def __getattr__(cls, name):
        if name.startswith('__'):
            raise AttributeError(name)
        return str(name).lower()

    def __call__(cls, name, *a, **k):
        return str(name).lower()


class ProviderType(metaclass=_ProviderTypeMeta):
    """供应商类型（self_learning 初始化时要 import 它）。"""

    CHAT_COMPLETION = 'chat_completion'
    TEXT_TO_SPEECH = 'text_to_speech'
    SPEECH_TO_TEXT = 'speech_to_text'
    EMBEDDING = 'embedding'
    RERANK = 'rerank'


__all__ = ['ProviderRequest', 'LLMResponse', 'ProviderType']
