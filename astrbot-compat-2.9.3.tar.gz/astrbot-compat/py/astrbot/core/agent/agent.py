"""`from astrbot.core.agent.agent import Agent` 这一路径的转发。"""

from . import Agent, AgentState  # noqa: F401

__all__ = ['Agent', 'AgentState']
