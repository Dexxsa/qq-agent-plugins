"""astrbot.core.agent —— 智能体编排层的「形状」垫片。

市场里不少插件只要 `from astrbot.core.agent import ...` 存在就能装起来：
它们把 Agent / 工具类当成类型标注、当成 dataclass 基类，或者只是在 import
时构造一个空壳。真跑对话链路属于 C 档（要桥我们自己那套 llm.js 工具调用），
但**导入不该炸** —— 一个 ImportError 会让整个插件连命令都注册不上。

策略：常见符号给真实可继承的类（FunctionTool 是 dataclass，能被子类覆盖字段），
其余未列出的名字由模块级 __getattr__ 兜一个宽容对象，避免逐个补。
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


class _Permissive:
    """什么都能接、什么都能调的空壳。用于兜住未知的编排层符号。"""

    def __init__(self, *args, **kwargs):
        self._args = args
        self._kwargs = kwargs

    def __getattr__(self, name):
        if name.startswith('__'):
            raise AttributeError(name)
        return _Permissive()

    def __call__(self, *args, **kwargs):
        return _Permissive()

    def __await__(self):
        # 让 `await agent.run()` 之类不至于 TypeError
        if False:
            yield None
        return _Permissive()

    def __iter__(self):
        return iter(())

    def __bool__(self):
        return False

    def __repr__(self):
        return '<agent-stub>'


@dataclass
class AgentContext:
    """上下文占位。插件常直接 ctx.xxx 取字段，这里全是 None 更安全。"""

    context: Any = None
    event: Any = None
    config: Dict[str, Any] = field(default_factory=dict)

    def __getattr__(self, name):
        if name.startswith('__'):
            raise AttributeError(name)
        return None


@dataclass
class ContextWrapper:
    context: Any = None
    event: Any = None

    def __class_getitem__(cls, item):
        # 插件里会写 ContextWrapper[SomeT] 做类型标注（真 AstrBot 是泛型类）
        return cls

    def __getattr__(self, name):
        if name.startswith('__'):
            raise AttributeError(name)
        return _Permissive()


@dataclass
class ToolExecResult:
    result: Any = None
    success: bool = True

    def __class_getitem__(cls, item):
        return cls

    def __str__(self):
        return str(self.result)


@dataclass
class FunctionTool:
    """AstrBot 的工具描述体。允许被 @dataclass 子类覆盖字段。"""

    name: str = ''
    description: str = ''
    parameters: Dict[str, Any] = field(default_factory=dict)
    handler: Any = None
    active: bool = True

    def __class_getitem__(cls, item):
        # AstrBot 4.x 里 FunctionTool 是泛型（FunctionTool[TS]），
        # 插件会写 `list[FunctionTool[MessageEvent]]` 做类型标注
        return cls

    async def call(self, *args, **kwargs):
        if callable(self.handler):
            ret = self.handler(*args, **kwargs)
            if hasattr(ret, '__await__'):
                return await ret
            return ret
        return ToolExecResult(success=False, result='compat: 工具执行未桥接')


class ToolSet:
    def __init__(self, tools: Optional[List[Any]] = None):
        self.tools: List[Any] = list(tools or [])

    def add(self, tool):
        self.tools.append(tool)
        return tool

    def remove(self, name):
        self.tools = [t for t in self.tools if getattr(t, 'name', None) != name]

    def get(self, name):
        for t in self.tools:
            if getattr(t, 'name', None) == name:
                return t
        return None

    def __iter__(self):
        return iter(self.tools)

    def __len__(self):
        return len(self.tools)


class Agent:
    """真跑要接我们自己的 LLM 通道，这里只保证能被实例化/继承。"""

    def __init__(self, *args, **kwargs):
        self.args = args
        self.kwargs = kwargs

    async def run(self, *args, **kwargs):
        raise NotImplementedError('兼容层未桥接 Agent 执行链路（属于 C 档能力）')


class AgentState:
    IDLE = 'idle'
    RUNNING = 'running'
    DONE = 'done'


class EventBus:
    def __init__(self, *args, **kwargs):
        self._handlers: Dict[str, List[Any]] = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)
        return handler

    on = subscribe

    async def emit(self, name, *args, **kwargs):
        out = []
        for h in self._handlers.get(name, []):
            ret = h(*args, **kwargs)
            if hasattr(ret, '__await__'):
                ret = await ret
            out.append(ret)
        return out


_ALIASES = {
    'AgentContextWrapper': ContextWrapper,
    'Tool': FunctionTool,
    'Tools': ToolSet,
}


def __getattr__(name):
    if name in _ALIASES:
        return _ALIASES[name]
    # 未知符号一律给宽容对象：import 不炸，用到真能力时才会明确报「未桥接」
    return type(name, (_Permissive,), {})


__all__ = [
    'Agent', 'AgentContext', 'AgentState', 'ContextWrapper', 'EventBus',
    'FunctionTool', 'ToolExecResult', 'ToolSet',
]


# 真 AstrBot 这几个类都是泛型的，插件会写 `ContextWrapper[X]`、`AgentContext[T]`
# 之类做类型标注。占位类不是泛型，直接下标会抛
# "TypeError: type 'X' is not subscriptable"，而且这错发生在**模块导入期**
# （类体/函数签名的标注即使有 from __future__ import annotations 也可能被求值），
# 一旦抛整个插件就加载失败。统一补上，返回类本身即可。
def _class_getitem(cls, item):
    return cls


for _cls in (AgentContext, ContextWrapper, ToolExecResult, FunctionTool,
             ToolSet, Agent, AgentState, EventBus):
    if '__class_getitem__' not in _cls.__dict__:
        _cls.__class_getitem__ = classmethod(_class_getitem)

