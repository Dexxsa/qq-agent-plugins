"""`astrbot.core.agent.message` 兜底：只保证导入可用。"""

import sys

from . import __getattr__ as _pkg_getattr  # noqa: F401


def __getattr__(name):
    return _pkg_getattr(name)


if __name__ == '__main__':
    sys.exit(0)
