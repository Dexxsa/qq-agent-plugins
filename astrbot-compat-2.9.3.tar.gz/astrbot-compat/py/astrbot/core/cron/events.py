"""定时任务触发的事件对象。继承 AstrMessageEvent，所以 isinstance 两边都成立。"""

from astrbot.api.event import AstrMessageEvent

_ALLOWED = ('text', 'chat', 'user', 'self_id', 'message_id', 'components', 'is_admin', 'bridge')


class CronMessageEvent(AstrMessageEvent):
    def __init__(self, *args, **kwargs):
        # 真 AstrBot 的签名是 CronMessageEvent(cron_job, ...)，第一个位置参数就是任务体
        self.cron_job = kwargs.pop('cron_job', args[0] if args else None)
        passthrough = {k: v for k, v in kwargs.items() if k in _ALLOWED}
        super().__init__(**passthrough)

    def is_cron(self):
        return True

    def __repr__(self):
        return '<CronMessageEvent %s>' % getattr(self.cron_job, 'name', '')


__all__ = ['CronMessageEvent']
