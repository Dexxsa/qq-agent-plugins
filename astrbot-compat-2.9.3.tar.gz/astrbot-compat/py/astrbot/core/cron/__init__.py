"""astrbot.core.cron —— 定时任务相关形状。

「通用生图」这类插件会在 result_handler 里判断 `isinstance(event, CronMessageEvent)`，
用来区分「用户发消息触发的」和「定时任务触发的」。真定时调度属于 C 档，
但类型必须在，否则 ImportError 直接让整个插件装不上。
"""

from .events import CronMessageEvent  # noqa: F401


class CronJob:
    """定时任务描述体，字段对齐 AstrBot：name / cron_expression / handler。"""

    def __init__(self, name='', cron_expression='', handler=None, enabled=True, **extra):
        self.name = name
        self.cron_expression = cron_expression
        self.handler = handler
        self.enabled = enabled
        for key, value in extra.items():
            setattr(self, key, value)

    def __repr__(self):
        return '<CronJob %s %s>' % (self.name, self.cron_expression)


class CronJobManager:
    """空实现：不真跑调度，只保证属性和方法可调用。"""

    def __init__(self):
        self.jobs = []

    def add(self, job):
        self.jobs.append(job)
        return job

    def list(self):
        return list(self.jobs)

    def remove(self, name):
        self.jobs = [j for j in self.jobs if getattr(j, 'name', None) != name]

    def __getattr__(self, name):
        if name.startswith('__'):
            raise AttributeError(name)
        return lambda *a, **k: None


cron_manager = CronJobManager()

__all__ = ['CronMessageEvent', 'CronJob', 'CronJobManager', 'cron_manager']
