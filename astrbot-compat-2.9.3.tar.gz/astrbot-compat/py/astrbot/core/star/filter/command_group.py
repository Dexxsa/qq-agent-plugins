"""`astrbot.core.star.filter.command_group` —— 命令组过滤器。

真 AstrBot 里 `@filter.command_group("漫画")` 会往 handlers 注册一个
`CommandGroupFilter(group_name=...)`，插件常在启动时遍历注册表、按
`isinstance(f, CommandGroupFilter)` 改命令别名（copymanga 就是这么做的）。

兼容层没有真正的注册表（handler 是我们自己扫类属性拿到的），
所以这里只提供**类型形状**：`group_name` 有值、`isinstance` 能成立，
插件那段「改别名」的循环自然空转，不影响命令本身可用。
"""

from ....api.event import filter


class CommandGroupFilter:
    def __init__(self, group_name='', description=None, func_list=None, **kwargs):
        self.group_name = str(group_name)
        self.description = description
        # 插件会读组里的子命令列表（改别名时遍历），给空列表避免 AttributeError
        self.func_list = list(func_list or [])
        for k, v in kwargs.items():
            setattr(self, k, v)

    def __repr__(self):
        return '<CommandGroupFilter %r>' % self.group_name


# 真正的实现在 api.event.filter；这里保留同名符号，供少数插件连带导入
command_group = filter.command_group

__all__ = ['CommandGroupFilter', 'command_group']
