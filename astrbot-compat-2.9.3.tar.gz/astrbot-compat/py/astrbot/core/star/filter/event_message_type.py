from ....api.event import EventMessageType, filter

event_message_type = filter.event_message_type


class EventMessageTypeFilter:
    """4.x 里这是个过滤器对象，插件拿它做 isinstance 判断或子类化。

    我们没有真正的过滤器链，给个能实例化、能比较的空壳即可
    （help_typst 直接 `from ... import EventMessageTypeFilter` 就崩在导入期）。
    """

    def __init__(self, *args, **kwargs):
        self.args = args
        self.kwargs = kwargs

    def __eq__(self, other):
        return isinstance(other, EventMessageTypeFilter)

    def __hash__(self):
        return id(self)


__all__ = ['event_message_type', 'EventMessageType', 'EventMessageTypeFilter']
