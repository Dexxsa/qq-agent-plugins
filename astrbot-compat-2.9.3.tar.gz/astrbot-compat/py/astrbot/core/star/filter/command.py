from ....api.event import filter


class CommandFilter:
    """命令过滤器。

    真 AstrBot 里每个 `@filter.command("x")` 都会注册一个 CommandFilter 实例，
    插件启动时会遍历注册表，按 `isinstance(f, CommandFilter)` 找到所有命令，
    再读 `f.func_list` 改别名/权限（codemage、trpgdice 就这么干）。

    之前这里是 `type(filter)`，实例上取 `.func_list` 只会拿到 __getattr__ 兜的
    函数，报 `'function' object has no attribute 'func_list'`。改成真类：
    字段齐全、func_list 是空列表，插件的遍历安全空转。
    """

    def __init__(self, command_name='', alias=None, description=None, **kwargs):
        self.command_name = str(command_name)
        self.alias = list(alias or [])
        self.description = description
        self.func_list = []
        self.event_filters = []
        self.enabled = True
        for k, v in kwargs.items():
            setattr(self, k, v)

    def __repr__(self):
        return '<CommandFilter %r>' % self.command_name


class GreedyStr(str):
    """「吃掉剩余全部参数」的类型标注。

    插件这么写，是希望 `@cmd 你好 世界` 里的 `你好 世界` 整体进一个参数，
    而不是按空格切成两个。runner 看到这个标注会把剩余参数用空格拼回来，
    所以这里只要是个 str 子类即可（继承 str 让插件内部的字符串操作照常可用）。
    """


command = filter.command

__all__ = ['command', 'CommandFilter', 'GreedyStr']
