"""`astrbot.core.star.filter.permission` —— 兼容旧导入路径。

部分插件写的是单数形式的模块名（permission），另一批写 permission_type。
两个路径都指向同一份实现，避免「同一个装饰器两种行为」。
"""

from ....api.event import PermissionType, filter

permission_type = filter.permission_type


class PermissionTypeFilter:
    """4.x 的权限过滤器对象。插件 import 它做 isinstance 判断或子类化，
    缺了会在导入期直接 ImportError（help 类插件好几个都这么写）。"""

    def __init__(self, *args, **kwargs):
        self.args = args
        self.kwargs = kwargs
        self.permission_type = args[0] if args else None

    def __eq__(self, other):
        return isinstance(other, PermissionTypeFilter)

    def __hash__(self):
        return id(self)


__all__ = ['permission_type', 'PermissionType', 'PermissionTypeFilter']
