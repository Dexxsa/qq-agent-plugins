"""新版插件从 astrbot.core.star.filter 取装饰器。

一律转发到 astrbot.api.event.filter —— 只有一份实现，
避免"两个命名空间行为不一致"这种最难查的 bug。
"""

from ....api.event import (EventMessageType, PermissionType, filter)

command = filter.command
command_group = filter.command_group
event_message_type = filter.event_message_type
permission_type = filter.permission_type
regex = filter.regex
llm_tool = filter.llm_tool
on_llm_request = filter.on_llm_request


class RegexFilter:
    """正则过滤器对象。插件 import 它做类型判断 / 子类化（help_typst 导入它就崩）。"""

    def __init__(self, pattern='', *args, **kwargs):
        self.pattern = pattern
        self.args = args
        self.kwargs = kwargs
        self.func_list = []

    def __repr__(self):
        return '<RegexFilter %r>' % self.pattern


__all__ = ['filter', 'command', 'command_group', 'event_message_type',
           'permission_type', 'regex', 'llm_tool', 'on_llm_request',
           'EventMessageType', 'PermissionType', 'RegexFilter']
