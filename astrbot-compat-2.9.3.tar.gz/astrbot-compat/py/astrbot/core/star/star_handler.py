"""`astrbot.core.star.star_handler` —— 处理器注册表。

插件用它做「遍历所有 handler、按条件改点什么」这类全局操作
（copymanga 用它动态改命令别名）。

兼容层里 handler 是启动时从插件类属性上扫出来的，没有长期存活的注册表，
所以这里给一个**空的可迭代对象**：插件的循环会安全地空转，
命令本身照常响应。等到真的需要「运行时改 handler」时再补成真表。
"""


class StarHandlerMetadata:
    """单个 handler 的元信息（形状对齐 AstrBot）。"""

    def __init__(self, handler_module_path='', handler_name='', event_filters=None, handler=None):
        self.handler_module_path = handler_module_path
        self.handler_name = handler_name
        self.event_filters = list(event_filters or [])
        self.handler = handler

    def __repr__(self):
        return '<StarHandlerMetadata %s>' % self.handler_name


class _HandlerRegistry(list):
    """空注册表。list 子类：既能 `for x in registry`，也能 `.append()`。"""

    def register(self, meta):
        self.append(meta)
        return meta

    @property
    def _handlers(self):
        """真 AstrBot 内部用 `registry._handlers`（dict）存 handler。

        有插件直接摸这个私有字段做去重/清理（trpgdice 就这么写的），
        给它自己这个 list：`.clear()` / `len()` / `for` 都成立，
        真去按 key 取会拿到 IndexError，但那是少数派。
        """
        return self


star_handlers_registry = _HandlerRegistry()

__all__ = ['StarHandlerMetadata', 'star_handlers_registry']
