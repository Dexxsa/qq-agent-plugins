"""新版本插件从 astrbot.core.star.star import Star 或 star_map。

`star_map` 是真 AstrBot 里的"已加载插件"全局注册表（Dict[str, StarMetadata]）。
插件常用它判断"某个插件在不在"或遍历所有插件。

这里用 defaultdict：真 AstrBot 里表有内容，插件 `star_map[key]` 是合法写法；
给空 dict 会 KeyError（just_enough_mc 就卡在这）。取不存在的 key 返回一个
宽容的占位元信息对象，`.name` / `.version` 之类能取到值，逻辑不会炸。
"""

from collections import defaultdict

from ...api.star import Star


class _StarMetadata:
    """占位元信息。取任意属性都返回空字符串/空列表，保证插件判断不出错。"""

    def __init__(self, star_id=''):
        self.star_id = star_id
        self.name = star_id
        self.author = ''
        self.desc = ''
        self.version = ''
        self.repo = ''
        self.module_path = ''
        self.activated = True
        self.star_cls_type = None
        self.star_handler_full_names = []

    def __getattr__(self, name):
        if name.startswith('__'):
            raise AttributeError(name)
        return ''

    def __repr__(self):
        return '<StarMetadata %s>' % self.star_id


star_map: dict = defaultdict(_StarMetadata)

__all__ = ['Star', 'star_map', '_StarMetadata']
