"""老版本插件从这里 import MessageChain / MessageEventResult / ResultContentType。"""

from ...api.event import MessageChain, MessageEventResult


class _EnumMember(str):
    @property
    def value(self):
        return str(self)

    @property
    def name(self):
        return str(self)


class _ResultContentTypeMeta(type):
    def __getattr__(cls, name):
        if name.startswith('__'):
            raise AttributeError(name)
        return _EnumMember(name.lower())

    def __call__(cls, name, *a, **k):
        return _EnumMember(str(name).lower())


class ResultContentType(metaclass=_ResultContentTypeMeta):
    """结果内容类型（genie-tts 等插件用它标记「这是一段 TTS 结果」）。"""

    LLM_RESULT = _EnumMember('llm_result')
    GENERAL_RESULT = _EnumMember('general_result')
    STREAMING_RESULT = _EnumMember('streaming_result')
    TOOL_CALL_RESULT = _EnumMember('tool_call_result')


__all__ = ['MessageChain', 'MessageEventResult', 'ResultContentType']
