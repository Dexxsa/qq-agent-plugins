"""astrbot.api.star —— Star 基类、Context、注册器、StarTools。"""

import inspect
import os


class _AwaitableStr(str):
    """既能当普通字符串用、又能被 await 的字符串。

    真 AstrBot 的 `get_current_chat_provider_id()` 是 async 方法，有的插件
    会 `await` 它（如日常记账），有的直接当同步值用（如塔罗）。这个类型
    两种姿势都兼容，避免按某一侧写死。
    """

    def __await__(self):
        async def _coro():
            return str(self)
        return _coro().__await__()


class Star:
    """所有插件的基类。构造函数签名在不同版本插件里不一致，见 runner 的容错。"""

    def __init__(self, context=None, config=None):
        self.context = context
        if config is not None:
            self.config = config
        # 真 AstrBot 的 Star 自带这些元数据属性，插件常直接读 self.name / self.version
        # （essentials 就在 __init__ 里用 self.name 建数据目录，缺了就 AttributeError）
        for attr in ('name', 'author', 'desc', 'version', 'repo', 'star_id'):
            if not hasattr(type(self), attr):
                try:
                    setattr(self, attr, '')
                except Exception:
                    pass

    async def terminate(self):
        return None

    async def initialize(self):
        return None

    # ---- KV 存储 ----------------------------------------------------------
    # 真 AstrBot 的 Star 自带一对 KV 接口，插件拿它存用户配置、状态、缓存：
    #     await self.put_kv_data('key', value)
    #     v = await self.get_kv_data('key', default)
    # 缺了就是 `AttributeError: 'XxxPlugin' object has no attribute 'get_kv_data'`
    # （DUT_Notices 就是这么挂的）。这里用进程内字典兜住，语义一致、不落盘。
    _kv_store = None

    def _kv(self):
        if self._kv_store is None:
            object.__setattr__(self, '_kv_store', {})
        return self._kv_store

    async def get_kv_data(self, key, default_value=None, *a, **k):
        return self._kv().get(key, default_value)

    async def put_kv_data(self, key, value, *a, **k):
        self._kv()[key] = value
        return None

    async def delete_kv_data(self, key, *a, **k):
        self._kv().pop(key, None)
        return None

    async def remove_kv_data(self, key, *a, **k):
        return await self.delete_kv_data(key)

    async def html_render(self, tmpl=None, data=None, **kw):
        """AstrBot 用它把 HTML 模板渲染成图片（内部依赖 playwright + chromium）。
        服务器上没有浏览器运行环境，明确抛错，让插件走它自己的降级分支；
        静默返回空图会让插件以为成功了，问题更难查。
        """
        raise NotImplementedError('兼容层不支持 HTML 渲染（缺 playwright/chromium）')


class Context:
    """插件与内核交互的入口。

    只实现了 A 档需要的那部分：发消息、取平台名。
    其余（LLM、会话、知识库、Web 面板）一律显式抛错，
    这样插件作者一眼能看出「是兼容层不支持」，而不是数据莫名不对。
    """

    def __init__(self, bridge=None):
        self._bridge = bridge
        self._registered = []
        self._llm_tools = []
        # 有些插件直接摸内部字段拿全局配置（adsb_monitor 就写 self.context._config）。
        # 给个空的类 dict 对象：取不存在的键会 KeyError 但不会 AttributeError，
        # 而且 `.get()` 能安全返回 None。
        self._config = {}
        self.platform_manager = _EmptyPlatformManager()
        self.provider_manager = _ProviderManager(self)
        self.conversation_manager = _ConversationManager()
        self.persona_manager = _PersonaManager()
        self.kb_manager = _KBManager()

    async def send_message(self, umo, message_chain):
        """主动发消息。message_chain 是组件列表或单个组件。"""
        chain = message_chain if isinstance(message_chain, (list, tuple)) else [message_chain]
        if self._bridge is not None:
            self._bridge.enqueue(chain)
        return True

    def get_platform(self, *a, **k):
        raise NotImplementedError('兼容层未提供平台对象（event.bot / platform 属于 C 档）')

    def get_all_platforms(self, *a, **k):
        raise NotImplementedError('兼容层未提供平台对象')

    # ── LLM ──────────────────────────────────────────────────
    # 2.9.0 起真的接上了内核的模型通道。之前这几个方法一律抛错 / 返回 None，
    # 「插件自调 LLM」那一类（AI 解读、塔罗、记账分析、基金分析…）装上就挂。

    def _provider(self):
        """懒创建一个能真正调模型的 provider。

        bridge 为 None 时返回 None（沿用旧行为）：比如插件在纯单测里被
        直接实例化，没有宿主进程可通信，插件自己会走「模型不可用」分支。
        """
        if self._bridge is None:
            return None
        inst = getattr(self, '_provider_inst', None)
        if inst is None:
            from ..provider import Provider
            inst = Provider(self._bridge)
            self._provider_inst = inst
        return inst

    async def llm_generate(self, prompt=None, contexts=None, system_prompt=None,
                           chat_provider_id=None, **kwargs):
        provider = self._provider()
        if provider is None:
            raise RuntimeError('当前上下文没有可用的模型通道（bridge 未接入）')
        return await provider.text_chat(prompt=prompt, contexts=contexts,
                                        system_prompt=system_prompt, **kwargs)

    def get_provider(self, *a, **k):
        return self._provider()

    def get_provider_by_id(self, provider_id=None, *a, **k):
        """按 id 取 provider。

        我们只有一个（内核的），所以任何 id 都返回它 —— 比返回 None
        让插件在 `provider.text_chat` 上 AttributeError 好排查。
        """
        return self._provider()

    def get_all_providers(self, *a, **k):
        """返回全部已加载的 LLM provider。内核只有一条通道，就是那一个。"""
        inst = self._provider()
        return [inst] if inst is not None else []

    def get_current_chat_provider_id(self, umo=None, *a, **k):
        """当前会话用的 chat provider id。直接报内核那个默认 id。

        返回 _AwaitableStr：插件 `await` 它（真 AstrBot 是 async）或直接
        拿来当字符串拼比较，都能工作。
        """
        inst = self._provider()
        return _AwaitableStr(inst.meta().id if inst is not None else 'compat-default')


    def get_using_provider(self, *a, **k):
        return self._provider()

    def get_config(self, umo=None, *a, **k):
        """取插件配置（部分插件用 context.get_config() 读全局配置）。

        兼容层没有 AstrBot 的全局配置库，给一个空 AstrBotConfig：
        插件读到的每一项都是 None/缺省，会走自己的默认分支，
        而不是在 `__init__` 里 AttributeError 直接装不上。
        """
        from .. import AstrBotConfig

        cfg = getattr(self, '_global_config', None)
        if cfg is None:
            cfg = AstrBotConfig({})
            self._global_config = cfg
        return cfg

    def save_config(self, config=None, *a, **k):
        """持久化插件配置（mcsmanager 等用它保存运行时改动）。

        两种调用姿势都要支持：
        - `context.save_config(self.config)` —— 显式传配置对象；
        - `context.save_config()` —— 不传，真 AstrBot 会自己找到「当前插件」
          的配置；runner 引导时把配置挂在 `_plugin_config` 上，这里兜底。
        """
        if config is None:
            config = getattr(self, '_plugin_config', None)
        if config is not None and hasattr(config, 'save_config'):
            return config.save_config()
        return True

    def register_web_api(self, route=None, handler=None, methods=None, desc=None):
        """挂 Web API。兼容层没有 AstrBot 的那套前端容器，所以**记录但不提供**。

        为什么不像 LLM 那样直接抛错：这个调用几乎都在插件 `__init__` 里，
        一抛整个插件就装不上，而插件的**命令功能其实完全可用**
        （Web 面板只是改配置用的另一个入口）。记下来供面板提示即可。
        """
        self._web_apis = getattr(self, '_web_apis', [])
        self._web_apis.append({
            'route': str(route or ''),
            'methods': list(methods or ['GET']),
            'desc': str(desc or ''),
        })
        return True

    def register_task(self, *a, **k):
        raise NotImplementedError('兼容层未提供定时任务（属于 B 档能力）')

    def register_llm_tool(self, *a, **k):
        # 不抛错：很多插件在 __init__ 里登记工具，一抛整个插件就装不上。
        # 工具本身不会交给模型（未桥接 LLM），但插件自己的命令仍然可用。
        self._llm_tools.extend(a)
        return True

    def add_llm_tools(self, *tools):
        self._llm_tools.extend(tools)
        return True

    def add_llm_tool(self, tool):
        self._llm_tools.append(tool)
        return True


class _Unsupported:
    """占位对象：一被使用就抛错，并说明所属档位。"""

    def __init__(self, name):
        self._name = name

    def __getattr__(self, item):
        raise NotImplementedError('兼容层未提供 %s.%s' % (self._name, item))


class _Awaitable:
    """让任意返回值既能同步用又能被 await（真 AstrBot 的 manager 方法多为 async）。"""

    def __await__(self):
        async def _c():
            return self
        return _c().__await__()


class _Conversation(_Awaitable):
    """伪会话对象：字段对齐 AstrBot 的 Conversation（id + 空 history）。"""

    def __init__(self, conv_id, umo=''):
        self.conversation_id = conv_id
        self.umo = umo
        self.user_id = ''
        self.persona_id = ''
        self.title = ''
        self.created_at = ''
        self.updated_at = ''
        self.history = []

    def __getattr__(self, name):
        # 字段探测兜底：不同版本 AstrBot 的 Conversation 字段有出入，
        # 缺字段返回 None 让插件走默认分支，比 AttributeError 好排查。
        if name.startswith('_'):
            raise AttributeError(name)
        return None

    def __repr__(self):
        return '<Conversation compat id=%s turns=0>' % self.conversation_id


class _ConversationList(list, _Awaitable):
    """get_conversations 的返回：list 用法与 await 用法都兼容。"""


class _AwaitableTuple(tuple, _Awaitable):
    """tuple 版：resolve_selected_persona 返回 (id, dict)，两种取法都兼容。"""


class _EmptyKB(_Awaitable):
    """空知识库对象：读恒为空、写恒成功（数据不落任何地方）。

    比 get_kb_by_id 返回 None 好：插件拿到 None 常直接崩，
    拿到空库会走「没搜到」分支，功能退化但活着。
    """

    def __init__(self, kb_id='', name=''):
        self.id = kb_id
        self.name = name
        self.info = {}
        self.embedding_provider = None

    def __getattr__(self, item):
        # 字段探测兜底（与 _Conversation 同理）：不同版本 KB 对象字段有出入
        if item.startswith('_'):
            raise AttributeError(item)
        return None

    def search(self, query=None, **k):
        return _ConversationList([])

    async def search_async(self, query=None, **k):
        return []

    def insert(self, *a, **k):
        return True

    def delete(self, *a, **k):
        return True

    def update(self, *a, **k):
        return True

    def __repr__(self):
        return '<KB compat empty>'


class _KBManager:
    """kb_manager 的最小实现：内核没有向量库，恒空。"""

    def get_kbs(self, *a, **k):
        return _ConversationList([])

    def get_kb_by_id(self, kb_id=None, *a, **k):
        return _EmptyKB(kb_id or 'compat-kb-empty')

    def get_kb_by_name(self, name=None, *a, **k):
        return _EmptyKB('', name or '')

    def create_kb(self, name=None, *a, **k):
        return _EmptyKB('', name or '')

    def delete_kb(self, *a, **k):
        return True

    def update_kb(self, *a, **k):
        return True


class _PersonaManager:
    """persona_manager 的最小实现。

    内核的人设由自己的 persona-rules / 提示词体系管理，兼容层拿不到那份
    数据。这里返回「无人设」：resolve_selected_persona 给空人设（prompt
    为空串），插件把它拼进提示词时等于没拼，功能退化为无人设模式。
    """

    def resolve_selected_persona(self, umo=None, *a, **k):
        # 按新版 AstrBot 返回 4 元组 (persona_id, persona, dialog_hist, use_webchat_default)。
        # 极少数旧插件按 2 元组解包会报 too many values —— 市场现役插件以新版为主。
        return _AwaitableTuple(('', {'name': '', 'prompt': '',
                                     'begin_dialogs': [], 'persona_id': ''},
                                [], False))

    def get_personas(self, *a, **k):
        return []

    def get_persona_by_id(self, persona_id=None, *a, **k):
        return None

    def update_persona(self, *a, **k):
        return True


class _ConversationManager:
    """conversation_manager 的最小实现。

    内核没有 AstrBot 那套按会话持久化的对话历史库（东方知识库等插件用
    get_curr_conversation_id 取「当前会话 id」当缓存键）。这里给每个会话
    一个稳定的伪 id，历史恒为空：只用 id 分桶的插件照常工作，真想读写
    历史的那部分功能退化为空，而不是 AttributeError。
    """

    def __init__(self):
        self._curr = {}
        self._seq = 0

    def get_curr_conversation_id(self, umo=None, *a, **k):
        key = str(umo or 'default')
        if key not in self._curr:
            safe = ''.join(c if c.isalnum() else '-' for c in key)[:60]
            self._curr[key] = 'compat-conv-' + (safe or 'default')
        return _AwaitableStr(self._curr[key])

    def get_conversation(self, umo=None, conversation_id=None, *a, **k):
        cid = conversation_id or self.get_curr_conversation_id(umo)
        return _Conversation(str(cid), str(umo or ''))

    def get_conversations(self, umo=None, *a, **k):
        return _ConversationList([self.get_conversation(umo)])

    def get_conversation_by_id(self, conversation_id=None, *a, **k):
        return _Conversation(conversation_id or 'compat-conv-default', '')

    def new_conversation(self, umo=None, *a, **k):
        key = str(umo or 'default')
        self._seq += 1
        safe = ''.join(c if c.isalnum() else '-' for c in key)[:60]
        self._curr[key] = 'compat-conv-%s-%d' % (safe or 'default', self._seq)
        return self.get_conversation(umo)

    def update_conversation(self, conversation=None, *a, **k):
        return conversation

    def append_conversation_history(self, *a, **k):
        return True


class _ProviderManager:
    """provider_manager 的最小可用实现。

    插件除了 `context.get_using_provider()`，还有一批走
    `context.provider_manager.get_using_provider()` / `.get_provider_by_id()` /
    `.providers`。内核只有一条模型通道，所以这些入口统统指向同一个 provider。
    """

    def __init__(self, ctx):
        self._ctx = ctx

    def get_using_provider(self, *a, **k):
        return self._ctx._provider()

    def get_provider_by_id(self, provider_id=None, *a, **k):
        return self._ctx._provider()

    def get_provider(self, *a, **k):
        return self._ctx._provider()

    def get_all_providers(self, *a, **k):
        return self._ctx.get_all_providers(*a, **k)

    def get_current_chat_provider_id(self, umo=None, *a, **k):
        return self._ctx.get_current_chat_provider_id(umo=umo, *a, **k)

    @property
    def providers(self):
        inst = self._ctx._provider()
        return [inst] if inst is not None else []

    def __bool__(self):
        # 有些插件写 `if not self.context.provider_manager: 跳过`
        return True



class _EmptyPlatformManager:
    """空的平台管理器。

    事件型插件（入群欢迎、消息监听）习惯用
    ``context.platform_manager.get_insts()`` 遍历已接入的平台去取 bot client。
    这里返回空列表，让它们走「当前没有可用平台」的正常分支 ——
    总比每次遍历都抛 AttributeError、在日志里刷一屏异常要好。
    """

    def get_insts(self, *a, **k):
        return []

    def get_inst(self, *a, **k):
        return None

    def __iter__(self):
        return iter(())

    def __len__(self):
        return 0


def register(*_args, **_kwargs):
    """@register(...) 注册装饰器。兼容层里是空操作 —— 类靠子类关系自动发现。"""

    def deco(cls):
        return cls

    if _args and inspect.isclass(_args[0]):
        return _args[0]
    return deco


class StarTools:
    """插件常用的工具方法。"""

    @staticmethod
    def initialize(*_a, **_k):
        """真 AstrBot 用它初始化全局数据目录。插件会显式 `StarTools.initialize()`，
        找不到就是 AttributeError（spider 插件这么挂的）。空实现即可。"""
        return None

    @staticmethod
    def get_data_dir(plugin_name=''):
        """返回 **pathlib.Path** —— 真 AstrBot 就是 Path，
        插件普遍写成 get_data_dir("x") / "file.json"，返回 str 会直接 TypeError。
        """
        from pathlib import Path

        root = Path(os.environ.get('ASTRBOT_DATA_DIR', os.getcwd()))
        path = root / plugin_name if plugin_name else root
        try:
            path.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        return path

    @staticmethod
    def get_config_path(*a, **k):
        from pathlib import Path

        return Path(os.environ.get('ASTRBOT_DATA_DIR', os.getcwd()))

    @staticmethod
    def get_astrbot_version():
        return '4.0.0'

    @staticmethod
    async def create_target(*a, **k):
        raise NotImplementedError('兼容层未提供 create_target')


__all__ = ['Star', 'Context', 'register', 'StarTools']
