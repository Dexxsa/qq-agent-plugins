"""astrbot.api.provider —— LLM 提供方。

2.9.0 起**真的能调模型了**：provider 把 AstrBot 的调用形状
（prompt + contexts + system_prompt + image_urls）翻成 messages，
经 stdin/stdout 协议交给内核，由内核用它自己的模型配置去请求
（主备通道、冷却、用量统计都跟着内核走，插件侧不存第二份密钥）。

之前这里是 `raise NotImplementedError('兼容层未桥接 LLM 提供方')`，
于是「插件自调 LLM」那一类（AI 解读、塔罗、记账分析……）一装上就挂。
"""


class ProviderType:
    CHAT_COMPLETION = 'chat_completion'
    TEXT_TO_SPEECH = 'text_to_speech'
    SPEECH_TO_TEXT = 'speech_to_text'
    EMBEDDING = 'embedding'


class ProviderMeta:
    """provider 的元信息。`provider.meta().id` / `.type` / `.model` 都有插件在读。"""

    def __init__(self, id='compat-default', type=ProviderType.CHAT_COMPLETION, model='default'):
        self.id = id
        self.type = type
        self.model = model

    def __repr__(self):
        return '<ProviderMeta id=%r type=%r model=%r>' % (self.id, self.type, self.model)


class LLMResponse:
    """一次补全的结果。

    AstrBot 的插件读法有两种，这里都给：
      · `resp.completion_text`            —— 纯文本
      · `resp.result_chain` → MessageChain —— 少数插件拿它去 yield
    """

    def __init__(self, role='assistant', completion_text='', result_chain=None, usage=None):
        self.role = role
        self.completion_text = completion_text
        self._result_chain = result_chain
        self.usage = usage

    @property
    def result_chain(self):
        if self._result_chain is not None:
            return self._result_chain
        # 延迟导入：api.event 会反向引用 provider 里的类型，放模块顶层会成环
        from ..event import MessageChain
        from ..message_components import Plain
        self._result_chain = MessageChain([Plain(self.completion_text or '')])
        return self._result_chain

    def __repr__(self):
        return '<LLMResponse %r>' % (str(self.completion_text)[:40],)


class Provider:
    """能真正发起补全请求的 provider。

    只实现 chat：embedding / TTS / STT 明确抛错（内核没有这些能力，
    假装有会让插件拿到空向量去做检索，错得更隐蔽）。
    """

    provider_type = ProviderType.CHAT_COMPLETION

    def __init__(self, bridge=None, provider_id='compat-default', model_name='', **kw):
        self._bridge = bridge
        self.provider_id = provider_id or 'compat-default'
        self.model_name = model_name or ''
        self.provider_config = kw.pop('provider_config', {}) or {}
        self.provider_settings = kw.pop('provider_settings', {}) or {}
        self._meta = None

    # ── 元信息 ────────────────────────────────────────────────

    def meta(self):
        if self._meta is None:
            self._meta = ProviderMeta(id=self.provider_id, model=self.get_model())
        return self._meta

    def get_model(self):
        return self.model_name or 'default'

    def provider_type_of(self):
        return ProviderType.CHAT_COMPLETION

    @property
    def config(self):
        return dict(self.provider_config)

    def __repr__(self):
        return '<Provider %s model=%s>' % (self.provider_id, self.get_model())

    # ── 请求 ──────────────────────────────────────────────────

    @staticmethod
    def _text_of(item):
        """把 context 元素里的文本抠出来（dict / AstrBot Message / 字符串都认）。"""
        if isinstance(item, str):
            return item
        if isinstance(item, dict):
            content = item.get('content')
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                out = []
                for part in content:
                    if isinstance(part, dict) and part.get('type') == 'text':
                        out.append(str(part.get('text') or ''))
                return ''.join(out)
            return ''
        # AstrBot 的 Message：正文在 .message 里（组件列表），也可能直接有 .content
        content = getattr(item, 'content', None)
        if isinstance(content, str) and content:
            return content
        parts = getattr(item, 'message', None)
        if isinstance(parts, (list, tuple)):
            buf = []
            for part in parts:
                text = getattr(part, 'text', None)
                if text:
                    buf.append(str(text))
            return ''.join(buf)
        return str(content or '')

    @classmethod
    def _role_of(cls, item, default='user'):
        if isinstance(item, dict):
            return str(item.get('role') or default)
        role = getattr(item, 'role', None)
        if role:
            return str(role)
        return default

    def _build_messages(self, prompt, contexts, system_prompt, image_urls):
        messages = []
        if system_prompt:
            messages.append({'role': 'system', 'content': str(system_prompt)})
        for item in (contexts or []):
            text = self._text_of(item)
            if not text:
                continue
            messages.append({'role': self._role_of(item), 'content': text})
        user_text = '' if prompt is None else str(prompt)
        # 图片不做多模态数组：内核的模型接口未必接 image_url 结构，
        # 传过去会整条请求 400，连文字都拿不到。降级成占位描述，至少不失败。
        if image_urls:
            marks = '\n'.join('[图片: %s]' % str(u) for u in image_urls)
            user_text = (user_text + '\n' + marks).strip() if user_text else marks
        if user_text:
            messages.append({'role': 'user', 'content': user_text})
        if not messages:
            messages.append({'role': 'user', 'content': ''})
        return messages

    async def text_chat(self, prompt=None, session_id=None, contexts=None,
                        image_urls=None, system_prompt=None, **kwargs):
        messages = self._build_messages(prompt, contexts, system_prompt, image_urls)
        text = await self._bridge.call_llm(
            messages,
            temperature=kwargs.get('temperature'),
            max_tokens=kwargs.get('max_tokens'),
        )
        return LLMResponse(role='assistant', completion_text=text)

    async def text_chat_stream(self, prompt=None, session_id=None, contexts=None,
                               image_urls=None, system_prompt=None, **kwargs):
        """内核没有流式通道：拿到全文后一次性 yield。

        插件那边是 `async for resp in provider.text_chat_stream(...)`，
        只 yield 一次也能正常走完（只是没有逐字效果）。
        """
        resp = await self.text_chat(prompt=prompt, session_id=session_id, contexts=contexts,
                                    image_urls=image_urls, system_prompt=system_prompt, **kwargs)
        yield resp

    # ── 明确没有的能力 ────────────────────────────────────────

    async def get_embedding(self, text, *a, **k):
        raise NotImplementedError('兼容层未桥接 embedding（内核没有向量模型）')

    async def get_embeddings(self, texts, *a, **k):
        raise NotImplementedError('兼容层未桥接 embedding（内核没有向量模型）')

    async def text_to_speech(self, *a, **k):
        raise NotImplementedError('兼容层未桥接 TTS')

    async def speech_to_text(self, *a, **k):
        raise NotImplementedError('兼容层未桥接 STT')


class ProviderRequest:
    """一次 LLM 请求的载荷。

    字段名对齐 AstrBot 4.x：prompt / contexts / system_prompt / image_urls / func_tool。
    刻意给全默认值 —— 插件里有大量 `req.system_prompt += '...'` 这类原地拼接，
    字段缺失会抛 AttributeError，比「功能不完整」更难排查。
    """

    def __init__(self, prompt='', contexts=None, system_prompt='', image_urls=None,
                 func_tool=None, session_id='', conversation=None, **extra):
        self.prompt = prompt
        self.contexts = list(contexts or [])
        self.system_prompt = system_prompt
        self.image_urls = list(image_urls or [])
        self.func_tool = func_tool
        self.session_id = session_id
        self.conversation = conversation
        for key, value in extra.items():
            setattr(self, key, value)

    def __repr__(self):
        return '<ProviderRequest prompt=%r contexts=%d images=%d>' % (
            str(self.prompt)[:40], len(self.contexts), len(self.image_urls))


__all__ = ['Provider', 'ProviderType', 'ProviderMeta', 'LLMResponse', 'ProviderRequest']
