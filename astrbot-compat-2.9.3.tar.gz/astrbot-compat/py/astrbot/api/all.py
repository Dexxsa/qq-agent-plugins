"""astrbot.api.all —— 插件里 `from astrbot.api.all import *` 的入口。"""

from . import AstrBotConfig, logger
from .event import (AstrMessageEvent, EventMessageType, MessageChain,
                    MessageEventResult, PermissionType, filter)
from .message_components import (At, Component, Face, File, Forward, Image, Json,
                                 Node, Nodes, Plain, Record, Reply, Video)
from .star import Context, Star, StarTools, register

# 真 AstrBot 的 astrbot.api.all 会把 filter 里的装饰器平铺导出。
# 插件普遍写成 `from astrbot.api.all import *` 之后直接 `@command("x")`，
# 少这几个就会在 import 阶段 NameError。
command = filter.command
command_group = filter.command_group
event_message_type = filter.event_message_type
permission_type = filter.permission_type
regex = filter.regex
llm_tool = filter.llm_tool
on_llm_request = filter.on_llm_request
on_astrbot_loaded = filter.on_astrbot_loaded


class CommandResult:
    """`from astrbot.api.all import CommandResult` 的插件用的类型。

    真 AstrBot 里它承载「命令执行结果」（是否成功、放行/拦截、附带消息）。
    我们不做拦截链路，给个能实例化、能取属性的壳：插件的 `isinstance` 判断
    和字段读取都不会炸，实际发送仍由 yield 出来的消息链决定。
    """

    def __init__(self, result=None, message=None, **kwargs):
        self.result = result
        self.message = message
        for k, v in kwargs.items():
            setattr(self, k, v)

    def __bool__(self):
        return bool(self.result) if self.result is not None else True

    def __repr__(self):
        return '<CommandResult %s>' % (self.result,)


__all__ = [
    'AstrBotConfig', 'logger',
    'Star', 'Context', 'register', 'StarTools',
    'filter', 'AstrMessageEvent', 'EventMessageType', 'PermissionType',
    'MessageEventResult', 'MessageChain', 'CommandResult',
    'command', 'command_group', 'event_message_type', 'permission_type',
    'regex', 'llm_tool', 'on_llm_request', 'on_astrbot_loaded',
    'Component', 'Plain', 'Image', 'At', 'Reply', 'Node', 'Nodes', 'Face',
    'Record', 'Video', 'File', 'Forward', 'Json',
]
