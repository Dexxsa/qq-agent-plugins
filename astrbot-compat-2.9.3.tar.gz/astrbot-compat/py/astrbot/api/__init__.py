"""astrbot.api —— 兼容层的公共入口。"""

import logging
import sys


class _Logger:
    """把插件的日志转发到 stderr，由 Node 侧收进插件日志。

    不走 logging 的 handler 配置：插件里的 logger 调用量很大，
    交给 logging 会带上默认格式和多余前缀，反而不好读。
    """

    def __init__(self):
        self.level = logging.INFO
        self._extra = {}
        # 标准库 Logger 有 filters（list），插件会 append / 遍历（self_learning 就读它）
        self.filters = []

    def _emit(self, level, msg, *args, **kwargs):
        text = str(msg)
        if args:
            try:
                text = text % args
            except Exception:
                text = text + ' ' + ' '.join(str(a) for a in args)
        try:
            sys.stderr.write('[py:%s] %s\n' % (level, text))
            sys.stderr.flush()
        except Exception:
            pass

    def debug(self, msg, *a, **k):
        self._emit('debug', msg, *a)

    def info(self, msg, *a, **k):
        self._emit('info', msg, *a)

    def warning(self, msg, *a, **k):
        self._emit('warn', msg, *a)

    warn = warning

    def log(self, level, msg, *a, **k):
        """标准 Logger 的 log(level, msg) 写法（nitter_tweets 用到）。"""
        name = getattr(level, 'name', None) or str(level).lower()
        self._emit(name if name in ('debug', 'info', 'warn', 'error') else 'info', msg, *a)

    def error(self, msg, *a, **k):
        self._emit('error', msg, *a)

    def exception(self, msg, *a, **k):
        self._emit('error', msg, *a)

    def critical(self, msg, *a, **k):
        self._emit('error', msg, *a)

    def setLevel(self, *_a, **_k):
        return None

    def addHandler(self, *_a, **_k):
        return None

    def addFilter(self, *_a, **_k):
        """标准 logging 接口。self_learning 会往 logger 上挂过滤器。"""
        return None

    def removeFilter(self, *_a, **_k):
        return None

    def getChild(self, name=None, *_a, **_k):
        """`logging.getLogger(__name__).getChild('x')` —— 标准库 Logger 有，
        不少插件用它给子模块起分层名字（self_learning 就卡在这）。
        返回同一个实例即可：插件只是想拿个能 log 的对象。"""
        return self


logger = _Logger()


class AstrBotConfig(dict):
    """插件配置。行为对齐 AstrBot：字典 + 属性访问 + save_config()。

    值来自两处合并：插件目录的 _conf_schema.json 里的 default，
    加上用户在控制台面板里改过的值（后者覆盖前者）。
    """

    def __init__(self, data=None, schema=None):
        super().__init__(data or {})
        object.__setattr__(self, '_schema', schema or {})

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(name)
        try:
            if name in self:
                return self[name]
        except Exception:
            pass
        raise AttributeError(name)

    def __missing__(self, key):
        """`config['APP']` 取不到时返回 None 而不是 KeyError。

        真 AstrBot 的配置表里一定有插件声明的键，我们只合并了 schema 的 default，
        有些插件会硬取一个 schema 里没写的键（kahunabot 取 'APP'），
        KeyError 会让整个插件加载失败——给 None 让它继续跑，缺的值由它自己兜。
        """
        return None

    def __setattr__(self, name, value):
        if name.startswith('_'):
            object.__setattr__(self, name, value)
        else:
            self[name] = value

    def save_config(self):
        """把插件运行时改过的配置送回宿主落盘。

        runner 启动时会把这个 config 实例挂上 `_bridge`；没有 bridge
        （插件被单独 import 做测试）时就退回旧行为：内存态，恒成功。
        """
        bridge = None
        try:
            bridge = object.__getattribute__(self, '_bridge')
        except AttributeError:
            pass
        if bridge is None:
            return True
        return bridge.save_config(dict(self))

    @property
    def schema(self):
        return object.__getattribute__(self, '_schema')


__all__ = ['logger', 'AstrBotConfig', 'FunctionTool']


# ── 顶层再导出几个装饰器 ────────────────────────────────────
# 有些插件写成 `from astrbot.api import llm_tool` 直接用装饰器，
# 不经过 astrbot.api.event.filter。这里补上，免得 ImportError。
from . import event as _event_mod  # noqa: E402

llm_tool = _event_mod.filter.llm_tool
on_llm_request = _event_mod.filter.on_llm_request
on_astrbot_loaded = _event_mod.filter.on_astrbot_loaded


# ── LLM 工具描述对象 ───────────────────────────────────────
# 插件普遍这样写：
#     @dataclass
#     class MyTool(FunctionTool):
#         name: str = "xxx"
#         description: str = "..."
#         parameters: dict = field(default_factory=...)
#         active: bool = True
# 然后 `context.add_llm_tools(MyTool())`。
# 兼容层没有把工具真正交给模型（那需要接管 LLM 调用链，属 B 档），
# 但这个**数据类必须存在且可被子类化**，否则整个插件在 import 阶段就死，
# 连它自己的命令都一起没了。字段顺序与 AstrBot 保持一致。
from dataclasses import dataclass as _dataclass, field as _field  # noqa: E402


@_dataclass
class FunctionTool:
    name: str = ''
    description: str = ''
    parameters: dict = _field(default_factory=dict)
    handler: object = None
    active: bool = True


__all__ += ['llm_tool', 'on_llm_request', 'on_astrbot_loaded', 'FunctionTool']
