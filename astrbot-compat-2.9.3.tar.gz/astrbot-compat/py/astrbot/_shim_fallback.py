"""astrbot.* 缺失子模块的通用兜底加载器。

为什么需要：
    市场上不少插件是「全家桶」写法，一个插件里 import 十几个 AstrBot 内部模块
    （`astrbot.core.db.po`、`astrbot.core.astr_main_agent`、
    `astrbot.core.platform.message_session`…）。逐个手写 stub 是填不完的坑，
    而且每来一个新插件就要再补一轮。

做法：
    在 sys.meta_path 末尾挂一个 Finder。真实垫片文件仍然由 PathFinder 先命中，
    只有「磁盘上确实没有」的 astrbot.* 子模块才由我们凭空造一个宽容模块。
    这样 `from astrbot.core.db.po import Conversation` 这类导入能过，
    插件至少能装起来、把命令注册上。

边界（刻意保留的告警）：
    大写名 → 当成类/常量，给出可实例化、可继承、属性可取的占位类型；
    小写名 → 当成函数，调用时抛 NotImplementedError，并指明是哪个模块缺能力。
    宁可让它在真正用到某个能力时明确报错，也不要静默返回 None 造成「偶发失灵」。
"""

import sys
import types
from importlib.abc import Loader, MetaPathFinder
from importlib.machinery import ModuleSpec

_PREFIX = 'astrbot'
_cache = {}


class _MissingCapability(NotImplementedError):
    pass


class _StubMeta(type):
    """让占位类本身也能被取属性（Stub.FOO / Stub.bar()）和下标（Stub[X]）。"""

    def __getitem__(cls, item):
        # 真 AstrBot 里这些类型多半是泛型（Generic[T]），插件会写 Cls[X]
        return cls

    def __getattr__(cls, name):
        if name.startswith('__'):
            raise AttributeError(name)
        return cls._mk(name)

    def _mk(cls, name):
        return _make_class('%s.%s' % (cls.__name__, name))

    # 占位类当容器用时要"空而安全"。
    # 典型炸法：`", ".join(THIRD_PARTY_AGENT_RUNNER_KEY.keys())` —— 我们兜底模块里
    # 那个常量是占位类，`.keys()` 又返回一个占位类，join 直接
    # `TypeError: sequence item 3: expected str instance, _StubMeta found`
    # （AstrBot 官方内置指令插件就这么崩在 import 期）。
    # 让它可迭代且长度 0，join/for/len 全部安全空转。
    def __iter__(cls):
        return iter(())

    def __len__(cls):
        return 0

    def __bool__(cls):
        return False


def _make_class(fullname):
    short = fullname.rsplit('.', 1)[-1]

    def _init(self, *args, **kwargs):
        self._args = args
        self._kwargs = kwargs

    def _getattr(self, name):
        if name.startswith('__'):
            raise AttributeError(name)
        return _make_class('%s.%s' % (fullname, name))

    def _call(self, *args, **kwargs):
        return None

    return _StubMeta(short, (_StubBase,), {
        '__init__': _init,
        '__getattr__': _getattr,
        '__call__': _call,
        '__repr__': lambda self: '<stub %s>' % fullname,
        '_shim_fullname': fullname,
    })


class _StubBase:
    def __init__(self, *args, **kwargs):
        self._args = args
        self._kwargs = kwargs

    def __class_getitem__(cls, item):
        return cls

    def __getattr__(self, name):
        if name.startswith('__'):
            raise AttributeError(name)
        return _make_class('%s.%s' % (type(self).__name__, name))

    def __call__(self, *args, **kwargs):
        return None

    # 与 _StubMeta 同理：占位对象被 join/for/len 时应该是"空"，不能抛
    def __iter__(self):
        return iter(())

    def __len__(self):
        return 0

    def __bool__(self):
        return False

    def __await__(self):
        if False:
            yield None
        return None

    def __repr__(self):
        return '<stub %s>' % type(self).__name__


def _make_func(module_name, attr):
    def _missing(*args, **kwargs):
        raise _MissingCapability(
            '兼容层未提供 %s.%s()（该能力需要真 AstrBot 运行时）' % (module_name, attr))
    _missing.__name__ = attr
    return _missing


def _resolve(module_name, attr):
    key = (module_name, attr)
    if key in _cache:
        return _cache[key]
    if attr.startswith('_'):
        raise AttributeError(attr)
    obj = _make_class('%s.%s' % (module_name, attr)) if attr[:1].isupper() \
        else _make_func(module_name, attr)
    _cache[key] = obj
    return obj


class _StubModule(types.ModuleType):
    def __getattr__(self, attr):
        if attr.startswith('__'):
            raise AttributeError(attr)
        obj = _resolve(self.__name__, attr)
        setattr(self, attr, obj)
        return obj


class _StubLoader(Loader):
    def create_module(self, spec):
        mod = _StubModule(spec.name)
        mod.__path__ = []
        mod.__shim_virtual__ = True
        return mod

    def exec_module(self, module):
        pass


class _FallbackFinder(MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if not (fullname == _PREFIX or fullname.startswith(_PREFIX + '.')):
            return None
        for finder in sys.meta_path:
            if finder is self:
                continue
            try:
                spec = finder.find_spec(fullname, path, target)
            except Exception:
                spec = None
            if spec is not None:
                return None  # 有真实实现，交给它
        return ModuleSpec(fullname, _StubLoader(), is_package=True)


def install():
    """幂等安装；重复调用不会重复挂 Finder。"""
    if any(isinstance(f, _FallbackFinder) for f in sys.meta_path):
        return True
    sys.meta_path.append(_FallbackFinder())
    return True
