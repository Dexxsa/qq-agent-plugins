# 记忆与约定（companion）

通用版长期记忆层。移植自 dsh-companion-kit 0.2.0，把「每轮注入一块材料 + 把该记的写回文件」这套做法接到 qq-agent v3.0 的插件内核上。

**不绑定任何人设**：提示词里只有中性描述（"你有长期记忆"），不写角色名、不规定语气。谁装上都能用。

版本 `0.2.0-qq.6` · 插件 API v1 · 无第三方依赖

---

## 它解决什么

普通聊天机器人记不住跨天的事：昨天说的事今天忘了，答应过的提醒转头就丢，聊久了还会把设定忘掉。

这个插件把记忆做成**纯文本文件**，把约定做成**真的定时任务**，把翻旧账做成**关键词检索**——全部本地、可读、可改。

## 能力

| 能力 | 默认 | 说明 |
| --- | --- | --- |
| 主卡 `mainCard` | 开 | 你自己写的长期设定（人设/规则）。文件空着就不注入，不占额度 |
| 时间线 `timeline` | 开 | 按天追加「发生过的事」，跨天累积 |
| 备忘 `memo` | 开 | 琐碎但不想忘的小事、偏好，新的在最上面 |
| 日记 `diary` | 开 | 一天一条，重复写入以最新为准 |
| 约定 `loops` | 开 | 答应的事记一条；给 `at` 会**同步排进内核定时任务**，到点真的叫 |
| 检索 `recall` | 开 | 在归档里按关键词翻旧事，带 16 组同义词扩展 |
| 关系阶段 `relation` | **关** | 1 陌生→2 熟悉→3 暧昧→4 对象，有门槛。伴侣向角色再开 |
| 心情精力 `state` | **关** | 心情/精力/温度 6–9，影响语气。伴侣向角色再开 |
| 作息表 `day` | **关** | 工作日/周末两套作息，给出"现在在干嘛"。有作息设定的角色再开 |

**关掉的能力连工具都不注册**，不占提示词额度：默认 4 个工具，全开 6 个。

## 三个默认关着的功能，在哪开

面板上默认只有前六项打勾。后三项是**给特定人设留的**，默认关着；关着的时候连工具都不注册，不占额度。

**开法（三步，1 分钟）**

1. 控制台 → **插件** 页 → 找到「记忆与约定」卡片 → 点 **配置**（面板直接展开在卡片里）
2. 往下第二组 **「角色状态（需要对应人设才开）」** → 勾上要用的（也可以点这一组右上角的 **「全开」**）→ **保存**
3. 回到插件页，点这张卡片上的 **「重载」**

**第 3 步不能省。只保存不重载 = 看着开了、实际没注入**：注入内容和工具注册都是插件**装载时**按配置算的快照，保存只写配置、不重新装载。实测（对比 `/api/plugins` 前后）：

| 操作 | `loadedAt` | 注册的工具 |
| --- | --- | --- |
| 保存 `state: true` | 不变 | 仍是 4 个，`companion_state` 不存在 |
| 再点「重载」 | 变了 | 5 个，`companion_state` 出现 |

重载约 1 秒、不掉线、不用重启整机。`systemctl restart qq-agent` 效果一样，但要断线几十秒，没必要。

**不用面板的话**，两行 curl 等价：

```bash
curl -s -X POST http://127.0.0.1:3210/api/plugins/config -H 'content-type: application/json' \
  -d '{"id":"companion","patch":{"features":{"relation":true,"state":true}}}'
curl -s -X POST http://127.0.0.1:3210/api/plugins/reload -H 'content-type: application/json' -d '{"id":"companion"}'
```

**直接改 `data/config.json` 的话，必须先停服务再改**：进程内存里有一份配置副本，运行时会整份覆盖回去，改了等于没改。

**开完分别多什么**

| 开关 | 多出来的工具 | 多出来的注入 |
| --- | --- | --- |
| `relation` | `companion_relation` | 当前阶段 + 怎么称呼 + 语气 + 这阶段能做什么 / 红线 |
| `state` | `companion_state` | 心情、精力 6–9 + 温度 + 这会儿在干嘛 |
| `day` | 无（纯注入） | 现在周几几点、你这会儿在做什么、能不能聊 |

> 只想要「记得住」，这三项都不用开。**不确定人设是不是这个方向就别开**——注入的是具体行为模板（撒娇 / 害羞 / 报状态 / 按作息说话），和冷酷型、公文型角色正面冲突。

## 安装

前置条件：宿主是 **BG-QQagent v3.0**（插件内核 API v1）。不需要装 node 依赖，也不需要 python，包内 `vendor/` 已经自带原库。

### 方式一：控制台导入（推荐，唯一推荐）

1. 打开控制台 → **插件页**
2. 点 **「导入插件包」** → 选 `companion-0.2.0-qq.6.tar.gz`
3. 列表里出现「记忆与约定」，状态 `已启用` —— **装完即用，不用改配置、不用重启**

这个包就是用内核自己的导出接口（`GET /api/plugins/export?mode=clean`）生成的，所以和插件中心的导入格式完全一致：包内 `config.json` 会整体写入 `plugins.companion`，默认值直接生效；装载是热加载，下一轮对话就带记忆块。

**升级旧版**：勾上「导入插件包」按钮右边的 **「覆盖安装」**，再选同一个包导入一次。覆盖只替换源码目录，`data/plugins/companion/` 里的记忆数据不会被删。

> 这个勾是后补的：v3.0 原版后端支持 `mode:"replace"`，但前端没暴露，遇到已存在插件只会弹「请勾选覆盖安装」而界面上没有该勾——等于升级死路。补丁在 `_patch/patch-import-ui.mjs`。

### 方式二：命令行调同一个接口

服务器上没有浏览器时，直接打 HTTP 接口，效果和点按钮一样：

```bash
cd /path/to/qq-agent
B64=$(base64 -w0 companion-0.2.0-qq.6.tar.gz)
curl -s -X POST http://127.0.0.1:3210/api/plugins/import \
  -H 'content-type: application/json' \
  -d "{\"base64\":\"$B64\",\"mode\":\"replace\"}"
```

返回 `{"ok":true,"status":"enabled",...}` 就是装好了。`mode` 可选 `replace`（覆盖）或省略（已存在时才报错）。

### 方式三：手动解压（不经过接口）

```bash
tar -xzf companion-0.2.0-qq.6.tar.gz -C plugins/
systemctl restart qq-agent
```

这条路**不会写 `plugins.companion` 配置段**，靠 `manifest.defaultEnabled: true` 和插件内部的默认值兜底，所以也能跑；但配置里不会有默认值，面板首次保存后才会补全。能用接口就别用这条。

## 配置

两条路，效果一样：

**① 控制台面板**：插件页 → 记忆与约定 → 点开，九项开关 + 归档开关 + 注入预算，勾完点保存，**再点一次卡片上的「重载」**。

**② 改 `data/config.json`**：`plugins.companion` 里覆盖，未写的用 manifest 默认值（深合并，只写想改的）：

```json
{
  "archive": true,
  "shareOwnerMemory": false,
  "features": { "relation": true, "state": true, "day": false },
  "caps": { "timeline": 2400, "total": 7000 }
}
```

- `archive`：每轮把新消息写进归档，供 `companion_recall` 用。关掉只省磁盘，检索会变空。
- `shareOwnerMemory`：`true` 时群聊读**主人私聊**的卡片（原包的"群里共享主人资料"）。默认 `false`，每个会话各记各的。
- `caps.total`：一轮注入的总字数上限。超了按优先级丢块：作息 → 日记 → 备忘 → 时间线，主卡和约定留到最后。

> 开关改完必须让插件重新装载才生效：面板保存后点「重载」，或整机重启。**改文件则必须先 `systemctl stop qq-agent` 再改再启动**，否则进程内存里的副本会把你的修改覆盖回去。

## 跟「轻量记忆」插件的关系（会自动处理）

**你不需要手动关任何东西。** 装上本插件后，如果检测到「轻量记忆」（`memory` 插件，提供 `memory_append` 那 4 个工具）也在跑，默认会自动把它停用，并留一个标记文件。

两者在技术上互不读写，冲突纯粹发生在**工具层**：两组写入工具并存时，模型要在它们之间反复权衡，结果是同一条内容写两遍，或者该记的一次都没记。这个靠配置解决不了，只能二选一。

| | companion | 轻量记忆（`memory` 插件） |
| --- | --- | --- |
| 存哪 | `data/plugins/companion/`，纯文本 md | `data/memory/<会话>.json` |
| 维度 | 主卡 / 时间线 / 备忘 / 日记 / 约定 / 归档 | 进行中的话题 / 想说没说的话 / 对某人的印象 |
| 整理 | 不压缩，靠 `caps` 裁剪注入量 | 有阈值触发，用 LLM 重写压缩 |
| 注入段 | `<chat_memory>` 包裹 | 内核 `prompt.js` 的【记忆】段 |

### 三种政策（`conflictPolicy`）

| 值 | 行为 |
| --- | --- |
| `autoDisable`（默认） | 检测到就停用 `memory` 插件，写 `data/plugins/companion/memory-conflict.json` 留痕。只做一次 |
| `coexist` | 都不动，在提示词里写清分工：它记「刚刚发生的事 / 没说出口的话 / 即时印象」，你记「跨天的事实 / 答应过的事」 |
| `ignore` | 什么都不做 |

面板上有下拉，`data/config.json` 里也能改。

### 为什么"停用插件"还不够，还要改提示词

「轻量记忆」不是纯插件：**工具在插件里，注入逻辑和规则文案在内核 `prompt.js`**。插件停用后工具消失、规则被 `hasTool` 守卫掐掉，但内核那一段【记忆】是直接读 `MemoryStore` 的，**数据还在就还会注入**。

所以自动停用之后，提示词里会多一句：

> 这个系统里原有的另一套记忆已经停用。如果上下文里还出现旧的【记忆】段，那是已经冻结的历史快照：可以拿来参考，但不要再往里写，也不要当作最新状态——最新段为准。

如果你手动把轻量记忆开回来，插件**不会跟你抢**（标记文件存在就不再动手），只把声明换成「记忆只有一个入口，就是 companion_*」。

### 验证过的行为

在隔离环境同时装两个插件跑的（`conflict-test.mjs`，9/9 通过）：

| 场景 | 结果 |
| --- | --- |
| 默认 `autoDisable` | 轻量记忆变为 `disabled`，标记文件生成，注入冻结声明 |
| 停用后你手动开回来 | 保持 `enabled`，不再重复停用，声明改成独占 |
| `coexist` | 两边都 `enabled`，注入分工说明 |
| `ignore` | 两边都 `enabled`，不注入任何冲突说明 |


## 数据

```
data/plugins/companion/state/companion-memory/
  wechat-direct-10001.md            主卡
  wechat-direct-10001.2.md          时间线
  wechat-direct-10001.5.md          备忘
  wechat-direct-10001.diary.md      日记
  wechat-direct-10001.loops.json    约定
  wechat-direct-10001.state.json    状态（开 state 才有）
  wechat-direct-10001.relation.json 关系（开 relation 才有）
  archive/wechat-direct-10001.jsonl 归档（检索用）
```

群聊是 `wechat-group-<群号>`，与私聊分开。全部是纯文本，直接编辑也生效（下一轮读取）。

## 工具

| 工具 | 作用 |
| --- | --- |
| `companion_note` | 记一条：`kind` = timeline / memo / diary / main |
| `companion_loop` | 约定：`add`（带 `at` 会排定时）/ `list` / `done` / `cancel` |
| `companion_recall` | 翻旧事：`query` 关键词 |
| `companion_state` | 心情/精力/在干嘛（开 `state` 才有） |
| `companion_relation` | 查看/推进关系阶段（开 `relation` 才有） |
| `companion_status` | 自查各卡条数、未了约定数 |

只读端点：`GET /api/plugins/companion/cards?chatKey=private:10001`（面板的"查看卡片"就是调它）

## 跟原包的结构差异

1. **会话 key 适配**：原包只认 `<平台>:direct|group:<id>`（判定正则是 `/:group(?::|$)/`），本内核用 `private:123` / `group:456`。插件内部统一转成 `qq:direct:` / `qq:group:`，否则群聊判定全失效、所有会话会挤进同一个文件。
2. **写回方式改成工具**：原包靠回复末尾的 `[MEMO:]` `[LOOP_ADD:]` `[MOOD:]` 标记。本内核没有"发送前改写"钩子（只有 message/poke/notice/tick/prefilter），标记会原样发给对方。所以改成模型调工具写回——更可靠，也不会漏标记。
3. **不重复注入最近聊天**：原包会把最近 12 轮流水一起注入，但内核的 `prompt.js` 已经在注入【最近聊天】。这里只补内核没有的东西。

## 已知限制

- 关系阶段靠"证据 + 对方表态"判定，没有出站钩子，所以只有模型主动调 `companion_relation action=up` 才会推进；不调就永远停在第 1 级。这是刻意的（关系不该自动涨）。
- 归档只在本插件收到新消息后才写；装插件之前的历史聊天不会被补录。
- 卡片不会自动压缩，只靠 `caps` 裁剪注入量。长期只增不减时，文件会变大而注入量恒定。
- `companion_loop` 的定时走内核 `scheduled-tasks.js`，删掉插件不会删掉已排的任务（它们仍会触发）。

## 卸载

```bash
systemctl stop qq-agent
rm -rf /root/DSH/qq-agent/plugins/companion
systemctl start qq-agent
```

数据留在 `data/plugins/companion/`，想彻底清干净再删这个目录。
