// ── 插件：记忆与约定（companion）─────────────────────────────────────
//
// 移植自 dsh-companion-kit 0.2.0（作者：lyy）。原包是给 DSH 的「长期陪伴型角色」
// 上下文层：每轮把一块材料插到提示词前面，再把回复里的标记写回文件。
//
// 本插件做的是**通用移植**，不绑定任何人设：
//   · 默认只开「记忆 + 约定 + 检索」——这三块对任何机器人都成立
//   · 关系阶段 / 心情精力 / 作息表 是伴侣向能力，做成了**开关**，需要的人自己打开
//   · 提示词里的说明全部是中性描述（"你有长期记忆"），不写任何角色名与口吻
//
// 与原包的三处结构性差异：
//   ① key 适配：kit 只认 `<平台>:direct|group:<id>`（isGroupKey 是 /:group(?::|$)/），
//      本内核是 `private:123` / `group:456`，插件内部统一转成 `qq:direct:` / `qq:group:`。
//   ② 写回方式：原包靠回复里的 [MEMO:]/[LOOP_ADD:]/[MOOD:] 标记，但本内核**没有出站
//      改写钩子**（只有 message/poke/notice/tick/prefilter），标记会原样发到聊天里。
//      所以改成工具写回：companion_note / companion_loop / companion_state / companion_relation。
//   ③ 注入范围：原包连「最近 12 轮流水」一起注入，本内核的 prompt.js 已经在注入
//      【最近聊天】，重复注入等于把同一段历史喂两遍。这里只补内核没有的：
//      卡片、约定、关系、状态、作息。
//
// 数据目录（全部纯文本，可读可改）：
//   data/plugins/companion/state/companion-memory/wechat-qq-<direct|group>-<id>.*
//     .md        主卡（人设/长期设定，可选）
//     .2.md      时间线（按天）
//     .5.md      备忘
//     .diary.md  日记（一天一条）
//     .loops.json      未了约定
//     .state.json      心情 / 精力 / 正在做什么（可选）
//     .relation.json   关系阶段（可选）
//   data/plugins/companion/state/companion-memory/archive/*.jsonl   归档，供检索
import fs from 'node:fs';
import path from 'node:path';

import { ok, err } from '../../src/core/tool-kit.js';
import * as ST from '../../src/scheduled-tasks.js';
import { chatMemoryBase, readChatLoops, saveChatLoops, memoryKeyFor } from './vendor/memory.mjs';
import { appendChatArchive, searchChatArchive } from './vendor/archive.mjs';
import { relationContext, readRelation, applyRelationMarkers } from './vendor/relation.mjs';
import { stateContext, readState, applyStateMarkers } from './vendor/state.mjs';
import { dayContext } from './vendor/day.mjs';

// ── 默认配置（全部可被 data/config.json 的 plugins.companion 覆盖）──
const DEFAULTS = {
  archive: true,          // 每轮把新消息写进 archive，供 companion_recall 检索
  shareOwnerMemory: false, // true = 群聊读主人的私聊卡片（原包的"群里共享主人资料"）
  // 和「轻量记忆」插件撞车时怎么办：
  //   autoDisable = 自动停用它（默认，装完不用管）
  //   coexist     = 都留着，靠提示词分工
  //   ignore      = 不管
  conflictPolicy: 'autoDisable',
  caps: {
    mainCard: 2200,
    timeline: 2400,
    memo: 1200,
    diary: 600,
    loops: 8,
    total: 7000
  },
  features: {
    mainCard: true,   // 主卡：你自己写的人设/长期设定，空文件就不注入
    timeline: true,
    memo: true,
    diary: true,
    loops: true,
    recall: true,
    relation: false,  // 关系四级（熟悉→暧昧→对象）：伴侣/亲密向角色再打开
    state: false,     // 心情 / 精力 / 温度 6-9
    day: false        // 两套作息表（工作日/周末）
  }
};

const HEADS = {
  '.2.md': '# 时间线（按天往下记，最新的在下面）\n',
  '.5.md': '# 备忘（最新的在最上面）\n',
  '.diary.md': '# 日记（一天最多一条）\n'
};

const pad2 = (n) => String(n).padStart(2, '0');
const stamp = (d = new Date()) => `${pad2(d.getMonth() + 1)}-${pad2(d.getDate())} ${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
const clamp = (text, n) => String(text ?? '').replace(/\s+/g, ' ').trim().slice(0, n);

/** 内核会话 key → kit 认的 key */
function keyOf(chatKey) {
  const raw = String(chatKey || '').trim();
  if (raw.startsWith('group:')) return 'qq:group:' + raw.slice(6);
  if (raw.startsWith('private:')) return 'qq:direct:' + raw.slice(8);
  return 'qq:direct:' + raw.replace(/[:\\/]/g, '-');
}

function readFileSafe(file) {
  try { return fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, ''); } catch { return ''; }
}

function ensureCards(root, key) {
  const base = chatMemoryBase(root, key);
  fs.mkdirSync(path.dirname(base), { recursive: true });
  for (const [suf, head] of Object.entries(HEADS)) {
    const file = base + suf;
    if (!fs.existsSync(file)) fs.writeFileSync(file, head, 'utf8');
  }
  return base;
}

/** 正文行：# 标题、> 注释、<!-- --> 都不进上下文（跟 kit 的 injectable 一致） */
function bodyLines(text) {
  return String(text ?? '').replace(/\r/g, '').split('\n')
    .map((l) => l.trim())
    .filter((l) => l && !l.startsWith('#') && !l.startsWith('>') && !l.startsWith('<!--'));
}

function pickLines(lines, maxChars, fromTail = true) {
  const seq = fromTail ? [...lines].reverse() : [...lines];
  const out = [];
  let used = 0;
  for (const line of seq) {
    if (used + line.length + 1 > maxChars) break;
    out.push(line);
    used += line.length + 1;
  }
  return (fromTail ? out.reverse() : out).join('\n');
}

function trimFile(file, keepLines) {
  try {
    const lines = readFileSafe(file).split('\n');
    if (lines.length <= keepLines) return;
    const head = lines[0].startsWith('#') ? [lines[0]] : [];
    fs.writeFileSync(file, head.concat(lines.slice(-keepLines)).join('\n'), 'utf8');
  } catch { /* 瘦身失败不影响主流程 */ }
}

function appendMain(root, key, text) {
  const base = ensureCards(root, key);
  const file = base + '.md';
  fs.appendFileSync(file, `- ${stamp()} ${clamp(text, 220)}\n`, 'utf8');
  trimFile(file, 300);
}

function addTimeline(root, key, text) {
  const file = ensureCards(root, key) + '.2.md';
  fs.appendFileSync(file, `- ${stamp()} ${clamp(text, 220)}\n`, 'utf8');
  trimFile(file, 400);
}

function addMemo(root, key, text) {
  const file = ensureCards(root, key) + '.5.md';
  const lines = readFileSafe(file).split('\n');
  const head = lines[0].startsWith('#') ? lines[0] : HEADS['.5.md'].trimEnd();
  const rest = lines.slice(1).filter((l) => l.trim());
  fs.writeFileSync(file, [head, `- ${stamp()} ${clamp(text, 200)}`, ...rest].join('\n') + '\n', 'utf8');
  trimFile(file, 200);
}

function setDiary(root, key, text) {
  // 一天一条：整份重写（重复写以最新为准，跟 kit 的语义一致）
  fs.writeFileSync(ensureCards(root, key) + '.diary.md', `${HEADS['.diary.md']}- ${stamp()} ${clamp(text, 300)}\n`, 'utf8');
}

function describeLoop(item) {
  const when = item?.at ? new Date(Number(item.at)).toLocaleString('zh-CN', { hour12: false }) : '没定时间';
  const extra = [item?.kind || '', item?.why || ''].filter(Boolean).join(' · ');
  return `${item.what}｜${when}${extra ? '｜' + extra : ''}（id: ${item.id}）`;
}

/** 组装本轮注入块。全空返回 ''，不占额度。 */
function buildBlock(root, key, feats, caps) {
  const base = chatMemoryBase(root, key);
  const blocks = [];

  if (feats.mainCard) {
    const card = pickLines(bodyLines(readFileSafe(base + '.md')), caps.mainCard, false);
    if (card) blocks.push({ tag: 'chat_card', priority: 0, text: '【长期设定】\n' + card });
  }
  if (feats.timeline) {
    const v = pickLines(bodyLines(readFileSafe(base + '.2.md')), caps.timeline, true);
    if (v) blocks.push({ tag: 'chat_timeline', priority: 5, text: '【时间线 · 发生过的事】\n' + v });
  }
  if (feats.memo) {
    const v = pickLines(bodyLines(readFileSafe(base + '.5.md')), caps.memo, false);
    if (v) blocks.push({ tag: 'chat_memo', priority: 6, text: '【备忘 · 记下的小事】\n' + v });
  }
  if (feats.diary) {
    const v = pickLines(bodyLines(readFileSafe(base + '.diary.md')), caps.diary, true);
    if (v) blocks.push({ tag: 'chat_diary', priority: 7, text: '【日记】\n' + v });
  }
  if (feats.loops) {
    try {
      const open = readChatLoops(root, key).filter((l) => l.status === 'open').slice(0, caps.loops);
      if (open.length) blocks.push({ tag: 'chat_loops', priority: 4, text: '【未了的约定】\n' + open.map((l) => '- ' + describeLoop(l)).join('\n') });
    } catch { /* 约定文件坏了就当没有 */ }
  }
  if (feats.relation) {
    try {
      const v = String(relationContext(root, key) || '').trim();
      if (v) blocks.push({ tag: 'chat_relation', priority: 2, text: v });
    } catch { /* 忽略 */ }
  }
  if (feats.state) {
    try {
      const v = String(stateContext(root, key) || '').trim();
      if (v) blocks.push({ tag: 'chat_state', priority: 3, text: v });
    } catch { /* 忽略 */ }
  }
  if (feats.day) {
    try {
      const v = String(dayContext(Date.now()) || '').trim();
      if (v) blocks.push({ tag: 'chat_day', priority: 8, text: v });
    } catch { /* 忽略 */ }
  }

  if (!blocks.length) return '';
  // 总额度不够时先丢低优先级块（day → diary → memo → timeline …），保主线
  blocks.sort((a, b) => a.priority - b.priority);
  let total = blocks.reduce((n, b) => n + b.text.length, 0);
  while (total > caps.total && blocks.length > 1) {
    const dropped = blocks.pop();
    total -= dropped.text.length;
  }
  return '<chat_memory>\n' + blocks.map((b) => b.text).join('\n\n') + '\n</chat_memory>';
}

/**
 * 探测内核的「轻量记忆」工具是否也装着（memory_append 来自 memory 插件）。
 *
 * 为什么要探测：两套记忆并存时，模型面对两组写入工具会做二选一，
 * 结果是同一条信息两边都写、或者该写的地方都没写。显式告诉它怎么分工，
 * 比让它自己猜可靠得多。
 *
 * 为什么懒探测而不在 activate 里算：插件按 priority 顺序装载，
 * companion(65) 有可能先于 memory 装载，那时探测结果必然是 false。
 * 放到每轮渲染时算，此时所有插件都已就位。
 */
function hasKernelMemoryTool(ctx) {
  try {
    const defs = ctx?.orchestrator?.pluginHost?.toolDefs;
    if (!Array.isArray(defs)) return false;
    return defs.some((t) => String(t?.def?.name || '') === 'memory_append');
  } catch {
    return false;
  }
}

/** 内核的「轻量记忆」插件是否真的在跑（工具挂上了才算） */
function memoryPluginRunning(ctx) {
  try {
    const host = ctx?.orchestrator?.pluginHost;
    const rec = host?.records?.get?.('memory');
    if (rec && rec.status === 'enabled') return true;
    return hasKernelMemoryTool(ctx);
  } catch {
    return false;
  }
}

/**
 * 处理与「轻量记忆」插件的冲突。每轮渲染时调用，但只真正执行一次。
 *
 * 为什么必须处理：两套记忆同时写，模型会在两组工具之间反复权衡，
 * 表现为「同一条内容写两遍」或者「该记的一次都没记」——这不是配置能盖住的语义冲突。
 *
 * 三种政策：
 *   autoDisable（默认）→ 通过 orchestrator.pluginHost 停用 memory 插件，并落一个标记文件；
 *                        标记存在后不再重复抢，用户以后想开回来就能开
 *   coexist            → 不动别人的插件，只在提示词里写清分工
 *   ignore             → 什么都不做
 *
 * @returns {'none'|'coexist'|'disabled'|'blocked'}
 */
function settleMemoryConflict(ctx, policy, root) {
  if (policy === 'ignore') return 'none';
  if (!memoryPluginRunning(ctx)) return 'none';
  if (policy === 'coexist') return 'coexist';

  const marker = path.join(root, 'memory-conflict.json');
  try {
    // 标记存在 = 之前处理过。此时 memory 还在跑，说明是用户自己又开回来的，
    // 不再跟用户抢，降级成提示词约束（只用 companion_* 写）。
    if (fs.existsSync(marker)) return 'blocked';
  } catch { /* 忽略 */ }

  const host = ctx?.orchestrator?.pluginHost;
  if (!host || typeof host.disable !== 'function') return 'blocked';   // 拿不到宿主，降级成提示词约束

  try {
    fs.writeFileSync(marker, JSON.stringify({
      at: Date.now(),
      atText: new Date().toISOString(),
      action: 'disable-memory',
      reason: '两套记忆同时启用会互相覆盖，已由 companion 自动停用轻量记忆'
    }));
  } catch { /* 标记写不进去不影响停用，只是下次可能再判一次 */ }

  Promise.resolve()
    .then(() => host.disable('memory'))
    .then(() => {
      try { host.records?.get?.('memory')?.config?.set?.({ enabled: false }); } catch { /* 配置写失败不影响本次 */ }
      ctx.log('检测到「轻量记忆」插件同时在跑，已自动停用它：两套记忆同时写会互相覆盖。记忆数据仍在 data/memory/，需要恢复就在插件页重新启用。');
    })
    .catch((error) => ctx.log(`自动停用「轻量记忆」失败（请到插件页手动关掉它）：${error?.message ?? error}`));

  return 'disabled';
}

/** 依据开启的能力生成提示词说明（中性措辞，不含任何人设） */
function rulesText(feats, conflict = 'none') {
  const lines = ['【你的长期记忆（跨天有效，重启不丢）】'];
  if (feats.timeline || feats.memo || feats.diary) {
    const kinds = [feats.timeline && 'timeline（发生过的事）', feats.memo && 'memo（琐碎但不想忘的小事）', feats.diary && 'diary（一天一条总结）'].filter(Boolean);
    lines.push(`- 要记住的事用 companion_note 记下来，kind 可选：${kinds.join(' / ')}。`);
    lines.push('- 只记值得跨天记住的，别把每句话都记下来；记完不用汇报「已记录」。');
  }
  if (feats.loops) {
    lines.push('- 对方说「提醒我」「别忘了」「明天」这类话 → companion_loop action=add 并给 at，系统会到点真的叫你；只在嘴上答应等于没答应。');
  }
  if (feats.recall) {
    lines.push('- 对方说「上次」「还记得」「之前说过」→ 先用 companion_recall 翻旧账，别凭印象编。');
  }
  if (feats.state) {
    lines.push('- 你的心情/精力会随对话变化，用 companion_state 调整（mood/energy 增量、doing 表示在干嘛）。注入的状态块决定这轮的语气，跟着它走，别硬装。');
  }
  if (feats.relation) {
    lines.push('- 关系阶段有门槛，用 companion_relation 查看；真心觉得更近了才 action=up，系统会核对证据，不够门槛不会生效。');
  }
  if (conflict === 'coexist') {
    // 同时装了 memory 插件（memory_append 那套）时的分工说明。
    // 不给这条，模型会在两套工具之间反复权衡，表现为"记了两次"或"一次都没记"。
    lines.push('- 这里还有另一套短期记忆工具（memory_append / memory_query / memory_remove）：那套装「刚刚发生的事、你还没说出口的话、对这个人的即时印象」，量少、会被自动整理；你这边装「跨天还要记得的事实、答应过的事」。同一条内容只写一边，别重复记。');
  } else if (conflict === 'disabled') {
    // 已经主动停掉另一方：还要处理内核【记忆】段的残留内容（它直接读 MemoryStore，插件停了数据仍在）
    lines.push('- 这个系统里原有的另一套记忆已经停用。如果上下文里还出现旧的【记忆】段，那是已经冻结的历史快照：可以拿来参考，但不要再往里写，也不要当作最新状态——最新状态以本段为准。');
  } else if (conflict === 'blocked') {
    // 拿不到插件管理器，只能靠提示词约束：明确指定唯一写入入口
    lines.push('- 系统里还挂着一套 memory_* 记忆工具。不要用它们：记忆只有一个入口，就是 companion_* 系列。');
  }
  return lines.length > 1 ? lines.join('\n') : '';
}

export async function activate(ctx) {
  const root = ctx.data.ensure();

  const rawCfg = ctx.config.get() || {};
  const caps = { ...DEFAULTS.caps, ...(rawCfg.caps || {}) };
  const feats = { ...DEFAULTS.features, ...(rawCfg.features || {}) };
  const archiveOn = rawCfg.archive !== false;
  const shareOwner = rawCfg.shareOwnerMemory === true;

  // 与「轻量记忆」插件的冲突策略（见 settleMemoryConflict 的注释）
  const conflictPolicy = ['autoDisable', 'coexist', 'ignore'].includes(rawCfg.conflictPolicy)
    ? rawCfg.conflictPolicy
    : DEFAULTS.conflictPolicy;
  // 判定只做一次：首次渲染时所有插件都已装载完，是唯一能准确判断的时机
  let conflictState = '';

  const memKeyOf = (key) => {
    if (!shareOwner) return key;
    try { return memoryKeyFor(root, key); } catch { return key; }
  };

  // 归档游标：只写「上一轮之后」的新消息；重启后第一轮只播种，不补历史
  const cursors = new Map();

  function archiveNew(chatKey, key) {
    if (!archiveOn || !ctx.store) return;
    try {
      const rows = ctx.store.recent(chatKey, { limit: 40 });
      if (!rows?.length) return;
      const newest = Number(rows[rows.length - 1]?.ts) || 0;
      const last = cursors.get(chatKey);
      if (last === undefined) { cursors.set(chatKey, newest); return; }
      for (const m of rows) {
        if ((Number(m.ts) || 0) <= last) continue;
        const text = clamp(m.text, 600);
        if (!text) continue;
        appendChatArchive(root, key, { text: (m.self ? '我：' : '他：') + text, kind: m.self ? 'self' : 'user' });
      }
      cursors.set(chatKey, newest);
    } catch (error) {
      ctx.log(`归档失败（不影响对话）：${error?.message ?? error}`);
    }
  }

  // ── 每轮注入 ──
  ctx.promptSections.register('companion-memory', (info) => {
    try {
      const chatKey = String(info?.chatKey || '');
      const key = memKeyOf(keyOf(chatKey));
      // 注入阶段只读不建：否则机器人待过的每个群都会留下一套空卡片文件
      archiveNew(chatKey, key);
      if (!conflictState) conflictState = settleMemoryConflict(ctx, conflictPolicy, root);
      const block = buildBlock(root, key, feats, caps);
      const rules = rulesText(feats, conflictState);
      if (!rules && !block) return '';
      return [rules, block].filter(Boolean).join('\n\n');
    } catch (error) {
      ctx.log(`记忆块渲染失败（本轮跳过）：${error?.message ?? error}`);
      return '';
    }
  });

  // ── 工具 1：记一条 ──
  ctx.tools.register({
    name: 'companion_note',
    description: '往长期记忆里记一条。kind=timeline（发生过的事，默认）/ memo（琐碎的小事、偏好）/ diary（一天一条总结）/ main（补进长期设定卡）。只在真值得跨天记住时用。',
    parameters: {
      type: 'object',
      properties: {
        kind: { type: 'string', description: 'timeline（默认）| memo | diary | main' },
        text: { type: 'string', description: '记什么，一句话，别超过 100 字' }
      },
      required: ['text']
    },
    async execute(toolCtx, args) {
      try {
        const text = clamp(args?.text, 300);
        if (!text) return err('要记的内容是空的');
        const key = memKeyOf(keyOf(toolCtx.chatKey));
        const kind = String(args?.kind || 'timeline').toLowerCase();
        if (kind === 'memo') { addMemo(root, key, text); return ok({ saved: 'memo', text }); }
        if (kind === 'diary') { setDiary(root, key, text); return ok({ saved: 'diary', text }); }
        if (kind === 'main') { appendMain(root, key, text); return ok({ saved: 'main', text }); }
        addTimeline(root, key, text);
        return ok({ saved: 'timeline', text });
      } catch (error) {
        return err(`记不下：${error?.message ?? error}`);
      }
    }
  });

  // ── 工具 2：约定（带 at 会真的排进定时任务）──
  if (feats.loops) {
    ctx.tools.register({
      name: 'companion_loop',
      description: '管理「未了的约定」：答应对方、到点该提醒的事。action=add 时给 at（ISO 本地时间）会同步排进定时任务，到点真的叫你；done/cancel 会一并撤掉定时；list 查看未了的事。',
      masterOnly: true,
      parameters: {
        type: 'object',
        properties: {
          action: { type: 'string', description: 'add（默认）| list | done | cancel' },
          what: { type: 'string', description: '答应/要提醒的事，一句话' },
          at: { type: 'string', description: '提醒时间，ISO 本地格式 YYYY-MM-DDTHH:MM:SS。只想记账不想被叫醒就别给。' },
          kind: { type: 'string', description: '类别，如 care / promise / task，可空' },
          why: { type: 'string', description: '为什么记这条，可空' },
          id: { type: 'string', description: 'done/cancel 时的约定 id（先用 list 看）' }
        },
        required: []
      },
      async execute(toolCtx, args) {
        try {
          const key = memKeyOf(keyOf(toolCtx.chatKey));
          const action = String(args?.action || 'add').toLowerCase();
          const list = readChatLoops(root, key);

          if (action === 'list') {
            const open = list.filter((l) => l.status === 'open');
            if (!open.length) return ok('没有未了的事。');
            return ok('【未了的约定】\n' + open.map((l) => '- ' + describeLoop(l)).join('\n'));
          }

          if (action === 'done' || action === 'cancel') {
            const id = String(args?.id || '').trim();
            const what = String(args?.what || '').trim();
            const hit = id
              ? list.find((l) => l.id === id)
              : list.find((l) => l.status === 'open' && what && String(l.what || '').includes(what));
            if (!hit) return err('没找到这条约定（可先用 action=list 看 id）');
            hit.status = action === 'done' ? 'done' : 'cancelled';
            hit.closedAt = Date.now();
            saveChatLoops(root, key, list);
            let removed = false;
            if (hit.taskId) { try { removed = ST.removeTask(hit.taskId); } catch { /* 任务已不在 */ } }
            return ok({ id: hit.id, status: hit.status, alsoRemovedReminder: removed });
          }

          const what = String(args?.what || '').trim();
          if (!what) return err('要记的约定是什么？（what）');
          const atRaw = String(args?.at || '').trim();
          let at = 0;
          let task = null;
          let reminderError = '';
          if (atRaw) {
            at = new Date(atRaw).getTime();
            if (!Number.isFinite(at)) return err('at 格式不对，应为 YYYY-MM-DDTHH:MM:SS');
            if (at <= Date.now()) return err('at 是过去的时间');
            // 排提醒是加分项，排不上也得把约定本身记下来：
            // 不同版本里 scheduled-tasks 的签名可能不一样，别让它带崩整次调用。
            try {
              task = ST.addTask({ chatKey: toolCtx.chatKey, text: '到点了：' + what, at, repeat: 'none', kind: 'reminder' });
            } catch (error) {
              reminderError = String(error?.message ?? error);
              ctx.log(`约定排提醒失败（只记账，不影响记录）：${reminderError}`);
            }
          }
          const item = {
            id: 'loop' + Math.random().toString(36).slice(2, 8),
            what: clamp(what, 80),
            at,
            kind: clamp(args?.kind, 16),
            why: clamp(args?.why, 80),
            status: 'open',
            made: stamp(),
            taskId: task?.id || null
          };
          list.push(item);
          saveChatLoops(root, key, list);
          return ok({
            saved: item.id,
            when: at ? new Date(at).toLocaleString('zh-CN', { hour12: false }) : '只记账，不叫醒',
            reminder: task ? task.id : null,
            ...(reminderError ? { reminderNote: `约定记下了，但没排上自动提醒（${reminderError}）` } : {})
          });
        } catch (error) {
          return err(`约定操作失败：${error?.message ?? error}`);
        }
      }
    });
  }

  // ── 工具 3：翻旧账 ──
  if (feats.recall) {
    ctx.tools.register({
      name: 'companion_recall',
      description: '在历史归档里按关键词翻旧事（同义词会自动扩展）。对方说「上次」「还记得」「之前说过」时先用它，别凭印象编。',
      parameters: {
        type: 'object',
        properties: { query: { type: 'string', description: '关键词，一两个词就够' } },
        required: ['query']
      },
      async execute(toolCtx, args) {
        try {
          const query = clamp(args?.query, 60);
          if (!query) return err('要给个关键词');
          const rows = await searchChatArchive(root, memKeyOf(keyOf(toolCtx.chatKey)), query, 6);
          if (!rows?.length) return ok('翻过了，没找到相关的事。');
          return ok('【翻到的旧事】\n' + rows.map((r) => '- ' + clamp(r.text ?? r, 220)).join('\n'));
        } catch (error) {
          return err(`翻旧账失败：${error?.message ?? error}`);
        }
      }
    });
  }

  // ── 工具 4：心情/精力（可选）──
  if (feats.state) {
    ctx.tools.register({
      name: 'companion_state',
      description: '调整或查看自己的心情(mood 0-100)与精力(energy 0-100)，以及"正在做什么"(doing)。增量式：mood=+5 表示心情好了一点。注入的状态块决定这轮语气。',
      parameters: {
        type: 'object',
        properties: {
          action: { type: 'string', description: 'get（默认）| bump' },
          mood: { type: 'number', description: '心情增量，如 +5 / -8' },
          energy: { type: 'number', description: '精力增量，如 -10' },
          doing: { type: 'string', description: '正在做什么，一句话（2 小时内有效）' }
        },
        required: []
      },
      async execute(toolCtx, args) {
        try {
          const key = memKeyOf(keyOf(toolCtx.chatKey));
          if (String(args?.action || 'get').toLowerCase() === 'get') {
            const st = readState(root, key);
            return ok({ mood: st.mood, energy: st.energy, doing: st.doing ?? null, temperature: st.temperature ?? null });
          }
          const parts = [];
          const mood = Number(args?.mood);
          const energy = Number(args?.energy);
          const doing = String(args?.doing || '').trim();
          if (Number.isFinite(mood) && mood !== 0) parts.push(`[MOOD:${mood > 0 ? '+' : ''}${mood}]`);
          if (Number.isFinite(energy) && energy !== 0) parts.push(`[ENERGY:${energy > 0 ? '+' : ''}${energy}]`);
          if (doing) parts.push(`[DOING:${doing.slice(0, 40)}]`);
          if (!parts.length) return err('要给 mood / energy 增量，或 doing');
          const res = applyStateMarkers(root, key, { text: parts.join(' ') + ' ' });
          const st = res?.state || readState(root, key);
          return ok({ mood: st.mood, energy: st.energy, doing: st.doing ?? null, changed: res?.changed === true });
        } catch (error) {
          return err(`状态操作失败：${error?.message ?? error}`);
        }
      }
    });
  }

  // ── 工具 5：关系阶段（可选）──
  if (feats.relation) {
    ctx.tools.register({
      name: 'companion_relation',
      description: '查看或推进「关系阶段」（1 陌生 → 2 熟悉 → 3 暧昧 → 4 对象）。升级有门槛（认识天数/往来条数/对方说过亲密话），不够门槛不会生效；action=down 用于关系退回。',
      parameters: {
        type: 'object',
        properties: {
          action: { type: 'string', description: 'get（默认）| up | down' },
          him: { type: 'string', description: '对方这句话的原话（判断他是否表态），可空' }
        },
        required: []
      },
      async execute(toolCtx, args) {
        try {
          const key = memKeyOf(keyOf(toolCtx.chatKey));
          const action = String(args?.action || 'get').toLowerCase();
          const rel = readRelation(root, key);
          if (action === 'get') {
            return ok({ stage: rel.stage, evidence: rel.evidence?.total ?? 0, context: relationContext(root, key) });
          }
          const marker = action === 'up' ? '[RELATION_UP]' : '[RELATION_DOWN]';
          const res = applyRelationMarkers(root, key, { text: marker, him: String(args?.him || '') });
          const after = readRelation(root, key);
          return ok({ stageBefore: rel.stage, stageAfter: after.stage, changed: res?.changed === true, note: res?.changed ? '已生效' : '条件没到，没生效（系统会记一条理由）' });
        } catch (error) {
          return err(`关系操作失败：${error?.message ?? error}`);
        }
      }
    });
  }

  // ── 工具 6：自查 ──
  ctx.tools.register({
    name: 'companion_status',
    description: '看长期记忆里各写有多少条、有几条未了约定。被问「你都记得什么」时用它如实回答，不要编。',
    parameters: { type: 'object', properties: {} },
    async execute(toolCtx) {
      try {
        const key = memKeyOf(keyOf(toolCtx.chatKey));
        const base = ensureCards(root, key);
        const count = (suf) => bodyLines(readFileSafe(base + suf)).length;
        const out = {
          mainCard: count('.md'),
          timeline: count('.2.md'),
          memo: count('.5.md'),
          diary: count('.diary.md'),
          openLoops: readChatLoops(root, key).filter((l) => l.status === 'open').length
        };
        if (feats.relation) out.relationStage = readRelation(root, key).stage;
        if (feats.state) { const st = readState(root, key); out.mood = st.mood; out.energy = st.energy; out.doing = st.doing ?? null; }
        return ok(out);
      } catch (error) {
        return err(`自查失败：${error?.message ?? error}`);
      }
    }
  });

  // ── 只读面板：给控制台/脚本看卡片现状（不提供写入，避免误删）──
  ctx.http.route('GET', '/cards', async (req, body, url) => {
    const chatKey = String(url?.searchParams?.get('chatKey') || '').trim();
    if (!chatKey) return { error: '需要 chatKey，例如 private:10001 或 group:778899' };
    const key = memKeyOf(keyOf(chatKey));
    const base = chatMemoryBase(root, key);
    return {
      key,
      cards: Object.fromEntries(
        ['.md', '.2.md', '.5.md', '.diary.md'].map((suf) => [suf, readFileSafe(base + suf)])
      ),
      loops: readChatLoops(root, key)
    };
  });

  const on = Object.entries(feats).filter(([, v]) => v).map(([k]) => k).join(',');
  ctx.log(`已就绪 · 数据 ${root} · 开启：${on} · 冲突策略：${conflictPolicy}`);
  // 启动时先探一次：此刻 memory 可能还没装载，所以只把「确认有冲突」的结果缓存下来，
  // 'none' 不缓存——否则首轮渲染不会再判，等于永远漏掉。
  try {
    const s = settleMemoryConflict(ctx, conflictPolicy, root);
    if (s !== 'none') conflictState = s;
  } catch { /* 首轮会重试 */ }
  return { dispose() { cursors.clear(); } };
}
