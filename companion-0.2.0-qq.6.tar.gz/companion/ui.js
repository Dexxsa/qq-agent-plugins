// ══════════════════════════════════════════════════════════════
//  companion · 插件配置面板
// ══════════════════════════════════════════════════════════════
//
//  架构约束：插件前端代码放在插件自己的目录里，不写进内核 ui/app.js。
//  内核通过 mountPanel(box, ctx) 调用；ctx 里可用：
//    api / toast / esc / $ / pluginConfigOf / savePluginConfig /
//    panelShell / bindPanelClose / pluginId
//
//  设计原则：
//  ① 默认值必须和 index.js 的 DEFAULTS 完全一致——两边不一致，
//     用户看到「开着」但实际没开，是最难查的一类 bug。
//  ② 保存走 patch 合并语义，前端只提交自己管的那几项，
//     不整体覆盖 plugins.companion，避免把别的字段（如 scopes）冲掉。
//  ③ 高级项（注入预算）折叠起来，默认展开只给开关——
//     大多数人只需要知道「开/关」，不需要知道 token 预算。

const DEFAULT_FEATURES = {
  mainCard: true,
  timeline: true,
  memo: true,
  diary: true,
  loops: true,
  recall: true,
  relation: false,
  state: false,
  day: false
};

const DEFAULT_CAPS = {
  mainCard: 2200,
  timeline: 2400,
  memo: 1200,
  diary: 600,
  loops: 8,
  total: 7000
};

// 开关分组：默认开的一组，需要人设配合的一组。
// 分组很重要——把 relation/state/day 和别的混在一起，
// 用户会顺手全勾上，然后发现机器人突然开始撒娇、报心情、按上班作息说话。
const GROUPS = [
  {
    title: '长期记忆（对任何角色都成立）',
    hint: '这几项不改变说话风格，只让它记得住跨天的事。',
    items: [
      ['mainCard', '主卡', '长期设定：身份、称呼、必须记住的约定。卡片空着就不注入，不占提示词。'],
      ['timeline', '时间线', '按天记录发生过的事，最新的在最后。'],
      ['memo', '备忘', '零碎的偏好和小事，最新的在最前。'],
      ['diary', '日记', '一天最多一条的总结。'],
      ['loops', '未了约定', '答应过的事。带具体时间的会同步排进内核定时任务，到点真的提醒。'],
      ['recall', '归档检索', '按关键词（含同义词）翻旧账，用于「我上次说过什么」这类问题。']
    ]
  },
  {
    title: '角色状态（需要对应人设才开）',
    hint: '这三项会往提示词里注入情绪/作息类内容，只有角色本身就是这种设定时才成立。给冷酷或公文型角色打开，会明显跑偏。勾完点保存只是写进配置，还要回插件页点一次本插件的「重载」才会真正注入。',
    items: [
      ['relation', '关系阶段', '陌生 → 熟悉 → 暧昧 → 对象，需要模型主动推进且过证据门槛。'],
      ['state', '心情 / 精力', '会随对话变化的心情与精力值，影响这轮语气。'],
      ['day', '作息表', '工作日 / 周末两套作息，影响它觉得自己在干嘛。']
    ]
  }
];

const FEATURE_LABEL = Object.fromEntries(GROUPS.flatMap((g) => g.items.map(([k, label]) => [k, label])));

export async function mountPanel(box, ctx) {
  const { $, api, esc, toast, panelShell, bindPanelClose, savePluginConfig, pluginConfigOf } = ctx;

  let cfg = {};
  try {
    cfg = (await pluginConfigOf(ctx.pluginId)) || {};
  } catch (error) {
    toast('读取配置失败：' + error.message);
  }

  const feats = { ...DEFAULT_FEATURES, ...(cfg.features || {}) };
  const caps = { ...DEFAULT_CAPS, ...(cfg.caps || {}) };
  const archiveOn = cfg.archive !== false;
  const shareOwner = cfg.shareOwnerMemory === true;
  const policy = ['autoDisable', 'coexist', 'ignore'].includes(cfg.conflictPolicy) ? cfg.conflictPolicy : 'autoDisable';

  const switchRow = ([key, label, desc], kind) => `
    <div class="checkbox-row" style="align-items:flex-start">
      <input type="checkbox" id="cp-f-${key}" data-feature="${key}" ${feats[key] ? 'checked' : ''} />
      <label for="cp-f-${key}" style="line-height:1.5">
        <b>${esc(label)}</b>
        ${kind === 'persona' ? '<span class="muted" style="font-size:12px"> · 需要人设配合</span>' : ''}
        <div class="muted" style="font-size:12px">${esc(desc)}</div>
      </label>
    </div>`;

  const numRow = ([key, label, fallback]) => `
    <div class="field">
      <label>${esc(label)}</label>
      <input type="number" min="0" step="100" id="cp-c-${key}" value="${Number(caps[key] ?? fallback)}" style="width:120px" />
    </div>`;

  box.innerHTML = panelShell('companion', '记忆与约定', `
    <p class="muted" style="font-size:13px;margin:0">
      分层卡片记忆 + 未了约定 + 归档检索。每轮把卡片内容注入提示词，
      模型用 4~6 个工具往里写。数据存在 <code>data/plugins/companion/</code>，
      不随插件包一起导出。
    </p>

    ${GROUPS.map((g, i) => `
      <div data-group="${i}" style="margin-top:16px;padding-top:14px;border-top:1px solid rgba(128,128,128,.18)">
        <div class="row" style="align-items:baseline;gap:8px">
          <b style="font-size:13px">${esc(g.title)}</b>
          <span class="spacer" style="flex:1"></span>
          <button class="btn tiny" data-preset="${i === 0 ? 'all' : 'none'}">
            ${i === 0 ? '全开' : '全关'}
          </button>
        </div>
        <p class="muted" style="font-size:12px;margin:4px 0 8px">${esc(g.hint)}</p>
        ${g.items.map((it) => switchRow(it, i === 0 ? 'core' : 'persona')).join('')}
      </div>`).join('')}

    <div style="margin-top:16px;padding-top:14px;border-top:1px solid rgba(128,128,128,.18)">
      <b style="font-size:13px">数据与检索</b>
      <div class="checkbox-row" style="align-items:flex-start;margin-top:8px">
        <input type="checkbox" id="cp-archive" ${archiveOn ? 'checked' : ''} />
        <label for="cp-archive" style="line-height:1.5">
          <b>归档新消息</b>
          <div class="muted" style="font-size:12px">每轮把新消息写进本地 jsonl，供「翻旧账」检索。关闭后 recall 只能查到开过归档时期的记录。</div>
        </label>
      </div>
      <div class="checkbox-row" style="align-items:flex-start">
        <input type="checkbox" id="cp-share" ${shareOwner ? 'checked' : ''} />
        <label for="cp-share" style="line-height:1.5">
          <b>群聊复用私聊卡片</b>
          <div class="muted" style="font-size:12px">开启后群聊读的是和私聊同一套卡片。默认关闭，各群独立记忆，避免把私聊的事说漏到群里。</div>
        </label>
      </div>
      <div class="checkbox-row" style="align-items:flex-start">
        <label for="cp-conflict" style="line-height:1.5;width:100%">
          <b>和「轻量记忆」撞车时</b>
          <div class="muted" style="font-size:12px;margin:4px 0 6px">
            两套记忆同时写会互相覆盖：同一条内容可能记两遍，也可能一次都没记。这是唯一需要你选的地方。
          </div>
          <select id="cp-conflict" style="max-width:380px">
            <option value="autoDisable" ${policy === 'autoDisable' ? 'selected' : ''}>自动停用「轻量记忆」（推荐，装完不用管）</option>
            <option value="coexist" ${policy === 'coexist' ? 'selected' : ''}>两套都留，靠提示词分工</option>
            <option value="ignore" ${policy === 'ignore' ? 'selected' : ''}>什么都不做</option>
          </select>
          <div class="muted" style="font-size:12px;margin-top:6px">
            自动停用只做一次，而且会留一个标记文件（<code>data/plugins/companion/memory-conflict.json</code>）。之后你手动把轻量记忆开回来，它不会再抢，只会在提示词里要求模型只用 companion_* 写。
          </div>
        </label>
      </div>
    </div>

    <details style="margin-top:16px">
      <summary style="cursor:pointer;font-size:13px" class="muted">高级 · 注入预算（字数上限）</summary>
      <div class="field-row" style="margin-top:10px;flex-wrap:wrap;gap:12px">
        ${numRow(['mainCard', '主卡', 2200])}
        ${numRow(['timeline', '时间线', 2400])}
        ${numRow(['memo', '备忘', 1200])}
        ${numRow(['diary', '日记', 600])}
        ${numRow(['loops', '约定条数', 8])}
        ${numRow(['total', '总上限', 7000])}
      </div>
      <p class="muted" style="font-size:12px;margin:8px 0 0">
        总上限是硬顶：超过就按「主卡 → 约定 → 时间线 → 备忘 → 日记」的优先级逐块裁剪。
        调太大会挤占对话本身的空间。
      </p>
    </details>

    <div class="row" style="margin-top:16px;gap:8px">
      <button class="btn primary" id="cp-save">保存</button>
      <span class="muted" style="font-size:12px;line-height:1.6" id="cp-tip">保存后回插件页点一次本插件的「重载」才生效（约 1 秒，不掉线；注入内容是装载时快照的）。</span>
    </div>

    <div style="margin-top:18px;padding-top:14px;border-top:1px solid rgba(128,128,128,.18)">
      <b style="font-size:13px">查看卡片</b>
      <p class="muted" style="font-size:12px;margin:4px 0 8px">只读。填会话键，如 <code>private:10001</code> 或 <code>group:778899</code>。</p>
      <div class="row" style="gap:8px">
        <input id="cp-chat" placeholder="private:10001" style="width:240px" />
        <button class="btn" id="cp-view">查看</button>
      </div>
      <div id="cp-out" style="margin-top:10px"></div>
    </div>
  `, '数据存 data/plugins/companion/，卸载插件不会自动删除');

  bindPanelClose(box);

  // 分组「全开 / 全关」：只动本组的开关，不碰另一组
  box.querySelectorAll('[data-preset]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.preset === 'all';
      const scope = btn.closest('[data-group]');
      if (!scope) return;
      scope.querySelectorAll('input[data-feature]').forEach((el) => { el.checked = target; });
    });
  });

  $('#cp-save')?.addEventListener('click', async () => {
    const nextFeatures = {};
    box.querySelectorAll('input[data-feature]').forEach((el) => {
      nextFeatures[el.dataset.feature] = el.checked;
    });
    const nextCaps = {};
    for (const key of Object.keys(DEFAULT_CAPS)) {
      const el = $('#cp-c-' + key);
      if (el) nextCaps[key] = Math.max(0, Number(el.value) || 0);
    }
    try {
      await savePluginConfig(ctx.pluginId, {
        conflictPolicy: $('#cp-conflict')?.value || 'autoDisable',
        archive: $('#cp-archive').checked,
        shareOwnerMemory: $('#cp-share').checked,
        features: nextFeatures,
        caps: nextCaps
      });
      toast('已保存 · 回插件页点「重载」生效');
      const onPersona = Object.keys(nextFeatures).filter((k) => nextFeatures[k] && !DEFAULT_FEATURES[k]);
      const tip = $('#cp-tip');
      if (tip) {
        tip.textContent = onPersona.length
          ? `已开启角色状态类：${onPersona.map((k) => FEATURE_LABEL[k] || k).join('、')}。回插件页点「重载」才生效；确认人设确实是这样，否则语气会跑偏。`
          : '已保存。回插件页点一次本插件的「重载」才生效（约 1 秒，不掉线）。';
      }
    } catch (error) {
      toast('保存失败：' + error.message);
    }
  });

  $('#cp-view')?.addEventListener('click', async () => {
    const chatKey = ($('#cp-chat').value || '').trim();
    const out = $('#cp-out');
    if (!chatKey) { out.innerHTML = '<span class="muted">请填会话键</span>'; return; }
    out.innerHTML = '<span class="muted">读取中…</span>';
    try {
      const r = await api(`/api/plugins/${encodeURIComponent(ctx.pluginId)}/cards?chatKey=${encodeURIComponent(chatKey)}`);
      if (!r || r.error) { out.innerHTML = `<span class="error">${esc(r?.error || '读取失败')}</span>`; return; }
      const names = { '.md': '主卡', '.2.md': '时间线', '.5.md': '备忘', '.diary.md': '日记' };
      const parts = Object.entries(r.cards || {}).map(([suf, text]) => {
        const body = String(text || '').trim();
        return `<div style="margin-bottom:10px">
          <div style="font-size:12px;font-weight:600">${esc(names[suf] || suf)} · ${body.length} 字</div>
          <pre style="white-space:pre-wrap;word-break:break-word;font-size:12px;line-height:1.6;margin:4px 0 0;max-height:220px;overflow:auto">${esc(body || '（空）')}</pre>
        </div>`;
      });
      const loops = Array.isArray(r.loops) ? r.loops : [];
      const LOOP_ST = { open: '未了', done: '已完成', cancelled: '已取消', canceled: '已取消' };
      const loopHtml = loops.length
        ? loops.map((l) => {
            // 约定条目的正文字段是 what（注入提示词时 describeLoop 用的也是它）。
            // 早期这里误读成 l.text，于是一条正常约定会被渲染成「[done] (时间戳)」。
            const what = String(l.what || l.text || l.content || '').trim().slice(0, 160);
            const n = Number(l.at);
            const when = l.at
              ? (!Number.isFinite(n) || n <= 0 ? String(l.at) : new Date(n).toLocaleString('zh-CN', { hour12: false }))
              : '';
            const extra = [l.kind, l.why].filter(Boolean).join(' · ');
            const st = LOOP_ST[l.status] || l.status || '未了';
            return `<div style="font-size:12px;line-height:1.6">
              · <span class="muted">[${esc(st)}]</span> ${esc(what || '（这条没有正文）')}
              ${when ? `<span class="muted">（${esc(when)}）</span>` : ''}
              ${extra ? `<span class="muted">｜${esc(extra)}</span>` : ''}
            </div>`;
          }).join('')
        : '<div class="muted" style="font-size:12px">（没有约定）</div>';
      out.innerHTML = `<div style="font-size:12px" class="muted">存储键：${esc(r.key || chatKey)}</div>
        ${parts.join('')}
        <div style="font-size:12px;font-weight:600;margin-top:6px">未了约定 · ${loops.length} 条</div>${loopHtml}`;
    } catch (error) {
      out.innerHTML = `<span class="error">${esc(error.message)}</span>`;
    }
  });
}

export default { mountPanel };
