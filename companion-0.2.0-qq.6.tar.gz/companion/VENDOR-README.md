# dsh-companion-kit

给 DSH 的「长期陪伴型角色」上下文层。每轮往提示词前面插一块材料，再从她的回复里把标记写回文件。
**包内不含任何数据**：装完是一张空白人设，你的卡、聊天记录、状态全部留在 `<dataRoot>`。

## 它解决什么

普通对话里，角色记不住跨天的事、没有心情、没有作息、聊久了还会把人设忘掉。
这套东西把「记忆」做成文件，把「状态」做成数字，把「写回」做成标记，全部离线、可读、可改。

## 能力

- **分层记忆**：主卡（人设）／时间线（按天）／备忘（她记的小事）／日记／说明卡，各有额度
- **约定唤醒**：她说「明天提醒你」会落成一条约定，到点后台提醒，他回一句自动完成
- **关系阶段**：四级，按认识天数／往来条数／亲密话次数解锁，不是想升就升
- **心情精力温度**：温度由心情、精力、时段推出，夹在 6–9，不会冷到不理人
- **两套作息**：工作日和周末，含「这个点睡了」的迷糊档
- **群聊模式**：群里知道自己是客，共享主人资料但不泄露私聊约定
- **归档检索**：关键词 + 16 组同义词，离线查旧事
- **语音／图片**：语音剥壳、没转写就标注；图片只留占位，不假装看得见（`docs/VOICE.md`）

## 不含什么

语音转写引擎、图片识别、平台收发、定时调度器、表情库——这些留给适配层。
本套件只做「材料怎么组、标记怎么回写」这一层。

## 快速开始

```bash
node bin/companion.mjs init --root ~/.dsh-companion --key local:direct:main
node bin/companion.mjs status --root ~/.dsh-companion --key local:direct:main
node bin/companion.mjs context --root ~/.dsh-companion --key local:direct:main --him "在吗"
```

装进 DSH：`docs/INSTALL.md`。它怎么运作：`docs/HOW-IT-WORKS.md`。
语音怎么弄：`docs/VOICE.md`。版本兼容：`docs/COMPAT.md`。数据边界：`docs/PRIVACY.md`。
