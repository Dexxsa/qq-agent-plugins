// ══════════════════════════════════════════════════════════════
//  napcat-alert · 极简 SMTP 客户端
// ══════════════════════════════════════════════════════════════
//
//  为什么不装 nodemailer：这个插件只有「发一封纯文本 + 一张 PNG」的需求，
//  而 qq-agent 的依赖表里刻意只有 4 个包（js-yaml / qrcode / undici / ws）。
//  为了一封告警邮件拉一个 200KB 的依赖，还得让用户在每台机器上 npm install，
//  不划算。SMTP 的必需子集很短：EHLO → (STARTTLS) → AUTH LOGIN → MAIL/RCPT/DATA。
//  这里就实现这一段，约 200 行，没有任何依赖。
//
//  支持：
//    - 465 隐式 TLS（QQ / 163 / 企业邮）
//    - 587 STARTTLS（Gmail）
//    - 25 明文（内网中继）
//    - AUTH LOGIN / AUTH PLAIN
//    - multipart/mixed，纯文本正文（base64，中文无乱码）+ 附件（二维码 PNG）
//
//  所有失败都带上 SMTP 服务器的原话（如「535 Login Fail」），
//  面板上直接显示这句话，比「发送失败」有用得多。

import net from 'node:net';
import tls from 'node:tls';

const TIMEOUT_MS = 25000;

/** 把 socket 包成「按行读」的信道，配合 readReply 解析多行响应。 */
function makeChannel(socket) {
  let buf = '';
  const queue = [];
  let waiter = null;

  const pushLine = (line) => {
    if (waiter) {
      const w = waiter;
      waiter = null;
      w(line);
    } else {
      queue.push(line);
    }
  };

  socket.setEncoding('utf8');
  socket.on('data', (chunk) => {
    buf += chunk;
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      let line = buf.slice(0, i);
      buf = buf.slice(i + 1);
      if (line.endsWith('\r')) line = line.slice(0, -1);
      pushLine(line);
    }
  });

  const nextLine = (timeoutMs = TIMEOUT_MS) => new Promise((resolve, reject) => {
    if (queue.length) return resolve(queue.shift());
    const timer = setTimeout(() => {
      waiter = null;
      reject(new Error('等待 SMTP 响应超时'));
    }, timeoutMs);
    waiter = (line) => {
      clearTimeout(timer);
      resolve(line);
    };
  });

  return { socket, nextLine };
}

/** 读一条完整响应（支持 250-XXX 多行）。 */
async function readReply(ch) {
  const first = await ch.nextLine();
  const m = /^(\d{3})([ -])(.*)$/.exec(first);
  if (!m) throw new Error(`SMTP 响应格式异常：${first.slice(0, 120)}`);
  let code = Number(m[1]);
  let text = m[3];
  if (m[2] === '-') {
    for (;;) {
      const line = await ch.nextLine();
      const mm = /^(\d{3})([ -])(.*)$/.exec(line);
      text += '\n' + (mm ? mm[3] : line);
      if (mm && mm[2] === ' ') {
        code = Number(mm[1]);
        break;
      }
    }
  }
  return { code, text };
}

async function cmd(ch, line, okCodes = [250]) {
  ch.socket.write(line + '\r\n');
  const r = await readReply(ch);
  if (!okCodes.includes(r.code)) {
    const head = line.split(' ')[0];
    throw new Error(`${head} 失败：${r.code} ${String(r.text).slice(0, 200)}`);
  }
  return r;
}

function connect(host, port, useTls) {
  return new Promise((resolve, reject) => {
    const opts = { host, port };
    const s = useTls
      ? tls.connect({ ...opts, servername: host }, () => resolve(s))
      : net.connect(opts, () => resolve(s));
    s.setTimeout(TIMEOUT_MS);
    s.once('error', reject);
    s.once('timeout', () => reject(new Error(`连接 ${host}:${port} 超时`)));
  });
}

function b64Block(buf) {
  const s = buf.toString('base64');
  const out = [];
  for (let i = 0; i < s.length; i += 76) out.push(s.slice(i, i + 76));
  return out.join('\r\n');
}

function encodeHeader(text) {
  const s = String(text ?? '');
  // 全 ASCII 直接写；含中文则 RFC2047 base64
  if (/^[\x20-\x7e]*$/.test(s)) return s;
  return `=?UTF-8?B?${Buffer.from(s, 'utf8').toString('base64')}?=`;
}

/**
 * 拼一封 MIME 邮件。
 *
 * 三种形态（按需嵌套，别的一律不加）：
 *   ① 纯文本 + 附件            multipart/mixed
 *   ② 纯文本 + 内嵌图 + 附件    mixed → related → text/plain + image(cid)
 *   ③ 纯文本 + HTML + 内嵌图    mixed → related → alternative(plain+html) + image(cid)
 *
 * 为什么要 ③：二维码只放在附件里，手机端得先点开附件才能看，
 * 很多人截图再扫就扫不出来（附件预览缩得很小）。写进正文里、按 cid 内嵌，
 * 邮件一打开就是一张 320px 的大图，直接截图或拿另一台手机扫都行。
 */
export function buildMessage({ from, to, subject, text, html, attachments = [], inline = [] }) {
  const stamp = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
  const bMix = `----napcat-mix-${stamp}`;
  const bRel = `----napcat-rel-${stamp}`;
  const bAlt = `----napcat-alt-${stamp}`;
  const toList = Array.isArray(to) ? to : String(to || '').split(/[,;，；\s]+/).filter(Boolean);

  const textLines = [
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    b64Block(Buffer.from(text, 'utf8'))
  ];
  const htmlLines = html
    ? [
      'Content-Type: text/html; charset=UTF-8',
      'Content-Transfer-Encoding: base64',
      '',
      b64Block(Buffer.from(html, 'utf8'))
    ]
    : null;

  // 正文：有 HTML 就是 alternative（客户端自己挑），没有就纯文本
  let body = htmlLines
    ? [
      `Content-Type: multipart/alternative; boundary="${bAlt}"`,
      '',
      `--${bAlt}`,
      ...textLines,
      `--${bAlt}`,
      ...htmlLines,
      `--${bAlt}--`
    ]
    : textLines;

  // 内嵌图：related，正文按 cid: 引用
  if (inline.length) {
    const relParts = [`--${bRel}`, ...body];
    for (const a of inline) {
      if (!a || !a.content) continue;
      relParts.push(
        `--${bRel}`,
        `Content-Type: ${a.contentType || 'image/png'}; name="${a.filename || 'inline.png'}"`,
        'Content-Transfer-Encoding: base64',
        `Content-ID: <${a.cid}>`,
        `Content-Disposition: inline; filename="${a.filename || 'inline.png'}"`,
        '',
        b64Block(a.content)
      );
    }
    relParts.push(`--${bRel}--`);
    body = [`Content-Type: multipart/related; boundary="${bRel}"`, '', ...relParts];
  }

  const lines = [
    `From: ${from}`,
    `To: ${toList.join(', ')}`,
    `Subject: ${encodeHeader(subject)}`,
    `Date: ${new Date().toUTCString()}`,
    `Message-ID: <${Date.now()}.${Math.random().toString(36).slice(2)}@napcat-alert>`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/mixed; boundary="${bMix}"`,
    '',
    `--${bMix}`,
    ...body
  ];
  for (const a of attachments) {
    if (!a || !a.content) continue;
    lines.push(
      `--${bMix}`,
      `Content-Type: ${a.contentType || 'application/octet-stream'}; name="${a.filename || 'attachment'}"`,
      'Content-Transfer-Encoding: base64',
      `Content-Disposition: attachment; filename="${a.filename || 'attachment'}"`,
      '',
      b64Block(a.content)
    );
  }
  lines.push(`--${bMix}--`, '');
  return lines.join('\r\n');
}

/**
 * 发一封邮件。
 * @param {object} cfg { host, port, tls, user, pass }
 * @param {object} mail { from, to, subject, text, html, attachments, inline }
 * @returns {Promise<{ms:number, server:string}>}
 */
export async function sendMail(cfg, mail) {
  const host = String(cfg?.host || '').trim();
  if (!host) throw new Error('未配置 SMTP 服务器');
  const port = Number(cfg?.port) || 465;
  const mode = String(cfg?.tls || '').toLowerCase() || (port === 465 ? 'ssl' : port === 587 ? 'starttls' : 'none');
  const user = String(cfg?.user || '');
  const pass = String(cfg?.pass || '');
  const t0 = Date.now();

  let socket = await connect(host, port, mode === 'ssl');
  let ch = makeChannel(socket);

  try {
    let greet = await readReply(ch);
    if (greet.code !== 220) throw new Error(`SMTP 拒绝连接：${greet.code} ${greet.text.slice(0, 160)}`);

    const helo = `EHLO ${host.split('.')[0] || 'localhost'}`;
    ch.socket.write(helo + '\r\n');
    let ehlo = await readReply(ch);
    if (ehlo.code !== 250) {
      // 有些老服务器只认 HELO
      await cmd(ch, 'HELO napcat-alert');
    }

    if (mode === 'starttls') {
      await cmd(ch, 'STARTTLS', [220]);
      socket.removeAllListeners('data');
      await new Promise((resolve, reject) => {
        const upgraded = tls.connect({ socket, servername: host }, () => resolve(upgraded));
        upgraded.once('error', reject);
        // eslint-disable-next-line no-param-reassign
        socket = upgraded;
      });
      ch = makeChannel(socket);
      ch.socket.write(helo + '\r\n');
      await readReply(ch);
    }

    if (user) {
      ch.socket.write('AUTH LOGIN\r\n');
      let r = await readReply(ch);
      if (r.code !== 334) throw new Error(`AUTH LOGIN 被拒：${r.code} ${r.text.slice(0, 160)}`);
      await cmd(ch, Buffer.from(user, 'utf8').toString('base64'), [334]);
      await cmd(ch, Buffer.from(pass, 'utf8').toString('base64'), [235]);
    }

    const from = String(mail.from || user || '').trim();
    if (!from) throw new Error('未配置发信地址');
    await cmd(ch, `MAIL FROM:<${from}>`, [250]);

    const toList = (Array.isArray(mail.to) ? mail.to : String(mail.to || '').split(/[,;，；\s]+/))
      .map((x) => String(x).trim()).filter(Boolean);
    if (!toList.length) throw new Error('未配置收件地址');
    for (const addr of toList) {
      await cmd(ch, `RCPT TO:<${addr}>`, [250, 251]);
    }

    await cmd(ch, 'DATA', [354]);
    const message = buildMessage({
      from,
      to: toList,
      subject: mail.subject,
      text: mail.text,
      html: mail.html,
      attachments: mail.attachments,
      inline: mail.inline
    });
    // 行首的点要转义，否则会被当成 DATA 结束符
    const stuffed = message.split('\r\n').map((l) => (l.startsWith('.') ? '.' + l : l)).join('\r\n');
    ch.socket.write(`${stuffed}\r\n.\r\n`);
    const done = await readReply(ch);
    if (done.code !== 250) throw new Error(`投递失败：${done.code} ${done.text.slice(0, 200)}`);

    try { ch.socket.write('QUIT\r\n'); } catch { /* 已经投递成功，QUIT 失败不算错 */ }

    return { ms: Date.now() - t0, server: done.text.slice(0, 120) };
  } finally {
    try { socket.destroy(); } catch { /* ignore */ }
  }
}
