// ══════════════════════════════════════════════════════════════
//  napcat-alert · NapCat / QQ 掉线邮件告警
// ══════════════════════════════════════════════════════════════
//
//  背景：NapCat 被风控踢下线后，进程还在、WS 端口还在监听，
//  只有 get_status 里的 online 会变 false。等用户自己发现往往已经过去半天。
//  掉线时**机器人自己发不出消息**，所以告警必须走站外——邮件是最可靠的，
//  而且邮件里直接带二维码，手机上点开就能扫。
//
//  与旧版 bash 脚本（/usr/local/bin/napcat-watch.sh + systemd timer）的区别：
//    · 状态、日志、配置都在控制台里，不用 ssh 改文件；
//    · 复用内核已有的 OneBot 连接，不再单独发 HTTP 请求、不重复读 token；
//    · 邮件模板、二维码路径、探测间隔都能在面板上改，改完下一轮生效；
//    · 掉线与恢复各发一封，中间不重复轰炸（按 offlineSince 去重）。
//
//  行为约定：
//    ① 连续 failThreshold 次探测失败才判离线（默认 2），过滤网络抖动；
//    ② online 字段缺失（null）不改判，只记录错误；
//    ③ 掉线只发一次，直到恢复；恢复时发一封说明离线时长；
//    ④ 没配 SMTP 时不报错刷屏，只在历史里留一条「未配置」。
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import QRCode from 'qrcode';
import { sendMail } from './smtp.js';
import { sharpenQr } from './qr-png.js';

const QR_CANDIDATES = [
  '/opt/QQ/resources/app/app_launcher/napcat/cache/qrcode.png',
  '/root/.config/QQ/NapCat/cache/qrcode.png',
  '/root/.config/QQ/NapCat/cache/qrcode.jpg',
  '/opt/QQ/resources/app/app_launcher/napcat/cache/qrcode.jpg'
];

// NapCat 的 WebUI 配置（token 在这里），用来主动刷新二维码。
const WEBUI_CANDIDATES = [
  '/opt/QQ/resources/app/app_launcher/napcat/config/webui.json',
  '/root/.config/QQ/NapCat/config/webui.json'
];

const MAX_HISTORY = 40;

// 二维码出图参数：720px、静区 4 个模块、纠错 M。
// 之前是 480px + margin 1 —— 手机上截图再扫经常不认，静区不够是主因。
const QR_OPTS = { type: 'png', margin: 4, width: 720, errorCorrectionLevel: 'M' };

// 邮件正文里内嵌二维码用的 Content-ID
const QR_CID = 'qrcode@napcat-alert';

function nowText(ts = Date.now()) {
  return new Date(ts).toLocaleString('zh-CN', { hour12: false });
}

function fmtDuration(ms) {
  const min = Math.max(0, Math.round(ms / 60000));
  if (min < 60) return `${min} 分钟`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  return m ? `${h} 小时 ${m} 分钟` : `${h} 小时`;
}

function maskPass(pass) {
  const s = String(pass || '');
  if (!s) return '';
  if (s.length <= 4) return '****';
  return `${s.slice(0, 2)}****${s.slice(-2)}`;
}

function escHtml(s) {
  return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

/**
 * 邮件正文的 HTML 版：把纯文本原样搬过来，再插一张 320px 的二维码大图。
 *
 * 为什么非要有 HTML 版：只把二维码塞成附件时，手机端要先点开附件、再截屏，
 * 缩略图小得扫不出来。正文里内嵌（cid）就不一样了——邮件一打开就是一张
 * 大图，另一台设备直接对着屏幕扫。
 * 注意：这张码（txz.qq.com/p?k=...）只能「用摄像头扫」触发登录确认，
 * 不能点开链接、也不能长按识别图片（QQ 会拒绝，点开只会跳下载页）。
 */
function buildMailHtml({ text, qrUrl = '', hasQr = false }) {
  const body = String(text || '')
    .split('\n')
    .map((line) => (line.trim()
      ? `<div style="min-height:6px">${escHtml(line)}</div>`
      : '<div style="height:8px"></div>'))
    .join('');

  const qrBlock = hasQr
    ? `
  <div style="text-align:center;margin:22px 0 6px">
    <img src="cid:${QR_CID}" width="320" alt="登录二维码"
         style="width:320px;height:auto;max-width:92%;border:6px solid #fff;background:#fff;image-rendering:pixelated">
    <div style="font-size:12px;color:#888;margin-top:8px">用<b>另一台设备</b>的 QQ 扫这张码（约 2 分钟内有效）</div>
  </div>`
    : '';

  // 登录链接（txz.qq.com/p?k=...）只能「扫码触发」，不能点开——点开只会跳到 QQ 下载页。
  // 所以这里不提供可点的 <a>，只把链接作为「用其它设备扫时照着输」的备选，避免误导。
  const linkBlock = qrUrl
    ? `
  <div style="margin-top:16px;padding:10px 12px;background:#f6f8fa;border-radius:8px;font-size:13px;color:#444">
    本机没有第二台设备？把下面这串登录码复制到<b>手机 QQ 的「扫一扫」里手动输入</b>，或让同事用他的 QQ 扫你屏幕上的码：<br>
    <span style="color:#1a73e8;word-break:break-all;font-family:ui-monospace,monospace">${escHtml(qrUrl)}</span>
  </div>`
    : '';

  return `<div style="font:14px/1.75 -apple-system,'PingFang SC','Microsoft YaHei',Arial,sans-serif;color:#222;max-width:660px">
${body}${qrBlock}${linkBlock}
</div>`;
}

/** 读 NapCat WebUI 的监听地址与 token（token 用来换 Credential）。 */
function readWebuiCfg() {
  for (const file of WEBUI_CANDIDATES) {
    try {
      const c = JSON.parse(fs.readFileSync(file, 'utf8'));
      if (!c?.token) continue;
      const host = (!c.host || c.host === '::' || c.host === '0.0.0.0') ? '127.0.0.1' : c.host;
      return { token: String(c.token), base: `http://${host}:${Number(c.port) || 6099}` };
    } catch { /* 换个路径再试 */ }
  }
  return null;
}

/**
 * 调 NapCat 的 /api/QQLogin/<ep>。
 * 鉴权两步：sha256(token + '.napcat') 换 Credential，再用 Bearer 调业务接口。
 * 注意 NapCat 鉴权失败也返回 HTTP 200 + {code:-1,...}，所以要看 body.code 而不是 status。
 */
async function napcatCall(ep, body = {}) {
  const cfg = readWebuiCfg();
  if (!cfg) throw new Error('找不到 NapCat 的 webui.json（无法刷新二维码）');
  const hash = crypto.createHash('sha256').update(cfg.token + '.napcat').digest('hex');
  const loginRes = await fetch(`${cfg.base}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ hash }),
    signal: AbortSignal.timeout(10000)
  });
  const loginData = await loginRes.json().catch(() => ({}));
  const cred = loginData?.data?.Credential;
  if (!cred) throw new Error('NapCat WebUI 鉴权失败');

  const res = await fetch(`${cfg.base}/api/QQLogin/${ep}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + cred },
    body: JSON.stringify(body || {}),
    signal: AbortSignal.timeout(20000)
  });
  const data = await res.json().catch(() => ({}));
  if (typeof data?.code === 'number' && data.code !== 0) {
    throw new Error(`NapCat ${ep} 返回 code=${data.code}：${data.message || ''}`);
  }
  return data?.data ?? null;
}

export async function activate(ctx) {
  const log = (...a) => { try { ctx.log(...a); } catch { /* 日志失败不影响告警 */ } };
  const readCfg = () => {
    const c = ctx.config.get() || {};
    return {
      enabled: c.enabled !== false,
      intervalSec: Math.max(30, Number(c.intervalSec) || 120),
      failThreshold: Math.max(1, Number(c.failThreshold) || 2),
      smtp: c.smtp || {},
      attachQr: c.attachQr !== false,
      qrPath: String(c.qrPath || '').trim(),
      qrMaxAgeMin: Math.max(1, Number(c.qrMaxAgeMin) || 3),
      notifyRecovery: c.notifyRecovery !== false,
      webhook: c.webhook || {}
    };
  };

  // ── 状态 ───────────────────────────────────────────────────
  const state = {
    online: null,
    checkedAt: 0,
    lastOnlineAt: 0,
    offlineSince: 0,
    failStreak: 0,
    lastError: '',
    probes: 0,
    mails: 0,
    mailFailures: 0,
    lastMailAt: 0,
    lastMailError: '',
    lastAlertFor: 0,      // 本次离线已告警的 offlineSince（去重）
    alerted: false
  };
  let history = [];

  const stateFile = ctx.data.file('state.json');
  try {
    const saved = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
    if (saved && typeof saved === 'object') {
      for (const k of ['probes', 'mails', 'mailFailures', 'lastMailAt', 'lastMailError']) {
        if (saved[k] !== undefined) state[k] = saved[k];
      }
      if (Array.isArray(saved.history)) history = saved.history.slice(0, MAX_HISTORY);
    }
  } catch { /* 首次运行没有存档 */ }

  const persist = () => {
    try {
      fs.writeFileSync(stateFile, JSON.stringify({
        probes: state.probes,
        mails: state.mails,
        mailFailures: state.mailFailures,
        lastMailAt: state.lastMailAt,
        lastMailError: state.lastMailError,
        history
      }, null, 1));
    } catch (e) {
      log('状态落盘失败：', e?.message ?? e);
    }
  };

  const note = (entry) => {
    history.unshift({ ts: Date.now(), ...entry });
    if (history.length > MAX_HISTORY) history.length = MAX_HISTORY;
    persist();
  };

  // ── 二维码定位 ─────────────────────────────────────────────
  const findQr = () => {
    const c = readCfg();
    const list = [c.qrPath, ...QR_CANDIDATES].filter(Boolean);
    for (const p of list) {
      try {
        const st = fs.statSync(p);
        if (st.isFile() && st.size > 0) {
          return { path: p, mtime: st.mtimeMs, size: st.size, ageMin: (Date.now() - st.mtimeMs) / 60000 };
        }
      } catch { /* 不存在就试下一个 */ }
    }
    return null;
  };

  /** 出图统一走这里：小图放大 + 补静区；已经合格就原样返回。 */
  const polishQr = (buf) => {
    try {
      return sharpenQr(buf, { target: 720, quiet: 4 });
    } catch (e) {
      log('二维码放大失败，按原图发送：' + (e?.message ?? e));
      return { buffer: buf, width: 0, height: 0, module: 0, scale: 1, changed: false };
    }
  };

  /** 一张 PNG 的两种挂法：附件（可保存原图）+ 正文内嵌（cid）。 */
  const packQr = (buffer, extra = {}) => {
    const png = { filename: 'qrcode.png', contentType: 'image/png', content: buffer };
    return { attachments: [png], inline: [{ ...png, cid: QR_CID }], ...extra };
  };

  const qrAttachment = () => {
    const c = readCfg();
    if (!c.attachQr) return { attachments: [], inline: [], note: '（配置为不附带二维码）' };
    const qr = findQr();
    if (!qr) return { attachments: [], inline: [], note: '（没找到二维码文件，请到控制台或 NapCat 面板扫码）' };
    if (qr.ageMin > c.qrMaxAgeMin) {
      return {
        attachments: [],
        inline: [],
        note: '（二维码刷新失败，附件未附带——请打开控制台 → 插件 → 掉线告警，那里能看到最新二维码并补发邮件）'
      };
    }
    try {
      const fixed = polishQr(fs.readFileSync(qr.path));
      const size = fixed.width ? `${fixed.width}×${fixed.height}` : '原始尺寸';
      return {
        ...packQr(fixed.buffer),
        size,
        upscaled: fixed.changed,
        note: `（二维码见正文和附件（${size}）：${Math.round(qr.ageMin)} 分钟前更新，可能已过期）`
      };
    } catch (e) {
      return { attachments: [], inline: [], note: `（读取二维码失败：${e?.message ?? e}）` };
    }
  };

  /**
   * 实时二维码：直接问 NapCat 要当前登录会话的 qrcodeurl，在本地渲染成 PNG。
   *
   * 为什么不再信 cache/qrcode.png：那是 NapCat 自己的自动刷新循环写的。
   * 账号掉线后这个循环经常已经停了（2026-09-16 出过同样的事故），
   * 文件可能停在几小时前 —— 附到邮件里，扫上去必然提示「二维码已过期」。
   * qrcodeurl 是活的：只要还在等扫码，它就是当前有效的那张。
   */
  const liveQrPng = async () => {
    try {
      await napcatCall('RefreshQRcode');
    } catch (e) {
      // 已登录时会返回 "QQ Is Logined"，属正常，继续取当前会话的码
      log('刷新二维码被拒（可能已登录）：' + (e?.message ?? e));
    }
    const st = await napcatCall('CheckLoginStatus');
    const url = String(st?.qrcodeurl || '').trim();
    if (!url) return null;
    const png = await QRCode.toBuffer(url, QR_OPTS);
    return { buffer: png, url };
  };

  /** 发信时优先用实时生成的码；拿不到才退回缓存文件。 */
  const mailQr = async () => {
    const c = readCfg();
    if (!c.attachQr) return { attachments: [], inline: [], note: '（配置为不附带二维码）' };
    try {
      const live = await liveQrPng();
      if (live) {
        return {
          ...packQr(live.buffer, { url: live.url }),
          size: '720×720',
          upscaled: false,
          note: '（二维码是按当前登录会话实时生成的，约 2 分钟内有效；过期后到面板点「补发二维码邮件」即可）'
        };
      }
    } catch (e) {
      log('实时生成二维码失败，退回缓存文件：' + (e?.message ?? e));
    }
    return qrAttachment();
  };

  // ── 发信 ───────────────────────────────────────────────────
  const sendAlert = async (kind, payload = {}) => {
    const c = readCfg();
    const smtp = c.smtp || {};
    if (!String(smtp.host || '').trim()) {
      note({ kind, ok: false, detail: '未配置 SMTP，跳过发信' });
      return { ok: false, error: '未配置 SMTP 服务器' };
    }
    if (!String(smtp.user || '').trim()) {
      note({ kind, ok: false, detail: '未配置发信账号，跳过发信' });
      return { ok: false, error: '未配置发信账号' };
    }

    const host = os.hostname();
    let subject;
    let text;
    let attachments = [];
    let inline = [];
    let qrUrl = '';

    if (kind === 'offline') {
      const since = payload.since || state.offlineSince || Date.now();
      // 先拿实时二维码，避免附上一张已经过期的图
      const qr = await mailQr();
      attachments = qr.attachments;
      inline = qr.inline || [];
      qrUrl = qr.url || '';
      const prefix = payload.test ? '【测试】' : '';
      subject = `${prefix}【NapCat】机器人掉线，需扫码重新登录`;
      text = [
        `${prefix}NapCat 掉线了（${nowText(since)}）！`,
        '',
        '机器人的 QQ 登录态已失效，需要扫码重新登录。',
        `服务器：${host}`,
        `探测结果：连续 ${payload.fails ?? state.failStreak} 次失败${state.lastError ? `（${state.lastError}）` : ''}`,
        '',
        '处理方式（任选其一）：',
        '  1. 用另一台设备的手机 QQ 扫本邮件正文里的二维码（附件里也有一份同图，可传到别的设备扫）；',
        '  2. 只有一台设备：把正文里的登录码复制到手机 QQ「扫一扫」手动输入；',
        '  3. 打开控制台 → 插件 → 掉线告警 → 「补发二维码」，或直接看面板上的二维码（用别的设备扫）；',
        '  4. 手机 QQ → 登录设备管理，确认服务器设备后重试。',
        '',
        '注意：这张码只能「用摄像头扫」，不能在本机点开链接、也不能长按识别图片——QQ 会拒绝这两种授权方式。',
        '',
        qr.note,
        '',
        `—— 由 qq-agent 的「掉线告警」插件发出 · ${nowText()}`
      ].join('\n');
    } else if (kind === 'recovered') {
      const since = payload.since || 0;
      const dur = since ? fmtDuration(Date.now() - since) : '未知时长';
      subject = `【NapCat】机器人已恢复上线`;
      text = [
        `NapCat 已恢复上线（${nowText()}）。`,
        since ? `本次离线约 ${dur}（${nowText(since)} 起）。` : '',
        `服务器：${host}`,
        '',
        `—— 由 qq-agent 的「掉线告警」插件发出 · ${nowText()}`
      ].filter(Boolean).join('\n');
    } else {
      subject = '【测试】掉线告警通道自检';
      text = [
        '这是一封测试邮件，说明掉线告警通道是通的。',
        '',
        `服务器：${host}`,
        `发信时间：${nowText()}`,
        `探测间隔：${c.intervalSec} 秒`,
        '真正掉线时，这封信会变成「掉线，需扫码重新登录」，并附带二维码。',
        '',
        `—— 由 qq-agent 的「掉线告警」插件发出 · ${nowText()}`
      ].join('\n');
    }

    try {
      const r = await sendMail(smtp, {
        from: smtp.from || smtp.user,
        to: smtp.to || smtp.user,
        subject,
        text,
        html: buildMailHtml({ text, qrUrl, hasQr: inline.length > 0 }),
        attachments,
        inline
      });
      state.mails += 1;
      state.lastMailAt = Date.now();
      state.lastMailError = '';
      note({ kind, ok: true, detail: `${subject} · ${r.ms}ms${attachments.length ? ' · 含二维码（正文内嵌+附件）' : ''}` });
      log(`已发出 ${kind} 邮件（${r.ms}ms）`);
      persist();
      return { ok: true, ms: r.ms };
    } catch (e) {
      state.mailFailures += 1;
      state.lastMailError = String(e?.message ?? e);
      note({ kind, ok: false, detail: state.lastMailError.slice(0, 200) });
      log(`发信失败：${state.lastMailError}`);
      persist();
      return { ok: false, error: state.lastMailError };
    }
  };

  // ── Webhook（可选）─────────────────────────────────────────
  const notifyWebhook = async (kind, payload = {}) => {
    const c = readCfg();
    const url = String(c.webhook?.url || '').trim();
    if (!url) return;
    const type = String(c.webhook?.type || 'wecom').toLowerCase();
    const text = kind === 'offline'
      ? `【NapCat】机器人掉线（${nowText(payload.since || Date.now())}），服务器 ${os.hostname()}，请扫码重登`
      : kind === 'recovered'
        ? `【NapCat】机器人已恢复上线（${nowText()}）`
        : '【测试】掉线告警 webhook 自检';
    const body = type === 'feishu'
      ? { msg_type: 'text', content: { text } }
      : type === 'dingtalk'
        ? { msgtype: 'text', text: { content: text } }
        : { msgtype: 'text', text: { content: text } };
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(10000)
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
    } catch (e) {
      note({ kind: `${kind}-webhook`, ok: false, detail: String(e?.message ?? e).slice(0, 160) });
    }
  };

  // ── 探测 ───────────────────────────────────────────────────
  let probing = false;

  async function probe(opts = {}) {
    const c = readCfg();
    if (probing && !opts.force) return { ok: false, error: '上一次探测还没结束' };
    probing = true;
    state.probes += 1;

    let online = null;
    let error = '';
    try {
      if (!ctx.onebot || typeof ctx.onebot.call !== 'function') {
        throw new Error('OneBot 客户端未就绪');
      }
      const r = await ctx.onebot.call('get_status', {}, 15000);
      // OneBotClient.call() 已经把 body.data 解包，r 直接就是 { online, good, stat }
      if (r && typeof r.online === 'boolean') online = r.online;
    } catch (e) {
      error = String(e?.message ?? e);
    }
    probing = false;

    state.checkedAt = Date.now();
    state.lastError = error;

    if (online === true) {
      const wasOffline = state.online === false;
      const since = state.offlineSince;
      state.online = true;
      state.lastOnlineAt = Date.now();
      state.offlineSince = 0;
      state.failStreak = 0;
      state.alerted = false;
      if (wasOffline && c.notifyRecovery) {
        await sendAlert('recovered', { since });
        await notifyWebhook('recovered', { since });
      }
      persist();
      return { ok: true, state: snapshot() };
    }

    if (online === false || error) {
      state.failStreak += 1;
      if (state.failStreak >= c.failThreshold) {
        const firstJudgement = state.online !== false;
        state.online = false;
        if (!state.offlineSince) state.offlineSince = Date.now();
        if (firstJudgement || (!state.alerted && state.lastAlertFor !== state.offlineSince)) {
          state.lastAlertFor = state.offlineSince;
          state.alerted = true;
          log(`判定离线（连续 ${state.failStreak} 次失败${error ? '：' + error : ''}），发告警`);
          await sendAlert('offline', { since: state.offlineSince, fails: state.failStreak });
          await notifyWebhook('offline', { since: state.offlineSince });
        }
      }
      persist();
      return { ok: true, state: snapshot() };
    }

    persist();
    return { ok: true, state: snapshot() };
  }

  function snapshot() {
    return {
      online: state.online,
      checkedAt: state.checkedAt,
      lastOnlineAt: state.lastOnlineAt,
      offlineSince: state.offlineSince,
      offlineMs: state.offlineSince ? Date.now() - state.offlineSince : 0,
      failStreak: state.failStreak,
      lastError: state.lastError,
      probes: state.probes,
      mails: state.mails,
      mailFailures: state.mailFailures,
      lastMailAt: state.lastMailAt,
      lastMailError: state.lastMailError
    };
  }

  // ── 定时循环 ───────────────────────────────────────────────
  let lastProbeAt = 0;
  const stopTimer = ctx.scheduler.every(15000, async () => {
    const c = readCfg();
    if (!c.enabled) return;
    if (Date.now() - lastProbeAt < c.intervalSec * 1000) return;
    lastProbeAt = Date.now();
    await probe();
  });

  // 启动后先等 40 秒：NapCat 重连、登录态同步都需要时间，
  // 立刻探测会把「正在连接」误判成掉线，白发一封邮件。
  const bootTimer = setTimeout(() => {
    lastProbeAt = Date.now();
    probe().catch((e) => log('首次探测失败：', e?.message ?? e));
  }, 40000);
  if (typeof bootTimer.unref === 'function') bootTimer.unref();

  // ── HTTP 接口 ──────────────────────────────────────────────
  ctx.http.route('GET', '/status', async () => {
    const c = readCfg();
    const smtp = c.smtp || {};
    const qr = findQr();
    return {
      ok: true,
      state: snapshot(),
      config: {
        enabled: c.enabled,
        intervalSec: c.intervalSec,
        failThreshold: c.failThreshold,
        attachQr: c.attachQr,
        qrPath: c.qrPath,
        qrMaxAgeMin: c.qrMaxAgeMin,
        notifyRecovery: c.notifyRecovery,
        smtp: {
          host: smtp.host || '',
          port: smtp.port || 465,
          tls: smtp.tls || 'ssl',
          user: smtp.user || '',
          passMasked: maskPass(smtp.pass),
          hasPass: Boolean(smtp.pass),
          from: smtp.from || '',
          to: smtp.to || ''
        },
        webhook: { url: c.webhook?.url ? '(已配置)' : '', type: c.webhook?.type || 'wecom' }
      },
      qr: qr ? { path: qr.path, mtime: qr.mtime, ageMin: Math.round(qr.ageMin), size: qr.size } : null,
      history
    };
  });

  ctx.http.route('GET', '/qr', async () => {
    // 掉线（或还没探测出状态）时面板也优先给实时码：用户多半就是在这里点「补发」的
    if (state.online !== true) {
      try {
        const live = await liveQrPng();
        if (live) {
          return {
            ok: true,
            source: 'live',
            mtime: Date.now(),
            ageMin: 0,
            url: live.url,
            width: 720,
            height: 720,
            upscaled: false,
            dataUrl: `data:image/png;base64,${live.buffer.toString('base64')}`
          };
        }
      } catch (e) {
        log('面板实时取码失败，退回文件：' + (e?.message ?? e));
      }
    }
    const qr = findQr();
    if (!qr) return { ok: false, error: '没有找到二维码文件' };
    try {
      const fixed = polishQr(fs.readFileSync(qr.path));
      return {
        ok: true,
        source: 'file',
        mtime: qr.mtime,
        ageMin: Math.round(qr.ageMin),
        width: fixed.width,
        height: fixed.height,
        upscaled: fixed.changed,
        dataUrl: `data:image/png;base64,${fixed.buffer.toString('base64')}`
      };
    } catch (e) {
      return { ok: false, error: String(e?.message ?? e) };
    }
  });

  ctx.http.route('POST', '/probe', async () => {
    const r = await probe({ force: true });
    return { ok: true, ...r, state: snapshot() };
  });

  ctx.http.route('POST', '/test', async () => {
    const r = await sendAlert('test');
    await notifyWebhook('test');
    return { ok: r.ok, error: r.error, ms: r.ms, history: history.slice(0, 5) };
  });

  ctx.http.route('POST', '/resend-qr', async () => {
    const r = await sendAlert('offline', { since: state.offlineSince || Date.now(), fails: state.failStreak, test: true });
    return { ok: r.ok, error: r.error, ms: r.ms };
  });

  ctx.http.route('POST', '/clear', async () => {
    history = [];
    persist();
    return { ok: true };
  });

  log('已启用：每', readCfg().intervalSec, '秒探测一次 OneBot 在线状态');

  return {
    dispose() {
      stopTimer?.();
      clearTimeout(bootTimer);
    }
  };
}
