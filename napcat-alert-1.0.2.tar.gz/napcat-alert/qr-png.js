// ══════════════════════════════════════════════════════════════
//  qr-png · 把二维码 PNG 变成「截屏也能扫」的尺寸
// ══════════════════════════════════════════════════════════════
//
//  为什么要这个文件：
//    NapCat 自己缓存的 cache/qrcode.png 是 147×147、1 位灰度的小图，
//    在手机邮件里点开只有拇指盖那么大 —— 截图上再扫，识别率极低。
//    我们又不方便为了「放大一张图」引进 sharp / jimp 这种几十 MB 的依赖。
//
//  所以这里手写了 PNG 的「读 → 放大 → 写」最小闭环（只用 node:zlib）：
//    · 只认二维码会用到的几种格式：灰度（0）、调色板（3）、RGB/RGBA（2/6），
//      位深 1/2/4/8，不认隔行扫描（NapCat 不产出）；
//    · 放大用「整块复制」而不是插值 —— 插值会把黑边糊成灰，越放大越扫不出；
//    · 顺手补够 4 个模块的静区（QR 规范要求），并保证每个模块是整数像素，
//      这样手机截图、微信/QQ 从相册识别都稳。
//
//  对外只有一个函数：sharpenQr(buf) → { buffer, width, height, module, scale, changed }
//  任何一步不认识就原样返回（changed:false），绝不把好图搞坏。

import zlib from 'node:zlib';

const PNG_SIG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

// ── CRC32（PNG 每个 chunk 都要）─────────────────────────────
let CRC_TABLE = null;
function crc32(buf) {
  if (!CRC_TABLE) {
    CRC_TABLE = new Int32Array(256);
    for (let n = 0; n < 256; n += 1) {
      let c = n;
      for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      CRC_TABLE[n] = c;
    }
  }
  let c = -1;
  for (let i = 0; i < buf.length; i += 1) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}

function chunk(type, data) {
  const out = Buffer.alloc(12 + data.length);
  out.writeUInt32BE(data.length, 0);
  out.write(type, 4, 'ascii');
  data.copy(out, 8);
  out.writeUInt32BE(crc32(out.subarray(4, 8 + data.length)), 8 + data.length);
  return out;
}

const CHANNELS = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 };

/** 读 PNG：返回 { width, height, gray } —— gray 每像素 0(黑)~255(白)。 */
function readGrayscale(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 33 || !buf.subarray(0, 8).equals(PNG_SIG)) {
    throw new Error('不是 PNG 文件');
  }
  let off = 8;
  let width = 0;
  let height = 0;
  let bitDepth = 0;
  let colorType = -1;
  let interlace = 0;
  let palette = null;
  const idat = [];

  while (off + 8 <= buf.length) {
    const len = buf.readUInt32BE(off);
    const type = buf.toString('ascii', off + 4, off + 8);
    const data = buf.subarray(off + 8, off + 8 + len);
    if (type === 'IHDR') {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      bitDepth = data[8];
      colorType = data[9];
      interlace = data[12];
    } else if (type === 'PLTE') {
      palette = Buffer.from(data);
    } else if (type === 'IDAT') {
      idat.push(Buffer.from(data));
    } else if (type === 'IEND') {
      break;
    }
    off += len + 12;
  }

  const channels = CHANNELS[colorType];
  if (!width || !height || !channels) throw new Error('PNG 头不完整');
  if (interlace !== 0) throw new Error('不支持隔行扫描的 PNG');
  if (![1, 2, 4, 8].includes(bitDepth)) throw new Error(`不支持的位深 ${bitDepth}`);

  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = Math.ceil((width * channels * bitDepth) / 8);
  const bpp = Math.max(1, Math.ceil((channels * bitDepth) / 8));
  if (raw.length < height * (stride + 1)) throw new Error('PNG 数据不完整');

  // ── 反滤波（PNG 规定的 5 种行滤波）─────────────────────
  const img = Buffer.alloc(stride * height);
  let prev = Buffer.alloc(stride);
  for (let y = 0; y < height; y += 1) {
    const filter = raw[y * (stride + 1)];
    const line = raw.subarray(y * (stride + 1) + 1, y * (stride + 1) + 1 + stride);
    const cur = Buffer.from(line);
    for (let i = 0; i < stride; i += 1) {
      const a = i >= bpp ? cur[i - bpp] : 0;
      const b = prev[i];
      const c = i >= bpp ? prev[i - bpp] : 0;
      switch (filter) {
        case 0: break;
        case 1: cur[i] = (cur[i] + a) & 0xff; break;
        case 2: cur[i] = (cur[i] + b) & 0xff; break;
        case 3: cur[i] = (cur[i] + ((a + b) >> 1)) & 0xff; break;
        case 4: {
          const p = a + b - c;
          const pa = Math.abs(p - a);
          const pb = Math.abs(p - b);
          const pc = Math.abs(p - c);
          const pred = pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
          cur[i] = (cur[i] + pred) & 0xff;
          break;
        }
        default: throw new Error(`未知滤波类型 ${filter}`);
      }
    }
    cur.copy(img, y * stride);
    prev = cur;
  }

  // ── 取亮度 ────────────────────────────────────────────
  const gray = new Uint8Array(width * height);
  const maxV = (1 << bitDepth) - 1;
  const sampleAt = (base, idx) => {
    if (bitDepth === 8) return img[base + idx];
    const bitPos = idx * bitDepth;
    const byte = img[base + (bitPos >> 3)];
    const shift = 8 - bitDepth - (bitPos & 7);
    return (byte >> shift) & maxV;
  };

  for (let y = 0; y < height; y += 1) {
    const base = y * stride;
    for (let x = 0; x < width; x += 1) {
      let v;
      if (colorType === 3) {
        const idx = sampleAt(base, x);
        const p = palette && palette.length >= (idx + 1) * 3 ? idx * 3 : 0;
        const r = palette ? palette[p] : 0;
        const g = palette ? palette[p + 1] : 0;
        const b = palette ? palette[p + 2] : 0;
        v = 0.299 * r + 0.587 * g + 0.114 * b;
      } else if (colorType === 2 || colorType === 6) {
        const step = channels;
        const r = sampleAt(base, x * step);
        const g = sampleAt(base, x * step + 1);
        const b = sampleAt(base, x * step + 2);
        v = 0.299 * r + 0.587 * g + 0.114 * b;
      } else {
        v = (sampleAt(base, x) * 255) / maxV;
      }
      gray[y * width + x] = Math.round(v);
    }
  }
  return { width, height, gray };
}

/** 写一张 1 位灰度 PNG（0=黑，255=白）。 */
function writeGrayscale1(bitmap, size) {
  const rowBytes = Math.ceil(size / 8);
  const stride = rowBytes + 1;
  const raw = Buffer.alloc(stride * size);
  for (let y = 0; y < size; y += 1) {
    raw[y * stride] = 0; // 滤波类型：none
    for (let x = 0; x < size; x += 1) {
      if (bitmap[y * size + x]) {
        raw[y * stride + 1 + (x >> 3)] |= 0x80 >> (x & 7); // 1 = 白
      }
    }
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 1;  // bitDepth
  ihdr[9] = 0;  // colorType: 灰度
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;
  return Buffer.concat([
    PNG_SIG,
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0))
  ]);
}

/**
 * 把二维码 PNG 修成「能扫」的样子。
 * @param {Buffer} buf 原始 PNG
 * @param {{target?:number, quiet?:number}} opts target=目标边长(px)，quiet=静区模块数
 * @returns {{buffer:Buffer,width:number,height:number,module:number,scale:number,changed:boolean}}
 */
export function sharpenQr(buf, { target = 720, quiet = 4 } = {}) {
  const original = { buffer: buf, width: 0, height: 0, module: 0, scale: 1, changed: false };
  let img;
  try {
    img = readGrayscale(buf);
  } catch {
    return original;
  }
  const { width, height, gray } = img;
  original.width = width;
  original.height = height;

  // 暗像素的包围盒 = 二维码实体（含原本可能不足的静区）
  let x0 = width;
  let y0 = height;
  let x1 = -1;
  let y1 = -1;
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      if (gray[y * width + x] < 128) {
        if (x < x0) x0 = x;
        if (y < y0) y0 = y;
        if (x > x1) x1 = x;
        if (y > y1) y1 = y;
      }
    }
  }
  if (x1 < 0) return original;              // 全白：不是二维码
  const boxW = x1 - x0 + 1;
  const boxH = y1 - y0 + 1;
  if (boxW < 21 || boxH < 21) return original; // 比 21×21（版本 1）还小，肯定不对

  // 估模块大小：把每一行里连续黑像素的段长做成直方图，
  // 出现最多的那个长度就是 1 个模块（二维码数据区里单模块段最常见）。
  // 比「只看左上角定位符顶边」稳：定位符被裁掉、加了 logo 的图也不会估飞。
  const hist = new Map();
  for (let y = y0; y <= y1; y += 1) {
    let run = 0;
    for (let x = x0; x <= x1; x += 1) {
      if (gray[y * width + x] < 128) {
        run += 1;
      } else if (run) {
        hist.set(run, (hist.get(run) || 0) + 1);
        run = 0;
      }
    }
    if (run) hist.set(run, (hist.get(run) || 0) + 1);
  }
  let guess = 0;
  let guessCount = 0;
  for (const [len, cnt] of hist) {
    if (cnt > guessCount || (cnt === guessCount && len < guess)) {
      guess = len;
      guessCount = cnt;
    }
  }
  // 最少 21 个模块（版本 1），所以模块不可能大于 边长的 1/21
  const limit = Math.max(1, Math.floor(boxW / 21));
  const module = Math.min(Math.max(1, guess || 1), limit);
  original.module = module;

  // 目标边 = 二维码实体 + 两侧静区（静区按模块算，规范是 4）
  const src = boxW + quiet * module * 2;
  let scale = Math.max(1, Math.ceil(target / src));
  if (scale > 16) scale = 16;               // 防止把 20px 的图吹成 3000px
  const outSize = src * scale;

  // 已经够大、白边也够 → 不动它，省得每次重画
  const quietOk = x0 >= quiet * module && y0 >= quiet * module
    && width - 1 - x1 >= quiet * module && height - 1 - y1 >= quiet * module;
  if (src >= target && quietOk) {
    return { buffer: buf, width, height, module, scale: 1, changed: false };
  }

  const bitmap = new Uint8Array(src * src).fill(1);  // 1 = 白，0 = 黑
  const pad = quiet * module;
  for (let y = 0; y < boxH; y += 1) {
    for (let x = 0; x < boxW; x += 1) {
      if (gray[(y0 + y) * width + (x0 + x)] < 128) {
        bitmap[(y + pad) * src + (x + pad)] = 0;
      }
    }
  }

  // 整块复制（不插值）：每个源像素变成 scale×scale 的方块
  const big = new Uint8Array(outSize * outSize);   // 0 = 黑，正好是默认值
  for (let y = 0; y < src; y += 1) {
    const sy = y * scale;
    for (let x = 0; x < src; x += 1) {
      if (!bitmap[y * src + x]) continue;          // 黑像素保持默认 0
      const sx = x * scale;
      for (let dy = 0; dy < scale; dy += 1) {
        const row = (sy + dy) * outSize;
        big.fill(1, row + sx, row + sx + scale);
      }
    }
  }

  return {
    buffer: writeGrayscale1(big, outSize),
    width: outSize,
    height: outSize,
    module,
    scale,
    box: { width: boxW, height: boxH, x: x0, y: y0 },
    changed: true
  };
}

/** 只报尺寸，不重画（状态接口/测试用）。 */
export function qrInfo(buf) {
  try {
    const img = readGrayscale(buf);
    return { ok: true, width: img.width, height: img.height };
  } catch (e) {
    return { ok: false, error: String(e?.message ?? e) };
  }
}
