// ══════════════════════════════════════════════════════════════
//  napcat-alert · 面板
// ══════════════════════════════════════════════════════════════
//
//  一块面板回答三个问题：
//    ① 现在它认为机器人在线吗？（状态 + 最后探测时间 + 错误原文）
//    ② 邮件通道通不通？（填完点「发测试邮件」，结果直接写在按钮下面）
//    ③ 上次掉线是什么时候？（历史列表，含发信成功/失败与 SMTP 原话）
//
//  密码字段永远回显掩码，只有用户真的改过才写回——避免「打开面板点保存」
//  把授权码洗成 ****。

export async function mountPanel(box, ctx) {
  const { $, api, esc, toast, panelShell, bindPanelClose, savePluginConfig, pluginConfigOf } = ctx;

  let data = null;
  const load = async () => {
    try {
      const r = await api('/api/plugins/napcat-alert/status');
      if (r && r.ok !== false) data = r;
    } catch (e) {
      toast('读取状态失败：' + e.message);
    }
    return data;
  };

  await load();
  const c = data?.config || {};
  const smtp = c.smtp || {};

  const stateBadge = () => {
    const s = data?.state || {};
    if (s.online === true) {
      return `<span style="color:#4a9d5f;font-weight:600">在线</span>`;
    }
    if (s.online === false) {
      return `<span style="color:#d9534f;font-weight:600">离线</span>
        ${s.offlineMs ? `<span class="muted" style="font-size:12px">已 ${Math.round(s.offlineMs / 60000)} 分钟</span>` : ''}`;
    }
    return `<span class="muted">尚未探测</span>`;
  };

  const fmt = (ts) => (ts ? new Date(ts).toLocaleString('zh-CN', { hour12: false }) : '—');

  box.innerHTML = panelShell('napcat-alert', '掉线告警', `
    <p class="muted" style="font-size:13px;margin:0">
      机器人被踢下线时自己发不出消息，所以告警走邮件。掉线发一封（<b>二维码直接印在正文里，320px 大图，用另一台设备扫</b>；
      附件里另有一份原图可保存），恢复再发一封告诉你离线了多久；两次之间不会重复发。
    </p>

    <div style="margin-top:14px;padding:12px;border-radius:8px;background:rgba(128,128,128,.08)">
      <div class="row" style="align-items:center;gap:10px;flex-wrap:wrap">
        <span style="font-size:13px">当前状态：<span id="na-state">${stateBadge()}</span></span>
        <span class="muted" style="font-size:12px" id="na-checked">最后探测：${esc(fmt(data?.state?.checkedAt))}</span>
        <span class="muted" style="font-size:12px" id="na-err">${esc(data?.state?.lastError || '')}</span>
        <span class="spacer" style="flex:1"></span>
        <button class="btn tiny" id="na-probe">立即探测</button>
        <button class="btn tiny" id="na-test">发测试邮件</button>
      </div>
      <div class="muted" style="font-size:12px;margin-top:8px" id="na-tip">
        累计探测 ${Number(data?.state?.probes) || 0} 次 · 发信成功 ${Number(data?.state?.mails) || 0} 次 · 失败 ${Number(data?.state?.mailFailures) || 0} 次
        ${data?.state?.lastMailError ? `· 最近错误：${esc(data.state.lastMailError.slice(0, 120))}` : ''}
      </div>
    </div>

    <div class="row" style="gap:16px;align-items:flex-start;margin-top:16px;flex-wrap:wrap">
      <div style="flex:1;min-width:280px">
        <b style="font-size:13px">SMTP 发信</b>
        <div class="field" style="margin-top:8px">
          <label>服务器 / 端口</label>
          <div class="row" style="gap:6px">
            <input id="na-host" style="flex:1" placeholder="smtp.qq.com" value="${esc(smtp.host || '')}">
            <input id="na-port" style="width:78px" placeholder="465" value="${esc(smtp.port || 465)}">
            <select id="na-tls" style="width:96px">
              <option value="ssl"${(smtp.tls || 'ssl') === 'ssl' ? ' selected' : ''}>SSL</option>
              <option value="starttls"${smtp.tls === 'starttls' ? ' selected' : ''}>STARTTLS</option>
              <option value="none"${smtp.tls === 'none' ? ' selected' : ''}>无加密</option>
            </select>
          </div>
        </div>
        <div class="field" style="margin-top:8px">
          <label>发信账号</label>
          <input id="na-user" style="width:100%" placeholder="xxx@qq.com" value="${esc(smtp.user || '')}">
        </div>
        <div class="field" style="margin-top:8px">
          <label>授权码 <span class="muted" style="font-size:12px">QQ 邮箱是 16 位授权码，不是登录密码${smtp.hasPass ? '；留空 = 不改' : ''}</span></label>
          <input id="na-pass" type="password" style="width:100%" placeholder="${smtp.hasPass ? esc(smtp.passMasked) : '未设置'}">
        </div>
        <div class="field" style="margin-top:8px">
          <label>收件地址 <span class="muted" style="font-size:12px">多个用逗号分隔；留空 = 发给自己</span></label>
          <input id="na-to" style="width:100%" placeholder="xxx@qq.com" value="${esc(smtp.to || '')}">
        </div>
        <div class="field" style="margin-top:8px">
          <label>发信人地址 <span class="muted" style="font-size:12px">留空 = 用发信账号</span></label>
          <input id="na-from" style="width:100%" placeholder="xxx@qq.com" value="${esc(smtp.from || '')}">
        </div>
      </div>

      <div style="flex:0 0 220px">
        <b style="font-size:13px">当前二维码</b>
        <div id="na-qr" style="margin-top:8px;text-align:center">
          <div class="muted" style="font-size:12px">加载中…</div>
        </div>
      </div>
    </div>

    <div style="margin-top:16px;padding-top:14px;border-top:1px solid rgba(128,128,128,.18)">
      <b style="font-size:13px">探测策略</b>
      <div class="row" style="gap:12px;margin-top:8px;flex-wrap:wrap;align-items:flex-end">
        <div class="field" style="margin:0">
          <label>探测间隔（秒）</label>
          <input id="na-interval" style="width:96px" value="${esc(c.intervalSec || 120)}">
        </div>
        <div class="field" style="margin:0">
          <label>连续失败几次算掉线</label>
          <input id="na-threshold" style="width:96px" value="${esc(c.failThreshold || 2)}">
        </div>
        <label class="muted" style="font-size:12px;display:inline-flex;gap:6px;align-items:center">
          <input type="checkbox" id="na-attach" ${c.attachQr !== false ? 'checked' : ''}> 邮件附带二维码
        </label>
        <label class="muted" style="font-size:12px;display:inline-flex;gap:6px;align-items:center">
          <input type="checkbox" id="na-recover" ${c.notifyRecovery !== false ? 'checked' : ''}> 恢复时通知
        </label>
        <label class="muted" style="font-size:12px;display:inline-flex;gap:6px;align-items:center">
          <input type="checkbox" id="na-enabled" ${c.enabled !== false ? 'checked' : ''}> 启用探测
        </label>
      </div>
      <div class="field" style="margin-top:8px">
        <label>二维码文件路径 <span class="muted" style="font-size:12px">留空 = 自动探测 NapCat 默认路径</span></label>
        <input id="na-qrpath" style="width:100%" placeholder="/opt/QQ/.../cache/qrcode.png" value="${esc(c.qrPath || '')}">
      </div>
      <div class="muted" style="font-size:12px;margin-top:6px">
        二维码超过 ${esc(c.qrMaxAgeMin || 3)} 分钟没更新就不附带（避免让你扫到过期码）。
      </div>
    </div>

    <div class="row" style="gap:8px;margin-top:14px;align-items:center">
      <button class="btn" id="na-save">保存配置</button>
      <button class="btn tiny" id="na-resend">补发二维码邮件</button>
      <button class="btn tiny" id="na-refresh">刷新状态</button>
      <span class="muted" style="font-size:12px" id="na-save-tip"></span>
    </div>

    <div style="margin-top:16px;padding-top:14px;border-top:1px solid rgba(128,128,128,.18)">
      <div class="row" style="align-items:center;gap:8px">
        <b style="font-size:13px">最近事件</b>
        <span class="spacer" style="flex:1"></span>
        <button class="btn tiny" id="na-clear">清空</button>
      </div>
      <div id="na-history" style="margin-top:8px"></div>
    </div>
  `);

  bindPanelClose(box);

  // ── 历史渲染 ───────────────────────────────────────────────
  const kindLabel = { offline: '掉线', recovered: '恢复', test: '测试', 'offline-webhook': '掉线-webhook', 'recovered-webhook': '恢复-webhook' };
  const renderHistory = () => {
    const boxEl = $('#na-history');
    if (!boxEl) return;
    const list = Array.isArray(data?.history) ? data.history : [];
    if (!list.length) {
      boxEl.innerHTML = '<div class="muted" style="font-size:12px">还没有记录。点「发测试邮件」可以先验证通道。</div>';
      return;
    }
    boxEl.innerHTML = list.slice(0, 12).map((x) => `
      <div style="font-size:12px;line-height:1.7">
        <span class="muted">${esc(fmt(x.ts))}</span>
        · <b>${esc(kindLabel[x.kind] || x.kind || '')}</b>
        · <span style="color:${x.ok ? '#4a9d5f' : '#d9534f'}">${x.ok ? '成功' : '失败'}</span>
        ${x.detail ? `<span class="muted">· ${esc(String(x.detail).slice(0, 160))}</span>` : ''}
      </div>`).join('');
  };

  // ── 二维码预览 ─────────────────────────────────────────────
  const renderQr = async () => {
    const el = $('#na-qr');
    if (!el) return;
    try {
      const r = await api('/api/plugins/napcat-alert/qr');
      if (r && r.ok && r.dataUrl) {
        const live = r.source === 'live';
        const sizeNote = r.width ? `${r.width}×${r.height}${r.upscaled ? '（已放大）' : ''}` : '';
        el.innerHTML = `<img src="${r.dataUrl}" style="width:240px;height:240px;border-radius:8px;background:#fff;padding:6px;image-rendering:pixelated">
          <div class="muted" style="font-size:12px;margin-top:4px">${live
            ? '实时生成 · 约 2 分钟内有效'
            : `${Math.round(r.ageMin)} 分钟前更新（可能已过期）`}${sizeNote ? ` · ${sizeNote}` : ''}</div>
          <div style="font-size:12px;margin-top:2px">
            <a href="${r.dataUrl}" download="登录二维码.png" style="color:#1a73e8">保存原图</a>
            ${r.url ? ` · <span style="color:#888">登录码：${esc(String(r.url).replace(/^https?:\/\//, ''))}</span>` : ''}
          </div>
          <div class="muted" style="font-size:12px;margin-top:2px">用<b>另一台设备</b>的 QQ 扫这张码；不能在本机点链接或长按识别图片（QQ 会拒绝）</div>`;
      } else {
        el.innerHTML = `<div class="muted" style="font-size:12px">${esc(r?.error || '没有二维码文件')}</div>`;
      }
    } catch (e) {
      el.innerHTML = `<div class="muted" style="font-size:12px">${esc(e.message)}</div>`;
    }
  };

  const refresh = async () => {
    await load();
    const s = data?.state || {};
    const el = $('#na-state');
    if (el) el.innerHTML = stateBadge();
    const ck = $('#na-checked');
    if (ck) ck.textContent = '最后探测：' + fmt(s.checkedAt);
    const er = $('#na-err');
    if (er) er.textContent = s.lastError || '';
    const tip = $('#na-tip');
    if (tip) {
      tip.textContent = `累计探测 ${s.probes || 0} 次 · 发信成功 ${s.mails || 0} 次 · 失败 ${s.mailFailures || 0} 次`
        + (s.lastMailError ? ` · 最近错误：${String(s.lastMailError).slice(0, 120)}` : '');
    }
    renderHistory();
  };

  // ── 事件 ───────────────────────────────────────────────────
  $('#na-probe')?.addEventListener('click', async () => {
    const btn = $('#na-probe');
    btn.disabled = true;
    btn.textContent = '探测中…';
    try {
      const r = await api('/api/plugins/napcat-alert/probe', { method: 'POST', body: {} });
      toast(r?.state?.online === true ? '在线' : r?.state?.online === false ? '离线（已按策略发信）' : '未取到在线状态');
      await refresh();
    } catch (e) {
      toast('探测失败：' + e.message);
    } finally {
      btn.disabled = false;
      btn.textContent = '立即探测';
    }
  });

  $('#na-test')?.addEventListener('click', async () => {
    const btn = $('#na-test');
    const tip = $('#na-tip');
    btn.disabled = true;
    btn.textContent = '发送中…';
    try {
      const r = await api('/api/plugins/napcat-alert/test', { method: 'POST', body: {} });
      if (r?.ok) {
        tip.textContent = `测试邮件已发出（${r.ms}ms）。没收到就查垃圾箱，或看下面的失败原因。`;
      } else {
        tip.textContent = '发送失败：' + (r?.error || '未知原因');
      }
      await refresh();
    } catch (e) {
      tip.textContent = '发送失败：' + e.message;
    } finally {
      btn.disabled = false;
      btn.textContent = '发测试邮件';
    }
  });

  $('#na-resend')?.addEventListener('click', async () => {
    try {
      const r = await api('/api/plugins/napcat-alert/resend-qr', { method: 'POST', body: {} });
      toast(r?.ok ? '已补发' : '补发失败：' + (r?.error || ''));
      await refresh();
      await renderQr();
    } catch (e) {
      toast('补发失败：' + e.message);
    }
  });

  $('#na-clear')?.addEventListener('click', async () => {
    try {
      await api('/api/plugins/napcat-alert/clear', { method: 'POST', body: {} });
      await refresh();
    } catch (e) {
      toast('清空失败：' + e.message);
    }
  });

  $('#na-refresh')?.addEventListener('click', async () => {
    await refresh();
    await renderQr();
  });

  $('#na-save')?.addEventListener('click', async () => {
    const tip = $('#na-save-tip');
    const num = (id, dflt) => {
      const v = Number($(id)?.value);
      return Number.isFinite(v) && v > 0 ? v : dflt;
    };
    const passInput = $('#na-pass')?.value || '';
    // 授权码留空 / 还是掩码 → 沿用已保存的旧值（配置是整键替换，必须自己补齐）
    let pass = passInput;
    if (!pass || pass.includes('****')) {
      try {
        const cur = (await pluginConfigOf(ctx.pluginId)) || {};
        pass = cur?.smtp?.pass || '';
      } catch { pass = ''; }
    }
    const patch = {
      enabled: Boolean($('#na-enabled')?.checked),
      intervalSec: num('#na-interval', 120),
      failThreshold: num('#na-threshold', 2),
      attachQr: Boolean($('#na-attach')?.checked),
      notifyRecovery: Boolean($('#na-recover')?.checked),
      qrPath: ($('#na-qrpath')?.value || '').trim(),
      smtp: {
        host: ($('#na-host')?.value || '').trim(),
        port: num('#na-port', 465),
        tls: $('#na-tls')?.value || 'ssl',
        user: ($('#na-user')?.value || '').trim(),
        pass,
        from: ($('#na-from')?.value || '').trim(),
        to: ($('#na-to')?.value || '').trim()
      }
    };
    try {
      await savePluginConfig('napcat-alert', patch);
      tip.textContent = '已保存，下一轮探测生效。';
      toast('已保存');
      await refresh();
    } catch (e) {
      tip.textContent = '保存失败：' + e.message;
      toast('保存失败：' + e.message);
    }
  });

  renderHistory();
  renderQr();
}
