// ══════════════════════════════════════════════════════════════
//  astrbot-compat · 市场面板
// ══════════════════════════════════════════════════════════════
//
// 这个面板只做「装」。装完之后每个插件就是控制台插件列表里的一张普通卡片——
// 启用 / 停用 / 配置 / 卸载 / 导出全在那边，这里不再重复造一套开关。
//
// 市场索引由后端拉取并缓存 6 小时，前端只做过滤和展示。

const BASE = '/api/plugins/astrbot-compat';

export async function mountPanel(root, ctx) {
  const { api, esc } = ctx;
  let info = { mounted: [] };

  root.innerHTML = `
    <div class="card">
      <div class="row" style="justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
        <h3 style="margin:0">插件市场</h3>
        <div class="row" style="gap:8px">
          <span class="muted" style="font-size:12px" id="ab-env"></span>
          <button class="btn" id="ab-localize" title="把已装插件的英文名换成中文（只改展示名，不动代码与配置）">名称中文化</button>
          <button class="btn" id="ab-rerender" title="给已装插件重新生成卡片说明书（不动源码与配置）">重建卡片</button>
          <button class="btn" id="ab-refresh">刷新</button>
        </div>
      </div>
      <p class="muted" style="font-size:12.5px;margin:8px 0 0;line-height:1.7">
        这里装的每个插件，都会变成插件列表里的一张<b>原生卡片</b>：能单独启停、单独配置、单独卸载。
        卡片的「配置」里写着<b>怎么用</b>（命令表 + 从仓库 README 存下来的说明书）。
        命令消息在唤醒模型之前就被接走，不消耗 token。<br />
        市场默认只列<b>实测能跑</b>的插件（装得上、命令有响应）；勾选「显示未验证」可看全量。
      </p>
      <div id="ab-out" class="muted" style="font-size:12.5px;margin-top:8px"></div>
      <div id="ab-kernel"></div>
    </div>

    <div class="card" style="margin-top:12px">
      <h3 style="margin:0 0 10px">已装插件 <span class="muted" id="ab-count" style="font-weight:400;font-size:12px"></span></h3>
      <div id="ab-list"></div>
    </div>

    <div class="card" style="margin-top:12px">
      <h3 style="margin:0 0 10px">官方市场 <span class="muted" id="ab-total" style="font-weight:400;font-size:12px"></span></h3>
      <div class="row" style="gap:8px">
        <input id="ab-q" placeholder="搜插件名 / 描述 / 标签，例如：点歌、Steam、古诗" style="flex:1;min-width:220px;padding:7px 10px;border:1px solid var(--border,#ddd);border-radius:7px;background:transparent;color:inherit" />
        <button class="btn primary" id="ab-search">搜索</button>
        <button class="btn" id="ab-sync" title="强制刷新市场索引">同步索引</button>
        <label title="默认只列实测能跑的插件（装得上、命令有响应）。勾上可看全量 1332 个，未验证的装上可能跑不动" style="display:flex;align-items:center;gap:5px;font-size:12px" class="muted">
          <input type="checkbox" id="ab-all" style="margin:0" />显示未验证
        </label>
      </div>
      <div id="ab-market" style="margin-top:10px"></div>
    </div>
  `;

  const $ = (s) => root.querySelector(s);
  const out = (text, isErr = false) => {
    const el = $('#ab-out');
    el.innerHTML = text
      ? `<span style="color:${isErr ? 'var(--error,#c62828)' : 'var(--muted)'}">${esc(text)}</span>`
      : '';
  };

  function renderInstalled() {
    const items = info.mounted || [];
    $('#ab-count').textContent = items.length ? `（${items.length} 个）` : '（还没有装）';
    if (!items.length) {
      $('#ab-list').innerHTML = '<p class="muted" style="font-size:13px">还没有装。在下面的市场搜一个装，装完它会出现在插件列表里。</p>';
      return;
    }
    $('#ab-list').innerHTML = items.map((it) => {
      const cmds = (it.commands || [])
        .map((c) => `<code style="font-size:11.5px;padding:1px 5px;border-radius:4px;background:var(--bg-3,#f1f3f5)">/${esc(c)}</code>`)
        .join(' ');
      return `
      <div style="border:1px solid var(--border,#e3e6eb);border-radius:9px;padding:10px 12px;margin-bottom:8px">
        <div class="row" style="justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:baseline">
          <div>
            <b>${esc(it.name || it.origin)}</b>
            <span class="muted" style="font-size:11.5px">v${esc(it.version || '?')} · 插件 id ${esc(it.slug)}</span>
          </div>
          <div class="row" style="gap:6px">
            <button class="btn" data-act="reload" data-origin="${esc(it.origin)}" style="font-size:12px">重载</button>
            <button class="btn" data-act="uninstall" data-origin="${esc(it.origin)}" style="font-size:12px">卸载</button>
          </div>
        </div>
        ${cmds ? `<div style="margin-top:6px">${cmds}</div>` : '<div class="muted" style="font-size:12px;margin-top:4px">事件型插件，没有命令</div>'}
        ${it.storeExists ? '' : '<div class="error" style="font-size:12px;margin-top:4px">源码丢失，需要重新安装</div>'}
        <div class="muted" style="font-size:11.5px;margin-top:4px">用法与配置在插件列表的 <b>${esc(it.slug)}</b> 卡片里点「配置」—— 顶部「怎么用」有命令表，下面还有仓库说明书</div>
        <div class="muted" style="font-size:11.5px">${esc(it.repo || '')}</div>
      </div>`;
    }).join('');
  }

  function renderMarket(res) {
    const items = res.items || [];
    // total 是过滤后的数量；hidden 是被「只显示已验证」挡掉的；marketTotal 是上游索引总量
    $('#ab-total').textContent = res.total
      ? `（可装 ${res.total} 个${res.hidden ? ` · 已隐藏 ${res.hidden} 个未验证` : ''}${res.at ? ' · ' + new Date(res.at).toLocaleString() : ''}）`
      : '';
    if (!items.length) {
      $('#ab-market').innerHTML = '<p class="muted" style="font-size:13px">没有匹配的插件。</p>';
      return;
    }
    $('#ab-market').innerHTML = items.map((it) => `
      <div style="display:flex;justify-content:space-between;gap:10px;border-bottom:1px solid var(--border,#eee);padding:8px 0">
        <div style="min-width:0">
          <div><b style="font-size:13.5px">${esc(it.name)}</b>
            <span class="muted" style="font-size:11.5px">@${esc(it.author || '?')}</span></div>
          <div class="muted" style="font-size:12px;margin-top:2px">${esc(it.desc || '')}</div>
          <div class="muted" style="font-size:11px;margin-top:2px">${esc(it.repo || '')}</div>
        </div>
        <div style="flex:0 0 auto">
          ${it.installed
            ? '<span class="muted" style="font-size:12px">已装</span>'
            : `<button class="btn primary" data-act="install" data-repo="${esc(it.repo)}" data-name="${esc(it.name)}" style="font-size:12px">安装</button>`}
        </div>
      </div>`).join('');
  }

  async function load() {
    try {
      info = await api(`${BASE}/info?t=${Date.now()}`);
      $('#ab-env').textContent = `Python：${info.python}${info.venv ? '（独立 venv）' : ''}`;
      renderInstalled();
    } catch (e) {
      // 关键：读不到状态时要说"读不到"，不能渲染成"还没有装"——那是两回事
      info = { mounted: [] };
      $('#ab-env').textContent = '';
      $('#ab-count').textContent = '';
      $('#ab-list').innerHTML =
        `<p style="font-size:12.5px;color:var(--error,#c62828)">插件状态读取失败：${esc(e.message)}。` +
        `点右上「刷新」重试；一直失败就看服务端日志。</p>`;
    }
    renderKernelBanner();
  }

  /** 内核状态横幅：旧内核提示一键升级；升级过就给回滚入口。 */
  async function renderKernelBanner() {
    const box = $('#ab-kernel');
    if (!box) return;
    let k = null;
    try { k = await api(`${BASE}/kernel?t=${Date.now()}`); } catch { k = null; }
    if (!k || !k.ok) { box.innerHTML = ''; return; }

    // 第三方定制宿主：不给升级入口，只给一句说明。
    // 这类宿主（name 不是 qq-agent，比如 bg-qqagent）自带本地补丁，
    // 整包换内核会把人家定制全冲掉（2026-10-25 事故），所以直接禁用。
    if (k.ownHost === false) {
      box.innerHTML = `
        <div class="muted" style="margin-top:8px;font-size:11.5px;line-height:1.7">
          检测到这是定制宿主（package.json name = <code>${esc(k.hostName || '未知')}</code>），
          不是原版 qq-agent。<b>内核升级已停用</b>——避免覆盖你本地的补丁与改动。
          市场装插件、更新插件都不受影响。
        </div>`;
      return;
    }

    if (k.needUpgrade && k.bundled) {
      box.innerHTML = `
        <div style="margin-top:10px;padding:10px 12px;border:1px solid var(--warn-border,#f0b429);border-radius:9px;background:var(--warn-bg,#fff8e6);font-size:12.5px;line-height:1.7">
          <b>内核需要升级</b>（当前内核缺「顶栏独立栏目」支持，插件市场会多占一张插件卡片）。
          点下面按钮一键升级到 2.8.1 —— 自动备份原文件、语法检查通过才重启，失败自动还原。<br />
          <button class="btn primary" id="ab-kernel-up" style="font-size:12px;margin-top:6px">一键升级内核</button>
        </div>`;
      $('#ab-kernel-up').onclick = async () => {
        const ok = confirm(
          '将把内核的 src / ui / skills / package.json 替换成包内自带的新版，然后重启服务（约 10 秒）。\n\n' +
          '· 旧内核会先自动备份到 _backup/\n' +
          '· 升级后会挂看门狗：60 秒内服务起不来会自动回滚\n' +
          '· 但升级期间面板会短暂断开，属正常\n\n' +
          '确定要升级吗？'
        );
        if (!ok) return;
        const btn = $('#ab-kernel-up');
        btn.disabled = true;
        btn.textContent = '正在升级并重启…（约 10 秒后自动刷新）';
        try {
          const r = await api(`${BASE}/kernel/upgrade`, { method: 'POST' });
          if (!r.ok) { btn.textContent = '失败：' + (r.error || '未知'); btn.disabled = false; return; }
          setTimeout(() => location.reload(), 9000);
        } catch (e) {
          // 服务正在重启时连接断开属预期：等一拍刷新
          setTimeout(() => location.reload(), 9000);
        }
      };
    } else if (k.backups && k.backups.length) {
      box.innerHTML = `
        <div class="muted" style="margin-top:8px;font-size:11.5px">
          内核 2.8.1 已就绪 · 有历史备份（${esc(k.backups[k.backups.length - 1])}）
          <a href="#" id="ab-kernel-rb" style="margin-left:6px">回滚内核</a>
        </div>`;
      $('#ab-kernel-rb').onclick = async (ev) => {
        ev.preventDefault();
        if (!confirm('把内核回滚到最近一次升级前的状态？服务会重启。')) return;
        try { await api(`${BASE}/kernel/rollback`, { method: 'POST' }); } catch { /* 重启中 */ }
        setTimeout(() => location.reload(), 9000);
      };
    } else {
      box.innerHTML = '';
    }
  }

  async function search(q, force = false) {
    out('正在查市场…');
    const showAll = !!($('#ab-all') && $('#ab-all').checked);
    try {
      const res = await api(
        `${BASE}/market?limit=40&q=${encodeURIComponent(q)}${force ? '&refresh=1' : ''}${showAll ? '&all=1' : ''}&t=${Date.now()}`
      );
      renderMarket(res);
      if (res.stale) {
        out(`索引源暂时不可达，正在用本地缓存（可装 ${res.total} 个，缓存时间 ${new Date(res.at).toLocaleString()}）`);
      } else {
        out(`可装 ${res.total} 个（共索引 ${res.marketTotal || '?'} 个，未验证的已隐藏），当前显示 ${(res.items || []).length} 条`);
      }
    } catch (e) {
      out(`市场索引拉取失败：${e.message}`, true);
    }
  }

  root.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('button[data-act]');
    if (!btn) return;
    const act = btn.dataset.act;

    if (act === 'install') {
      const repo = btn.dataset.repo;
      btn.disabled = true;
      btn.textContent = '安装中…';
      out(`正在安装 ${btn.dataset.name}（下载 → 解压 → 装依赖 → 生成插件 → 热装载）`);
      try {
        const r = await api(`${BASE}/install`, { method: 'POST', body: JSON.stringify({ repo }) });
        if (!r.ok) throw new Error(r.error || '安装失败');
        const cmds = (r.commands || []).map((c) => '/' + c).join(' ') || '（无命令）';
        out(`已装 ${r.name}，插件 id ${r.slug}，命令 ${cmds}${r.mounted ? '，已生效' : ''}${r.mountError ? ' · 热装载失败：' + r.mountError : ''}${r.warning ? ' · ' + r.warning : ''}。到插件列表打开 ${r.slug} 卡片的「配置」，顶部就是「怎么用」`, !r.mounted);
        await load();
        await search($('#ab-q').value.trim());
        btn.disabled = false;
        btn.textContent = '安装';
      } catch (e) {
        out(`安装失败：${e.message}`, true);
        btn.disabled = false;
        btn.textContent = '安装';
      }
      return;
    }

    if (act === 'reload') {
      out('正在重载…');
      const r = await api(`${BASE}/reload`, { method: 'POST', body: JSON.stringify({ origin: btn.dataset.origin }) });
      out(r.ok ? '已重载' : `重载失败：${r.error}`, !r.ok);
      await load();
      return;
    }

    if (act === 'uninstall') {
      const origin = btn.dataset.origin;
      if (!confirm(`卸载 ${origin}？插件卡片和源码会一起删除。`)) return;
      const r = await api(`${BASE}/uninstall`, { method: 'POST', body: JSON.stringify({ origin }) });
      out(r.ok ? `已卸载 ${origin}（刷新页面后卡片消失）` : `卸载失败：${r.error}`, !r.ok);
      await load();
    }
  });

  $('#ab-refresh').onclick = () => load();
  $('#ab-localize').onclick = async () => {
    out('正在把插件名换成中文…');
    try {
      const r = await api(`${BASE}/localize-names`, { method: 'POST', body: JSON.stringify({}) });
      if (!r.ok) throw new Error(r.error || '改名失败');
      const changed = r.changed || [];
      if (!changed.length) {
        out('已经全是中文名了，没有要改的。想给某个插件换名字：在 zh-names.json 的 plugins 里加一行，再点一次这里。');
      } else {
        const list = changed.map((c) => `${c.from} → ${c.to}`).join('；');
        out(`已改 ${changed.length} 个：${list}${(r.failed || []).length ? ` · 重载失败：${r.failed.join('，')}` : ''}`, (r.failed || []).length > 0);
      }
      await load();
    } catch (e) {
      out(`改名失败：${e.message}`, true);
    }
  };
  $('#ab-rerender').onclick = async () => {
    out('正在重建卡片（补说明书 / 换新模板）…');
    try {
      const r = await api(`${BASE}/rerender`, { method: 'POST', body: JSON.stringify({}) });
      out(r.ok ? `已重建 ${r.count} 张卡片：${(r.slugs || []).join('、')}。打开各卡片的「配置」即可看到「怎么用」` : `重建失败：${r.error}`, !r.ok);
      await load();
    } catch (e) {
      out(`重建失败：${e.message}`, true);
    }
  };
  $('#ab-search').onclick = () => search($('#ab-q').value.trim());
  $('#ab-sync').onclick = () => search($('#ab-q').value.trim(), true);
  $('#ab-q').addEventListener('keydown', (e) => { if (e.key === 'Enter') search($('#ab-q').value.trim()); });

  await load();
  await search('');
}

// 兼容旧内核：旧内核的顶栏页签只认 `mount`（找不到就报「没有导出 mount()」），
// 新内核/插件配置面板走 `mountPanel`。这里让 `mount` 作为 `mountPanel` 的别名导出，
// 两种内核都能挂载。
export const mount = mountPanel;
export default { mount, mountPanel };
