// ══════════════════════════════════════════════════════════════
//  astrbot-compat · 市场与安装入口
// ══════════════════════════════════════════════════════════════
//
//  职责边界（2026-10-22 重做后）：
//    本插件**不再管理 AstrBot 插件的生命周期**。它只做三件事：
//      ① 提供市场索引与一键安装（下载源码 + 装依赖 + 生成原生插件）
//      ② 安装完把新生成的插件热装载进宿主，立刻可用，不用重启
//      ③ 清理孤儿源码（用户从插件卡片卸载时，内核只删 plugins/<id>）
//
//  每个 AstrBot 插件现在是 plugins/ab-<slug>/ 下的**原生插件**：
//    有自己的 manifest、配置表单、启用开关、卸载按钮、导出包。
//    所以「停用 / 配置 / 卸载」全部走内核既有端点，这里不重复实现。
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';

import { runtime, reguide, resolveCommand, zhName, forcedName, PLUGINS_ROOT, STORE_DIR, VENV_DIR, HERE, DATA_ROOT } from './runtime.js';
import { normalizeManifest } from '../../src/core/manifest.js';

// ── 验证白名单：市场默认只列「实测能跑」的插件 ──────────────
// verified.json 随包分发（本轮实测 674 个），data 下的同名文件是运行期
// 追加（升级插件不丢）。搜得出来装不上/装上就挂的插件不进市场列表。
let VERIFIED = null;
function verifiedRepos() {
  if (VERIFIED) return VERIFIED;
  const set = new Set();
  try {
    for (const r of JSON.parse(fs.readFileSync(path.join(HERE, 'verified.json'), 'utf8'))) {
      set.add(String(r).replace(/\.git$/, ''));
    }
  } catch { /* 包里没有白名单 → 不过滤 */ }
  try {
    for (const r of JSON.parse(fs.readFileSync(path.join(DATA_ROOT, 'verified.json'), 'utf8'))) {
      set.add(String(r).replace(/\.git$/, ''));
    }
  } catch { /* 没有运行期追加 */ }
  VERIFIED = set;
  return set;
}

/** 把刚生成的插件目录热装载进宿主（无需重启） */
async function hotLoad(ctx, slug) {
  const host = ctx.pluginHost || ctx.orchestrator?.pluginHost;
  if (!host) throw new Error('拿不到插件宿主（内核版本不支持热装载）');

  const dir = path.join(PLUGINS_ROOT, slug);
  const file = path.join(dir, 'manifest.json');
  if (!fs.existsSync(file)) throw new Error(`manifest 未生成：${file}`);

  const norm = normalizeManifest(JSON.parse(fs.readFileSync(file, 'utf8')), { dirName: slug });
  if (!norm.ok) throw new Error(`manifest 不合法：${norm.error}`);

  if (host.records.has(slug)) await host.disable(slug);
  const rec = await host.enable(norm.manifest);
  if (rec?.status !== 'enabled') throw new Error(rec?.lastError || '启用失败');
  return rec;
}

export async function activate(ctx) {
  fs.mkdirSync(STORE_DIR, { recursive: true });

  // 孤儿清理：内核卸载只删 plugins/<id>，不知道源码在 store 里
  const removed = runtime.gc();
  if (removed.length) ctx.log(`清理孤儿源码：${removed.join(', ')}`);

  const mounted = runtime.installed();
  ctx.log(`插件市场就绪，已挂载 ${mounted.length} 个插件`);

  // ── 市场 ────────────────────────────────────────────────
  // 中文名按 key 缓存：一次搜索要过 1300 条，逐条翻译太浪费
  const nameCache = new Map();
  const nameOf = (key, v) => {
    if (nameCache.has(key)) return nameCache.get(key);
    const n = forcedName(key) || zhName(key, v.display_name || v.name);
    nameCache.set(key, n);
    return n;
  };
  ctx.http.route('GET', '/market', async (req, body, url) => {
    const q = String(url.searchParams.get('q') || '').trim().toLowerCase();
    const force = url.searchParams.get('refresh') === '1';
    if (force) nameCache.clear();
    const limit = Math.min(Number(url.searchParams.get('limit') || 40), 200);
    // 只列验证过的：默认开。配置 onlyVerified=false 可看全量，?all=1 同效（排障用）。
    const ownCfg = (ctx.config && ctx.config.get) ? (ctx.config.get() || {}) : {};
    const onlyVerified = ownCfg.onlyVerified !== false && url.searchParams.get('all') !== '1';
    const verified = onlyVerified ? verifiedRepos() : null;
    const payload = await runtime.market(force);
    const all = payload.data || {};
    const installedRepos = new Set(mounted.map((x) => x.repo));
    const rows = [];
    let hidden = 0;
    for (const [key, v] of Object.entries(all)) {
      if (key === '$meta') continue;
      // 市场索引里 tags 字段有的条目是数组、有的是一串逗号分隔的文字，两种都得认
      const tags = Array.isArray(v.tags)
        ? v.tags
        : String(v.tags || '').split(/[,，\s]+/).filter(Boolean);
      // 中文名也进搜索词：用户按「热榜」「欢迎」这种中文搜得到
      const name = nameOf(key, v);
      const blob = `${name} ${v.display_name || ''} ${key} ${v.desc || ''} ${tags.join(' ')} ${v.author || ''}`.toLowerCase();
      if (q && !blob.includes(q)) continue;
      if (verified) {
        const repo = String(v.repo || '').replace('https://github.com/', '').replace(/\.git$/, '');
        // 已装的一律显示（在用的必然能跑），其余不在白名单就隐藏
        if (!installedRepos.has(v.repo || '') && !verified.has(repo)) { hidden += 1; continue; }
      }
      rows.push({
        key,
        name,
        desc: (v.short_desc || v.desc || '').slice(0, 220),
        author: v.author || '',
        repo: v.repo || '',
        tags: tags.slice(0, 5),
        category: v.category || '',
        installed: installedRepos.has(v.repo || '')
      });
    }
    return {
      ok: true,
      total: rows.length,
      hidden,
      marketTotal: Object.keys(all).filter((k) => k !== '$meta').length,
      at: payload.at,
      stale: !!payload.stale,
      items: rows.slice(0, limit)
    };
  });

  // ── 安装 ────────────────────────────────────────────────
  ctx.http.route('POST', '/install', async (req, body) => {
    const repo = body?.repo;
    if (!repo) return { ok: false, error: '缺少 repo' };
    try {
      // 顺手清一次孤儿：用户可能刚在插件卡片上卸载过（内核只删 plugins/<id>）
      const orphans = runtime.gc();
      if (orphans.length) ctx.log(`安装前清理孤儿源码：${orphans.join(', ')}`);
      const rec = await runtime.install(repo);
      let mounted = false;
      let mountError = '';
      try {
        await hotLoad(ctx, rec.slug);
        mounted = true;
      } catch (err) {
        mountError = String(err?.message || err);
        ctx.log(`[${rec.origin}] 生成成功但热装载失败：${mountError}`);
      }
      return {
        ok: true,
        origin: rec.origin,
        slug: rec.slug,
        name: rec.name,
        version: rec.version,
        commands: rec.commands,
        mounted,
        mountError,
        warning: rec.loadError || ''
      };
    } catch (err) {
      return { ok: false, error: String(err?.message || err) };
    }
  });

  // ── 重载（改完配置想立刻生效时用；平时靠指纹自动重启） ──
  ctx.http.route('POST', '/reload', async (req, body) => {
    const origin = String(body?.origin || '');
    const meta = runtime.byOrigin(origin);
    if (!meta) return { ok: false, error: '没有这个插件' };
    try {
      await hotLoad(ctx, meta.slug);
      return { ok: true, slug: meta.slug };
    } catch (err) {
      return { ok: false, error: String(err?.message || err) };
    }
  });

  // ── 重建卡片（补 usage.md / 换新模板；不动源码与配置） ──
  ctx.http.route('POST', '/rerender', async (req, body) => {
    try {
      // 传 slug 就只重建那一张卡（排查单个插件时不用把 12 个都重探一遍）
      const done = await reguide(String(body?.slug || ''));
      return { ok: true, count: done.length, slugs: done };
    } catch (err) {
      return { ok: false, error: String(err?.message || err) };
    }
  });

  // ── 名称中文化（只改展示名，不动源码/配置/数据） ──────────
  ctx.http.route('POST', '/localize-names', async () => {
    try {
      const changed = runtime.relocalizeNames();
      const host = ctx.pluginHost || ctx.orchestrator?.pluginHost;
      const reloaded = [];
      const failed = [];
      for (const c of changed) {
        try {
          if (host?.records?.has(c.slug)) {
            await host.reload(c.slug);
            reloaded.push(c.slug);
          }
        } catch (err) {
          failed.push(`${c.slug}：${String(err?.message || err)}`);
        }
      }
      return { ok: true, changed, reloaded, failed };
    } catch (err) {
      return { ok: false, error: String(err?.message || err) };
    }
  });

  // ── 卸载（也可直接在插件卡片点卸载，两条路等价） ────────
  ctx.http.route('POST', '/uninstall', async (req, body) => {
    const origin = String(body?.origin || '');
    const meta = runtime.byOrigin(origin);
    if (!meta) return { ok: false, error: '没有这个插件' };
    const host = ctx.pluginHost || ctx.orchestrator?.pluginHost;
    try {
      if (host?.records?.has(meta.slug)) await host.disable(meta.slug);
      fs.rmSync(path.join(PLUGINS_ROOT, meta.slug), { recursive: true, force: true });
      host?.records?.delete(meta.slug);
      await runtime.uninstallOrigin(origin);
      return { ok: true };
    } catch (err) {
      return { ok: false, error: String(err?.message || err) };
    }
  });

  // ── 内核一键升级（面板操作，免命令行）─────────────────────
  // 目标读者是「只有控制台、不进 shell」的使用者：导入这个插件包后，
  // 内核旧也能在面板上一键升到 2.8.1。内核文件随包分发在 kernel/ 目录。
  // 注意是两层 ../..：HERE=plugins/astrbot-compat，两级上去正好是内核根。
  // （写成三层会指到内核目录外面 —— e2e 实测抓过这个 bug，别改回去）
  const KERNEL_ROOT = path.resolve(HERE, '../..');
  const KERNEL_BUNDLED = path.join(HERE, 'kernel');
  const KERNEL_CHECK_FILES = [
    'src/app.js', 'src/skill.js', 'src/core/plugin-admin.js',
    'src/core/plugin-host.js', 'src/core/manifest.js', 'ui/app.js',
  ];
  // 升级时会被覆盖的顶层文件 —— 必须一起备份，否则回滚不完整（2.9.4 修）
  const KERNEL_TOP_FILES = ['package.json', 'PLUGIN-ARCH.md', '插件与Skill制作及使用规范.md'];

  const kernelHas = (marker) => {
    try {
      return fs.readFileSync(path.join(KERNEL_ROOT, 'src/core/manifest.js'), 'utf8').includes(marker);
    } catch { return false; }
  };

  /** 游离进程延迟重启服务：响应先回到浏览器，一拍之后 systemctl 才动手。
   *  单元名从自己的 cgroup 里探测（部署可能不叫 qq-agent），认不出再退回默认名。 */
  const ownUnit = () => {
    try {
      const cg = fs.readFileSync('/proc/self/cgroup', 'utf8');
      const m = cg.match(/([-\w]+)\.service\b/g);
      if (m && m.length) return m[m.length - 1].replace(/\.service$/, '');
    } catch { /* 非 systemd 环境 */ }
    return 'qq-agent';
  };
  const scheduleRestart = () => {
    try {
      const cp = spawn('sh',
        ['-c', `sleep 1.5; systemctl restart ${ownUnit()} 2>/dev/null || true`],
        { detached: true, stdio: 'ignore' });
      cp.unref();
    } catch { /* 非 systemd 环境：note 里已提示手动重启 */ }
  };

  /** 控制台端口：从 data/config.json 读，读不到退回 3210。 */
  const consolePort = () => {
    try {
      const c = JSON.parse(fs.readFileSync(path.join(DATA_ROOT, '../../config.json'), 'utf8'));
      return Number(c?.server?.port) || 3210;
    } catch { return 3210; }
  };

  /**
   * 升级看门狗（2.9.4 新增）。
   *
   * 为什么需要：升级把内核换掉后 `systemctl restart`，如果新内核运行时起不来
   * （缺依赖、配置不兼容、语法检查过了但 import 失败……），服务就一直起不来了，
   * 面板只会卡在「正在启动」，用户又没有 shell —— 只能干等。
   *
   * 做法：升级前写一个独立脚本到备份目录，用游离进程跑起来。它每 5 秒探一次
   * 本机 HTTP 健康，60 秒都不通就把备份原样拷回、重启服务，并写日志。
   * 服务正常则脚本自己退出，不留下常驻进程。
   */
  const spawnWatchdog = (bak) => {
    const script = path.join(bak, '__watchdog.mjs');
    const logFile = path.join(bak, '__watchdog.log');
    const port = consolePort();
    const unit = ownUnit();
    const body = `import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';

const ROOT = ${JSON.stringify(KERNEL_ROOT)};
const BAK = ${JSON.stringify(bak)};
const PORT = ${port};
const UNIT = ${JSON.stringify(unit)};
const LOG = ${JSON.stringify(logFile)};
const DIRS = ['src', 'ui', 'skills'];
const FILES = ${JSON.stringify(KERNEL_TOP_FILES)};

const log = (m) => { try { fs.appendFileSync(LOG, '[' + new Date().toISOString() + '] ' + m + '\\n'); } catch {} };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function healthy() {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 4000);
    const r = await fetch('http://127.0.0.1:' + PORT + '/', { signal: ctrl.signal });
    clearTimeout(t);
    return r.status < 500;
  } catch { return false; }
}

(async () => {
  log('看门狗启动，端口 ' + PORT + '，单元 ' + UNIT);
  for (let i = 0; i < 12; i += 1) {
    await sleep(5000);
    if (await healthy()) { log('服务已恢复，看门狗退出'); process.exit(0); }
    log('第 ' + (i + 1) + ' 次健康检查未通过');
  }
  log('服务 60 秒未恢复，开始自动回滚');
  try {
    for (const d of DIRS) {
      const from = path.join(BAK, d);
      if (!fs.existsSync(from)) continue;
      fs.rmSync(path.join(ROOT, d), { recursive: true, force: true });
      fs.cpSync(from, path.join(ROOT, d), { recursive: true });
    }
    for (const f of FILES) {
      const from = path.join(BAK, f);
      if (fs.existsSync(from)) fs.copyFileSync(from, path.join(ROOT, f));
    }
    execSync('systemctl restart ' + UNIT + ' 2>/dev/null || true');
    log('自动回滚完成并已重启');
  } catch (e) {
    log('自动回滚失败：' + (e && e.message ? e.message : e));
  }
  process.exit(0);
})();
`;
    try {
      fs.writeFileSync(script, body, 'utf8');
      fs.writeFileSync(logFile, `[${new Date().toISOString()}] 升级开始\n`, 'utf8');
      const cp = spawn(process.execPath, [script], { detached: true, stdio: 'ignore' });
      cp.unref();
      return { ok: true, script, log: logFile };
    } catch (err) {
      return { ok: false, error: String(err?.message ?? err) };
    }
  };

  /** 读宿主 package.json 的 name，判断是不是原版 qq-agent。
   *
   *  为什么必须校验：这个升级会把整个内核（src/ui/skills/package.json）换成包里自带那套。
   *  如果对方是**第三方定制宿主**（自带本地补丁：注入钩子、界面改造、控制台鉴权、模型容错……），
   *  整包换掉就等于把人家所有定制全冲了 —— 2026-10-25 真实事故：
   *  某台 bg-qqagent 定制宿主被换成原版内核，鉴权补丁丢失 → 所有接口 401 → 面板永久卡加载。
   *  所以只认原版宿主名，其它名字一律拒绝升级。
   */
  const hostInfo = () => {
    try {
      const pkg = JSON.parse(fs.readFileSync(path.join(KERNEL_ROOT, 'package.json'), 'utf8'));
      const name = String(pkg?.name || '');
      return { name, own: name === 'qq-agent' };
    } catch {
      return { name: '', own: false };
    }
  };

  ctx.http.route('GET', '/kernel', () => {
    const hi = hostInfo();
    const need = !kernelHas('hideCard');
    const backups = fs.existsSync(path.join(KERNEL_ROOT, '_backup'))
      ? fs.readdirSync(path.join(KERNEL_ROOT, '_backup'))
        .filter((d) => /^kernel-|^aio-|^panel-kernel-/.test(d)).sort().slice(-5)
      : [];
    const hasBundled = fs.existsSync(path.join(KERNEL_BUNDLED, 'src/core/manifest.js'));
    return {
      ok: true, ownHost: hi.own, hostName: hi.name,
      needUpgrade: need && hi.own,   // 第三方宿主永远不提示升级
      bundled: hasBundled, backups, root: KERNEL_ROOT
    };
  });

  ctx.http.route('POST', '/kernel/upgrade', async () => {
    const hi = hostInfo();
    if (!hi.own) {
      return {
        ok: false,
        error: `这是第三方定制宿主（package.json 的 name = "${hi.name || '读不到'}"），不是原版 qq-agent。`
          + '为避免覆盖你的定制代码（本地补丁 / 界面改造 / 鉴权逻辑），内核升级已停用。'
          + '要升级请用你自己的升级方式。'
      };
    }
    if (!fs.existsSync(path.join(KERNEL_BUNDLED, 'src'))) {
      return { ok: false, error: '包里没有内核文件（kernel/ 缺失），请用完整包重装插件市场' };
    }
    const ts = new Date().toISOString().replace(/[-:T.]/g, '').slice(0, 14);
    const bak = path.join(KERNEL_ROOT, '_backup', `panel-kernel-2.8.1-${ts}`);
    try {
      fs.mkdirSync(bak, { recursive: true });
      for (const d of ['src', 'ui', 'skills']) {
        if (fs.existsSync(path.join(KERNEL_ROOT, d))) {
          fs.cpSync(path.join(KERNEL_ROOT, d), path.join(bak, d), { recursive: true });
        }
      }
      // 顶层文件也要备份 —— 升级会覆盖它们，不备份的话回滚不完整（2.9.4 修）
      for (const f of KERNEL_TOP_FILES) {
        const from = path.join(KERNEL_ROOT, f);
        if (fs.existsSync(from)) fs.copyFileSync(from, path.join(bak, f));
      }
      for (const d of ['src', 'ui', 'skills']) {
        const from = path.join(KERNEL_BUNDLED, d);
        if (!fs.existsSync(from)) continue;
        fs.rmSync(path.join(KERNEL_ROOT, d), { recursive: true, force: true });
        fs.cpSync(from, path.join(KERNEL_ROOT, d), { recursive: true });
      }
      for (const f of ['package.json', 'PLUGIN-ARCH.md', '插件与Skill制作及使用规范.md']) {
        const from = path.join(KERNEL_BUNDLED, f);
        if (fs.existsSync(from)) fs.copyFileSync(from, path.join(KERNEL_ROOT, f));
      }
    } catch (err) {
      return { ok: false, error: `备份/复制失败，未做任何破坏性改动：${err?.message || err}` };
    }
    // 语法检查：不过就把三个目录原样放回去
    for (const f of KERNEL_CHECK_FILES) {
      const p = path.join(KERNEL_ROOT, f);
      if (!fs.existsSync(p)) continue;
      const pass = await new Promise((resolve) => {
        try {
          const cp = spawn(process.execPath, ['--input-type=module', '--check'],
            { stdio: ['pipe', 'ignore', 'ignore'] });
          cp.on('exit', (c) => resolve(c === 0));
          cp.on('error', () => resolve(false));
          cp.stdin.end(fs.readFileSync(p));
        } catch { resolve(false); }
      });
      if (!pass) {
        for (const d of ['src', 'ui', 'skills']) {
          if (fs.existsSync(path.join(bak, d))) {
            fs.rmSync(path.join(KERNEL_ROOT, d), { recursive: true, force: true });
            fs.cpSync(path.join(bak, d), path.join(KERNEL_ROOT, d), { recursive: true });
          }
        }
        return { ok: false, error: `${f} 语法检查不过，已回滚到升级前（备份：${bak}）` };
      }
    }
    // 起看门狗：重启后 60 秒内服务不通就自动回滚（2.9.4 新增，避免用户卡死）
    const dog = spawnWatchdog(bak);
    // 重启：先回响应，再由游离子进程延迟一拍执行，避免杀死自己的请求
    scheduleRestart();
    const dogNote = dog.ok
      ? `已挂看门狗：60 秒内服务起不来会自动回滚（日志 ${dog.log}）`
      : `看门狗未启动（${dog.error}），若服务起不来请手动用备份恢复`;
    return {
      ok: true, backup: bak, watchdog: dog.ok,
      note: `已升级到 2.8.1，服务正在重启（约 10 秒），之后刷新本页。${dogNote}。备份在 ${bak}。`
    };
  });

  ctx.http.route('POST', '/kernel/rollback', async () => {
    const bakRoot = path.join(KERNEL_ROOT, '_backup');
    if (!fs.existsSync(bakRoot)) return { ok: false, error: '没有备份目录' };
    const cands = fs.readdirSync(bakRoot)
      .filter((d) => /^panel-kernel-/.test(d)).sort();
    if (!cands.length) return { ok: false, error: '没有面板升级留下的备份' };
    const bak = path.join(bakRoot, cands[cands.length - 1]);
    try {
      for (const d of ['src', 'ui', 'skills']) {
        if (fs.existsSync(path.join(bak, d))) {
          fs.rmSync(path.join(KERNEL_ROOT, d), { recursive: true, force: true });
          fs.cpSync(path.join(bak, d), path.join(KERNEL_ROOT, d), { recursive: true });
        }
      }
      // 顶层文件一并回滚（老备份里可能没有，存在才拷）
      for (const f of KERNEL_TOP_FILES) {
        const from = path.join(bak, f);
        if (fs.existsSync(from)) fs.copyFileSync(from, path.join(KERNEL_ROOT, f));
      }
    } catch (err) {
      return { ok: false, error: `回滚失败：${err?.message || err}` };
    }
    scheduleRestart(ctx);
    return { ok: true, note: '已回滚到 ' + cands[cands.length - 1] + '，服务正在重启。' };
  });

  // ── 运行时状态 ──────────────────────────────────────────
  ctx.http.route('GET', '/info', () => ({
    ok: true,
    python: fs.existsSync(path.join(VENV_DIR, 'bin', 'python')) ? 'venv' : 'python3',
    venv: fs.existsSync(VENV_DIR),
    store: STORE_DIR,
    mounted: runtime.installed().map((x) => ({
      slug: x.slug,
      origin: x.origin,
      name: x.name,
      version: x.version,
      commands: x.commands || [],
      repo: x.repo || '',
      storeExists: x.storeExists,
      running: !!runtime.runners.get(x.origin)?.info
    }))
  }));

  // ── 自检：走和真实消息完全相同的代码路径，只是不发送 ────
  ctx.http.route('POST', '/simulate', async (req, body) => {
    const text = String(body?.text || '').trim();
    if (!text) return { ok: false, error: '缺少 text' };

    const prefix = '/';
    // 只认"已挂载且启用"的插件 —— 自检必须和真实消息走同一套启用状态，
    // 否则停用后自检还能命中，会让人误判停用没生效。
    // 匹配走 resolveCommand（和真实钩子同一份逻辑），所以 "@机器人 /gs" 也能自检。
    const hit = (() => {
      const entries = new Map();
      for (const [origin, rec] of runtime.attached) {
        const cfg = rec.ctx?.config?.get?.() || {};
        if (cfg.enabled === false) continue;
        for (const cmd of rec.commands || []) entries.set(cmd, origin);
      }
      const found = resolveCommand(text, entries, prefix);
      if (!found) return null;
      return {
        cmd: found.cmd,
        origin: found.id,
        body: found.body,
        slug: runtime.byOrigin(found.id)?.slug || ''
      };
    })();
    if (!hit) return { ok: false, error: '没有启用中的插件认这条命令' };

    const fakeMsg = {
      chatKey: String(body?.chatKey || 'group:0'),
      kind: 'group',
      chatId: '0',
      userId: String(body?.userId || ''),
      senderName: String(body?.name || '面板测试'),
      selfId: '',
      messageId: 'simulate',
      media: []
    };
    try {
      // 自检也要走配置同步：否则刚改完配置在这里测，看到的还是旧值
      const mountRec = runtime.attached.get(hit.origin);
      if (mountRec?.ctx) runtime.syncConfig(hit.origin, mountRec.ctx.config.get());
      const res = await runtime.invoke(hit.origin, fakeMsg, hit.body);
      return {
        ok: true,
        origin: hit.origin,
        slug: hit.slug,
        matched: res?.matched === true,
        handler: res?.handler || '',
        actions: res?.actions || [],
        error: res?.error || ''
      };
    } catch (err) {
      return { ok: false, error: String(err?.message || err) };
    }
  });

  return {
    dispose() {
      // 各 ab-* 插件自己负责自己的进程；这里只兜底杀掉残留
      for (const id of [...runtime.runners.keys()]) {
        const r = runtime.runners.get(id);
        if (r) r.kill();
        runtime.runners.delete(id);
      }
    }
  };
}
