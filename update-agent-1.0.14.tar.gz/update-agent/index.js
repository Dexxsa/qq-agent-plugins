// ── 自动更新（插件版）──────────────────────────────────────────────────
//
//  想解决的问题：别的机器要「打开控制台就自动更新」，但内核补丁得登服务器跑
//  apply-kernel-patch.sh 才有。那就把这事做成**普通插件** —— 在控制台上传一次，
//  之后它自己把 plugins/ 下的插件跟着分发源升级，永远不用再碰命令行。
//
//  凭什么插件能做到：内核把 pluginHost 暴露在 ctx 里（热装载 AstrBot 市场插件时
//  留下的口子），而 host.reload(id) 就是「重新装载某个插件」的公开入口。于是
//  「下载 → 解包 → 换目录 → 重载」这条链在插件里就能闭环，不需要任何内核改动。
//
//  与内核内置更新器（src/core/plugin-updater.js）的关系：
//    · 内核那份是补丁版才有的；装了这个插件，那台机器就不必再打补丁；
//    · 若检测到内核已内置更新器，本插件默认**待命让位**（两边同时覆盖同一个目录
//      会打架）。config.preferSelf = true 可强行由本插件接管。
//
//  安全与稳妥：
//    · 只碰**更新名单**里的插件；名单外的一律不动（installNew 只保留兼容，不再放开名单外）；
//    · 名单里的插件若本机还没装，默认直接装上（installMissing）——名单本身就是"我要这些"，
//      否则新机器装完这个插件还得手工再传两个包，等于没解决麻烦；
//    · 包体 sha256 必须对得上，否则拒装；
//    · 覆盖前整目录改名备份，重载失败自动回滚；
//    · 依赖目录（node_modules / .venv / venv / __pycache__ / .git）更新时保留，
//      否则每升一次就要重装一次依赖。
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import zlib from 'node:zlib';
import crypto from 'node:crypto';

const SELF_ID = 'update-agent';
const KEEP_ON_REPLACE = new Set(['node_modules', '.venv', 'venv', '__pycache__', '.git']);
const MAX_PACKAGE_BYTES = 32 * 1024 * 1024;

const DEFAULTS = {
  enabled: true,
  source: 'https://fastly.jsdelivr.net/gh/Dexxsa/qq-agent-plugins@main',
  intervalMinutes: 30,
  autoApply: true,
  // 名单里还没装的插件，检查时顺手装上（默认开）。关掉则只提示、不装。
  installMissing: true,
  // 旧字段：早期含义是"连没装的也装"。现在名单外一律不碰，这个字段只为兼容老配置保留。
  installNew: false,
  preferSelf: false,
  // 更新名单：只碰这里列出的插件，一行一个 id。
  // 自己维护、走自动更新的插件（2026-10-25 起 5 个）。
  only: 'companion\nnapcat-alert\nastrbot-compat\ndaily-news'
};

// ── 版本比较 ──────────────────────────────────────────────────────────
//
// 宽松比较（1.2.3 / 0.2.0-qq.6 / v2 都认）：按 . - _ + ~ 切段，数字段按数值、
// 字符段按字典序，段数多的更新（0.2.0-qq.6 > 0.2.0）。不追求 semver 的
// 「预发布更小」，插件自更新只需要「新号大于旧号」这一个性质。
function compareVersion(a, b) {
  const tok = (v) => String(v ?? '').trim().replace(/^v/i, '')
    .split(/[.\-+_~]/).filter((s) => s !== '')
    .map((s) => (/^\d+$/.test(s) ? Number(s) : s));
  const ta = tok(a);
  const tb = tok(b);
  for (let i = 0; i < Math.max(ta.length, tb.length); i += 1) {
    const x = ta[i];
    const y = tb[i];
    if (x === undefined) return -1;
    if (y === undefined) return 1;
    if (typeof x === 'number' && typeof y === 'number') {
      if (x !== y) return x > y ? 1 : -1;
      continue;
    }
    if (typeof x === 'number') return -1;
    if (typeof y === 'number') return 1;
    if (x !== y) return x > y ? 1 : -1;
  }
  return 0;
}

const sha256 = (buf) => crypto.createHash('sha256').update(buf).digest('hex');

// ── 极简 tar 读取（ustar，只认普通文件）──────────────────────────────
//
// 分发包是内核 tarWrite 打的：短名、无软链、无 pax 扩展头，所以这点代码够用。
// 不为解包去引第三方依赖 —— 插件包要能直接丢给别人，依赖越少越不会出事。
function tarRead(buf) {
  const out = [];
  let off = 0;
  while (off + 512 <= buf.length) {
    const header = buf.subarray(off, off + 512);
    if (header.every((b) => b === 0)) break;           // 两个全零块 = 结束
    let name = header.subarray(0, 100).toString('utf8').replace(/\0[\s\S]*$/, '');
    const prefix = header.subarray(345, 500).toString('utf8').replace(/\0[\s\S]*$/, '');
    if (prefix) name = `${prefix}/${name}`;
    const sizeStr = header.subarray(124, 136).toString('ascii').replace(/\0[\s\S]*$/, '').trim();
    const size = parseInt(sizeStr, 8) || 0;
    const type = String.fromCharCode(header[156] || 48);
    off += 512;
    const data = buf.subarray(off, off + size);
    off += Math.ceil(size / 512) * 512;
    if (!name || type === '5') continue;               // 目录条目不需要建（写文件时自动建）
    if (type === '0' || type === '\0' || type === '') out.push([name, Buffer.from(data)]);
  }
  return out;
}

// ── HTTP（用 Node 内置 fetch，不依赖 undici）──────────────────────────
async function httpGet(url, { binary = false, maxBytes = 8 * 1024 * 1024, timeout = 15000 } = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      redirect: 'follow',
      headers: { 'user-agent': `qq-agent/${SELF_ID}` }
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const len = Number(res.headers.get('content-length') || 0);
    if (len && len > maxBytes) throw new Error(`包超过 ${Math.round(maxBytes / 1024 / 1024)}MB`);
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length > maxBytes) throw new Error(`包超过 ${Math.round(maxBytes / 1024 / 1024)}MB`);
    return binary ? buf : buf.toString('utf8');
  } finally {
    clearTimeout(timer);
  }
}

export async function activate(ctx) {
  const log = (...a) => ctx.log('[auto-update]', ...a);
  const pluginsDir = path.resolve(ctx.dir, '..');
  const dataDir = ctx.dataDir || path.join(pluginsDir, '..', 'data');
  const backupRoot = path.join(dataDir, 'plugin-backup');

  // 读配置：默认值垫底 + 存盘值覆盖。
  // 关键：存盘里若是「空字符串 / 0 这类空值」，不能让它覆盖掉 DEFAULTS 的正确默认值——
  // 之前出现过「别人机器上 config 里 source 被存成空串，浅合并后默认源被空串顶掉，
  // 结果报『没有配置分发源』、自己这台能用别人用不了」。空字符串当「没填」处理。
  const cfg = () => {
    const raw = ctx.config.get() || {};
    const out = { ...DEFAULTS };
    for (const [k, v] of Object.entries(raw)) {
      if (v === '' || v === null || v === undefined) continue;  // 空值不覆盖默认
      out[k] = v;
    }
    return out;
  };
  const st = () => ({
    lastCheckAt: 0, lastResult: 'never', lastError: '', source: '',
    pending: [], applied: [], mode: 'self',
    ...(ctx.state.all() || {})
  });
  const save = (patch) => {
    for (const [k, v] of Object.entries(patch || {})) {
      try { ctx.state.set(k, v); } catch { /* 落盘失败不影响更新本身 */ }
    }
  };

  // ── 本机地址识别：源指向自己时改走 127.0.0.1，别绕公网撞登录框 ──────
  function consolePort() {
    try {
      const c = JSON.parse(fs.readFileSync(path.join(dataDir, 'config.json'), 'utf8'));
      return Number(c?.server?.port) || 3210;
    } catch {
      return 3210;
    }
  }

  function selfNames() {
    const set = new Set(['127.0.0.1', 'localhost', '0.0.0.0', '::1', os.hostname()]);
    try {
      for (const list of Object.values(os.networkInterfaces() || {})) {
        for (const ni of list || []) if (ni?.address) set.add(ni.address);
      }
    } catch { /* 忽略 */ }
    return set;
  }

  /** 一个源可能有两个候选：原样 + 本机回环（后者只在原样失败时才试）。 */
  function candidatesOf(base) {
    const list = [base];
    // 回环地址本身就是"本机"，不用换端口 —— 用户可能在本机起了个静态目录
    // （比如 http://127.0.0.1:8080/dist），一律改成控制台端口会把它改坏。
    const LOOPBACK = new Set(['127.0.0.1', 'localhost', '0.0.0.0', '::1']);
    try {
      const u = new URL(base);
      if (selfNames().has(u.hostname)) {
        const local = new URL(base);
        local.protocol = 'http:';
        local.hostname = '127.0.0.1';
        // 只有"公网地址/主机名"才换成控制台端口（那个端口在外面被 nginx 挡着登录框）
        if (!LOOPBACK.has(u.hostname)) local.port = String(consolePort());
        const s = local.toString().replace(/\/+$/, '');
        if (s !== base) list.push(s);
      }
    } catch { /* 非法 URL 交给下面的 fetch 报错 */ }
    return list;
  }

  function sourcesOf(c) {
    // source 为空时回退到内置默认源：宁可连官方源，也别让插件报「没有配置分发源」停摆。
    const raw = String(c.source || '').trim();
    const text = raw || DEFAULTS.source;
    return String(text)
      .split(/[\n,]+/).map((s) => s.trim().replace(/\/+$/, '')).filter(Boolean);
  }

  /**
   * 更新名单。空 = 一个都不更新（不解释成"全部"，那太危险）。
   * 本插件自身永远在名单里：否则以后想修这个更新器，就只能让人手动上传一次，
   * 等于把"以后不用管"这件事又还回去了。
   */
  function onlySetOf(c) {
    const set = new Set(String(c.only || '')
      .split(/[\n,]+/).map((s) => s.trim()).filter(Boolean));
    set.add(SELF_ID);
    return set;
  }

  // ── 内核是否已内置自动更新（补丁版）；有则让位 ──────────────────────
  let probe = { at: 0, ok: false };
  async function kernelHasUpdater() {
    if (Date.now() - probe.at < 5 * 60 * 1000) return probe.ok;
    let ok = false;
    try {
      const r = await fetch(`http://127.0.0.1:${consolePort()}/api/plugins/updates`, {
        signal: AbortSignal.timeout(1500)
      });
      if (r.ok) {
        const j = await r.json();
        // 端点存在 ≠ 它在干活：内核更新器可能被配置关掉了，那就该由本插件接手
        ok = !!j && ('lastCheckAt' in j || 'pending' in j) && j.enabled !== false;
      }
    } catch { ok = false; }
    probe = { at: Date.now(), ok };
    return ok;
  }

  async function modeNow() {
    const c = cfg();
    if (c.preferSelf) return 'self';
    return (await kernelHasUpdater()) ? 'standby' : 'self';
  }

  /**
   * 待命状态下把活转交给内核更新器（补丁版）。
   * 为什么不在待命时自己干：两个更新器同时覆盖同一个目录会打架 —— 一个刚把目录
   * 改名备份，另一个正好在写文件，插件就残了。宁可只让一个动手。
   */
  async function kernelCall(pathname) {
    const res = await fetch(`http://127.0.0.1:${consolePort()}${pathname}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: '{}',
      signal: AbortSignal.timeout(120000)
    });
    if (!res.ok) throw new Error(`内核更新器 HTTP ${res.status}`);
    return res.json();
  }

  /** 已装插件的 { id: version }（直接扫盘：停用的插件也算「已装」） */
  function localVersions() {
    const out = {};
    let names = [];
    try {
      names = fs.readdirSync(pluginsDir, { withFileTypes: true })
        .filter((d) => d.isDirectory() && !d.name.startsWith('.'))
        .map((d) => d.name);
    } catch {
      return out;
    }
    for (const name of names) {
      try {
        const mf = JSON.parse(fs.readFileSync(path.join(pluginsDir, name, 'manifest.json'), 'utf8'));
        if (mf?.version) out[String(mf.id || name)] = String(mf.version);
      } catch { /* 没 manifest / 坏了 → 视为未装 */ }
    }
    return out;
  }

  async function fetchManifest(sources) {
    const errors = [];
    for (const base of sources) {
      for (const b of candidatesOf(base)) {
        try {
          const text = await httpGet(`${b}/manifest.json?t=${Date.now()}`, {
            maxBytes: 2 * 1024 * 1024, timeout: 8000
          });
          const data = JSON.parse(text);
          if (!data || typeof data !== 'object' || !data.plugins) {
            throw new Error('manifest 缺少 plugins 字段');
          }
          return { base: b, manifest: data };
        } catch (error) {
          errors.push(`${b}: ${error?.message ?? error}`);
        }
      }
    }
    throw new Error(`所有更新源都不可用（${errors.join('；')}）`);
  }

  // ── 检查 ────────────────────────────────────────────────────────────
  let running = false;

  async function check({ manual = false } = {}) {
    const c = cfg();
    if (!c.enabled) return { ok: false, error: '自动更新已关闭', disabled: true };
    if (running) return { ok: false, error: '正在检查中，请稍候' };

    // 待命：把检查交给内核更新器，自己只抄一份结果回来给面板看
    if ((await modeNow()) === 'standby') {
      try {
        const j = await kernelCall('/api/plugins/updates/check');
        save({
          lastCheckAt: Date.now(), lastResult: j.ok === false ? 'error' : 'ok',
          lastError: j.ok === false ? String(j.error || '') : '',
          source: j.source || st().source || '',
          pending: j.pending || [], mode: 'standby'
        });
        return { ok: j.ok !== false, delegated: true, pending: j.pending || [], applied: j.applied || j.appliedAll || [] };
      } catch (error) {
        // 内核那边不可用（比如被禁用一半）→ 落回自己干
        log('转交内核更新器失败，改由本插件执行:', error?.message ?? error);
      }
    }

    running = true;
    try {
      const sources = sourcesOf(c);
      if (!sources.length) throw new Error('没有配置分发源');
      const { base, manifest } = await fetchManifest(sources);
      const local = localVersions();
      const only = onlySetOf(c);
      const pending = [];
      const unknown = [];
      const ignored = [];          // 有新版，但不在更新名单里

      for (const [id, info] of Object.entries(manifest.plugins || {})) {
        const remote = String(info?.version || '');
        if (!remote || !info?.file) continue;
        const cur = local[id];

        // 🔴 名单之外一律不碰。连"记录下来待确认"都不做 —— 免得有人看到列表就手滑点掉。
        if (!only.has(id)) {
          if (cur !== undefined && compareVersion(remote, cur) > 0) ignored.push(id);
          continue;
        }

        if (cur === undefined) {
          // 名单 = 订阅：名单里有、本机没有，就是新机器上"该装但还没装"的插件。
          // 默认直接补装，省得每台新机器都要人工再传一遍。
          if (c.installMissing !== false) {
            pending.push({ id, from: '', to: remote, file: info.file, sha256: info.sha256 || '', note: info.note || '', isNew: true });
          } else {
            unknown.push(id);
          }
          continue;
        }
        if (compareVersion(remote, cur) > 0) {
          pending.push({
            id, from: cur, to: remote,
            file: info.file, sha256: info.sha256 || '', note: info.note || ''
          });
        }
      }

      save({
        lastCheckAt: Date.now(), lastResult: 'ok', lastError: '',
        source: base, pending, unknown, ignored, mode: await modeNow()
      });

      if (pending.length) {
        log(`发现 ${pending.length} 个待处理：${pending.map((p) => `${p.id} ${p.from || '未装'}→${p.to}`).join('，')}`);
      } else if (manual) {
        log(`没有待更新的插件（名单 ${only.size} 个，本机已装 ${Object.keys(local).length} 个）`);
      }

      let applied = [];
      if (pending.length && c.autoApply) applied = await applyPending(base, pending);
      return { ok: true, pending, applied, source: base, checked: Object.keys(local).length };
    } catch (error) {
      const msg = String(error?.message ?? error);
      save({ lastCheckAt: Date.now(), lastResult: 'error', lastError: msg });
      log('检查失败:', msg);
      return { ok: false, error: msg };
    } finally {
      running = false;
    }
  }

  // ── 安装 ────────────────────────────────────────────────────────────

  /** 覆盖前把旧目录整体挪走（放 data/plugin-backup，不留在 plugins/ 里污染扫描） */
  function backupPlugin(id) {
    const src = path.join(pluginsDir, id);
    if (!fs.existsSync(src)) return null;
    const dst = path.join(backupRoot, `${id}-${Date.now()}`);
    try {
      fs.mkdirSync(backupRoot, { recursive: true });
      fs.renameSync(src, dst);
      return dst;
    } catch (error) {
      log(`${id} 备份失败:`, error?.message ?? error);
      return null;
    }
  }

  function restoreDeps(id, backupPath) {
    if (!backupPath) return;
    const target = path.join(pluginsDir, id);
    for (const name of KEEP_ON_REPLACE) {
      const from = path.join(backupPath, name);
      if (!fs.existsSync(from)) continue;
      try {
        fs.cpSync(from, path.join(target, name), { recursive: true, force: true });
      } catch (error) {
        log(`${id} 依赖目录 ${name} 迁移失败:`, error?.message ?? error);
      }
    }
  }

  async function rollback(id, backupPath, reason, wasEnabled = true) {
    try {
      fs.rmSync(path.join(pluginsDir, id), { recursive: true, force: true });
      if (backupPath) fs.renameSync(backupPath, path.join(pluginsDir, id));
      const host = ctx.pluginHost;
      try { host?.records?.delete?.(id); } catch { /* 忽略 */ }
      await host?.reload?.(id);
      // 原本停用的，回滚后也该保持停用（别因为我们动过一次就把它悄悄打开）
      if (!wasEnabled) {
        try {
          await host?.disable?.(id);
          host?.records?.get?.(id)?.config?.set({ enabled: false });
        } catch { /* 忽略 */ }
      }
      log(`${id} 更新失败，已回滚（${reason}）`);
    } catch (error) {
      log(`${id} 回滚失败，备份在 ${backupPath}:`, error?.message ?? error);
    }
  }

  async function installOne(base, item) {
    const id = item.id;
    const host = ctx.pluginHost;
    if (!host) throw new Error('拿不到插件宿主（内核版本过旧？）');

    const fileUrl = `${base}/${String(item.file).replace(/^\/+/, '')}`;
    const buf = await httpGet(fileUrl, { binary: true, maxBytes: MAX_PACKAGE_BYTES, timeout: 60000 });
    if (item.sha256 && sha256(buf) !== String(item.sha256).toLowerCase()) {
      throw new Error('sha256 校验失败（包可能损坏或被替换）');
    }

    let entries;
    try {
      entries = tarRead(zlib.gunzipSync(buf));
    } catch (error) {
      throw new Error(`解包失败：${error?.message ?? error}`);
    }
    if (!entries.length) throw new Error('包里没有文件');
    // 包内布局容错（1.0.10）：别人的源不一定是 <id>/manifest.json 这种规范结构，
    // tar czf x.tgz * 出来是平铺（manifest.json 在根），Windows 压缩工具还带 ./ 前缀。
    // 以前这里直接取「第一个条目第一段」当根目录，平铺包就永远报「包里没有 manifest.json」。
    const files = entries
      .map(([n, b]) => [String(n).replace(/^\.\//, ''), b])
      .filter(([n]) => n && !n.startsWith('__MACOSX/') && !/(^|\/)\.DS_Store$/.test(n));
    const mfCandidates = files.filter(([n]) => {
      const segs = n.split('/');
      return segs[segs.length - 1] === 'manifest.json' && segs.length <= 3;
    });
    if (!mfCandidates.length) throw new Error('包里没有 manifest.json');
    const mfEntry = mfCandidates.find(([n]) => {
      const dir = n.slice(0, n.length - 'manifest.json'.length);
      return files.some(([m]) => m === `${dir}index.js`);
    }) || mfCandidates[0];
    // 根目录，带结尾斜杠；平铺时为空串
    const rootName = mfEntry[0].slice(0, mfEntry[0].length - 'manifest.json'.length);

    let pkgManifest;
    try {
      pkgManifest = JSON.parse(mfEntry[1].toString('utf8'));
    } catch (error) {
      throw new Error(`包内 manifest 解析失败：${error?.message ?? error}`);
    }
    // 防呆：包里的 id / 版本必须和清单对得上，避免把 A 的包写进 B 的目录
    if (String(pkgManifest.id || '') !== id) {
      throw new Error(`包内 id（${pkgManifest.id || '空'}）与清单（${id}）不一致`);
    }
    if (item.to && compareVersion(pkgManifest.version, item.to) !== 0) {
      throw new Error(`包内版本（${pkgManifest.version}）与清单（${item.to}）不一致`);
    }

    const wasEnabled = host.records?.get(id)?.status === 'enabled';
    const isSelf = id === SELF_ID;

    // 先停用：旧代码还在跑的时候把目录换掉，行为不可预期
    if (!isSelf) {
      try { await host.disable(id); } catch { /* 未装载过也无所谓 */ }
    }

    // 🔴 关键一步：把内存里的记录**删掉**，逼 reload 从磁盘重读 manifest。
    //    内核的 host.reload(id) 优先复用 records 里的旧 manifest 对象 —— 目录里
    //    的版本已经换成新版了，内存里还是 `1.0.0`，重载完版本号纹丝不动，
    //    /api/plugins 显示的还是旧版本（这也是「改 manifest 必须重启」那个老毛病）。
    //    记录一删，reload 就退回 #readManifest(磁盘) 那条路，装的才是新 manifest。
    //    自身更新时先不删：要留着记录，稍后 disable 才能走到本插件的 dispose 清定时器。
    if (!isSelf) {
      try { host.records?.delete(id); } catch { /* 删不掉就退回旧路 */ }
    }

    const backup = backupPlugin(id);
    const targetDir = path.join(pluginsDir, id);
    // 干净包里带的是 manifest 默认值（"刚装上"的状态）。本机若已有 config.json，
    // 一律以本机为准 —— 自动更新绝不能顺手把人家的配置改回默认。
    const keepLocalConfig = !!backup && fs.existsSync(path.join(backup, 'config.json'));
    try {
      fs.mkdirSync(targetDir, { recursive: true });
      for (const [name, data] of files) {
        const rel = name.slice(rootName.length);
        if (!rel || rel.includes('..') || path.isAbsolute(rel)) continue;
        if (rel === 'config.json' && keepLocalConfig) continue;
        const dest = path.join(targetDir, rel);
        if (!dest.startsWith(targetDir)) continue;
        fs.mkdirSync(path.dirname(dest), { recursive: true });
        fs.writeFileSync(dest, data);
      }
      if (keepLocalConfig) {
        try { fs.copyFileSync(path.join(backup, 'config.json'), path.join(targetDir, 'config.json')); } catch { /* 忽略 */ }
      }
      restoreDeps(id, backup);
    } catch (error) {
      await rollback(id, backup, String(error?.message ?? error), wasEnabled);
      throw error;
    }

    // 自己更新自己：当前实例马上会被 reload 掉，不能 await 它的结果。
    // 顺序有讲究：先 disable（走到本插件的 dispose，清掉定时器）→ 删记录（让 reload
    // 从磁盘读新 manifest）→ reload。少了「删记录」这一步，重载后版本号还是旧的。
    if (isSelf) {
      log(`自身已升级到 ${item.to}，即将重载`);
      setTimeout(async () => {
        try { await host.disable(SELF_ID); } catch { /* 忽略 */ }
        try { host.records?.delete(SELF_ID); } catch { /* 忽略 */ }
        try {
          await host.reload(SELF_ID);
        } catch (error) {
          log('自身重载失败（重启后生效）:', error?.message ?? error);
        }
      }, 400);
      if (backup) setTimeout(() => { try { fs.rmSync(backup, { recursive: true, force: true }); } catch { /* 忽略 */ } }, 5000);
      return { id, from: item.from, to: item.to, ok: true, self: true };
    }

    let result;
    try {
      result = await host.reload(id);
    } catch (error) {
      result = { ok: false, error: String(error?.message ?? error) };
    }

    const rec = host.records?.get(id);
    const nowVersion = String(rec?.manifest?.version || '');
    const loadedOk = result?.ok !== false && rec?.status === 'enabled'
      && compareVersion(nowVersion, item.to) >= 0;
    if (!loadedOk) {
      await rollback(id, backup, result?.error || `重载后版本 ${nowVersion || '未知'}（${rec?.lastError || rec?.status || '未装载'}）`, wasEnabled);
      throw new Error(result?.error || `重载后版本不符（${nowVersion || '未知'}）`);
    }

    if (backup) {
      try { fs.rmSync(backup, { recursive: true, force: true }); } catch { /* 忽略 */ }
    }

    // 原本停用的，更新后不该偷偷启起来
    if (!wasEnabled && !item.isNew) {
      try {
        await host.disable(id);
        rec?.config?.set({ enabled: false });
      } catch { /* 忽略 */ }
    }

    log(`${id} 已更新 ${item.from || '（新装）'} → ${item.to}`);
    return { id, from: item.from, to: item.to, ok: true };
  }

  async function applyPending(base, pending) {
    const applied = [];
    for (const item of pending) {
      try {
        applied.push(await installOne(base, item));
      } catch (error) {
        applied.push({ id: item.id, from: item.from, to: item.to, ok: false, error: String(error?.message ?? error) });
        log(`${item.id} 更新失败:`, error?.message ?? error);
      }
    }
    const okCount = applied.filter((a) => a.ok).length;
    const prev = st();
    save({
      applied: [...applied.map((a) => ({ ...a, at: Date.now() })), ...(prev.applied || [])].slice(0, 30),
      pending: applied.filter((a) => !a.ok).map((a) => pending.find((p) => p.id === a.id)).filter(Boolean),
      lastResult: okCount === applied.length ? 'ok' : 'partial'
    });
    return applied;
  }

  // ── 对外：面板 / 手动触发 ───────────────────────────────────────────

  async function snapshot() {
    const c = cfg();
    const s = st();
    // 只信 probe 的实时结论：state 里的 mode 只是上次的快照，拿它当依据会一直显示
    // 上一次的「待命」（内核更新器被关掉后还赖着不动）。probe 有 5 分钟缓存，
    // 但首次调用必出网一次 —— 127.0.0.1 的回环请求，几毫秒的事。
    const mode = await modeNow();
    return {
      enabled: c.enabled,
      autoApply: c.autoApply,
      installNew: c.installNew,
      installMissing: c.installMissing !== false,
      preferSelf: c.preferSelf,
      intervalMinutes: Number(c.intervalMinutes) || 0,
      // source = 面板上填的那个（改完立刻能看到）；lastSource = 上次实际用上的地址
      source: sourcesOf(c)[0] || '',
      lastSource: s.source || '',
      sources: sourcesOf(c),
      // 名单外的插件永远不出现在 pending 里，只在这个提示里露个名字，
      // 好让人知道"不是没查出来，是我不管它"
      only: [...onlySetOf(c)].filter((x) => x !== SELF_ID),
      onlyText: String(c.only || ''),
      ignored: (s.ignored || []).slice(0, 20),
      // 名单里、本机还没装，且「自动补装」被关掉时才会出现在这里
      unknown: (s.unknown || []).slice(0, 20),
      mode,
      kernelUpdater: probe.ok,
      running,
      lastCheckAt: s.lastCheckAt || 0,
      lastResult: s.lastResult || 'never',
      lastError: s.lastError || '',
      pending: (s.pending || []).map((p) => ({ id: p.id, from: p.from, to: p.to, note: p.note || '' })),
      recentApplied: (s.applied || []).slice(0, 20).map((a) => ({
        id: a.id, from: a.from, to: a.to, ok: a.ok !== false, error: a.error || '', at: a.at || 0
      })),
      installed: Object.keys(localVersions()).length,
      selfVersion: ctx.version
    };
  }

  ctx.http.route('GET', '/status', () => snapshot());

  ctx.http.route('POST', '/check', async () => {
    probe.at = 0;                                   // 手动检查时重新判断一次谁干活
    const r = await check({ manual: true });
    return { ...r, status: await snapshot() };
  });

  ctx.http.route('POST', '/apply', async () => {
    // 待命：交给内核更新器动手（两边同时覆盖同一目录会打架）
    if ((await modeNow()) === 'standby') {
      try {
        const j = await kernelCall('/api/plugins/updates/apply');
        return { ...j, delegated: true, status: await snapshot() };
      } catch (error) {
        log('转交内核更新器失败，改由本插件执行:', error?.message ?? error);
      }
    }
    const s = st();
    const pending = (s.pending || []).filter((p) => p && p.file);
    if (!pending.length) {
      const r = await check({ manual: true });
      if (!r.ok) return r;
      return { ok: true, applied: r.applied || [], pending: r.pending || [], status: await snapshot() };
    }
    if (running) return { ok: false, error: '正在更新中' };
    running = true;
    try {
      const applied = await applyPending(s.source || sourcesOf(cfg())[0], pending);
      return { ok: true, applied, status: await snapshot() };
    } finally {
      running = false;
    }
  });

  ctx.http.route('POST', '/config', async (_req, body) => {
    const patch = {};
    const b = body || {};
    if ('enabled' in b) patch.enabled = b.enabled === true;
    if ('autoApply' in b) patch.autoApply = b.autoApply === true;
    if ('installNew' in b) patch.installNew = b.installNew === true;
    if ('installMissing' in b) patch.installMissing = b.installMissing === true;
    if ('preferSelf' in b) patch.preferSelf = b.preferSelf === true;
    if ('source' in b) {
      // 空 source 直接删键（回落 DEFAULTS.source），别再存一个空串进 config 顶掉默认值
      const src = String(b.source || '').trim();
      patch.source = src || null;
    }
    if ('only' in b) {
      // 规范化：一行一个 id，去掉空行与重复，非法字符直接丢（id 只允许小写字母数字连字符）
      const ids = String(b.only || '')
        .split(/[\n,]+/).map((s) => s.trim()).filter((s) => /^[a-z0-9][a-z0-9-]*$/.test(s));
      patch.only = [...new Set(ids)].join('\n');
    }
    if ('intervalMinutes' in b) patch.intervalMinutes = Math.max(0, Math.min(1440, Number(b.intervalMinutes) || 0));
    ctx.config.set(patch);
    probe.at = 0;
    schedule();
    return { ok: true, status: await snapshot() };
  });

  // ── 定时：每分钟醒一次，按间隔决定要不要真查 ────────────────────────
  let timer = null;
  function schedule() {
    if (timer) { timer(); timer = null; }
    // 用内核的 scheduler.every：dispose 时会被自动 clearInterval，不留悬挂定时器
    timer = ctx.scheduler.every(60 * 1000, () => { tick().catch(() => {}); });
  }

  let lastRunAt = 0;
  /**
   * @param {{force?: boolean}} [opts] force=true 是开机那一次：不受「间隔」约束。
   *   否则重启后如果距上次检查还不到 30 分钟，就会被节流挡掉，等于开机不查。
   */
  async function tick(opts) {
    const force = opts?.force === true;
    const c = cfg();
    if (!c.enabled || running) return;
    const intervalMs = (Number(c.intervalMinutes) || 0) * 60 * 1000;
    const last = st().lastCheckAt || 0;
    if (force) {
      if (last && Date.now() - last < 2 * 60 * 1000) return;  // 2 分钟内查过就不重复（防反复重启打爆源）
      if (Date.now() - lastRunAt < 60 * 1000) return;
    } else {
      if (intervalMs <= 0) return;                       // 0 = 只在启动时查一次
      if (Date.now() - last < intervalMs) return;
      if (Date.now() - lastRunAt < 60 * 1000) return;    // 失败也别一分钟内反复重试
    }
    lastRunAt = Date.now();
    if ((await modeNow()) === 'standby') {
      save({ mode: 'standby' });
      return;                                            // 内核在管，不抢活
    }
    save({ mode: 'self' });
    await check();
  }

  schedule();
  // 启动后 20 秒先查一次：开机即更新，不用等第一个 30 分钟窗口。
  // 这一次用 force，绕开「距上次不足间隔就跳过」，否则重启后可能干等半小时。
  const bootTimer = setTimeout(() => { tick({ force: true }).catch(() => {}); }, 20 * 1000);
  if (typeof bootTimer.unref === 'function') bootTimer.unref();

  log(`已就绪（间隔 ${cfg().intervalMinutes} 分钟，自动安装 ${cfg().autoApply ? '开' : '关'}）`);

  return {
    async dispose() {
      if (timer) { timer(); timer = null; }
      clearTimeout(bootTimer);
    }
  };
}
