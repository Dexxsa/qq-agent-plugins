// ══════════════════════════════════════════════════════════════
//  update-agent · 面板：一眼看清「谁在管更新、上次什么时候查、都升了什么」
// ══════════════════════════════════════════════════════════════
//
//  两点设计：
//  ① 先说清**谁在干活**。内核补丁版内置了更新器时本插件会待命，这一条不写明白，
//     用户会以为插件坏了（"怎么一直是待命"）。
//  ② 更新记录要留最近几条。自动更新最容易出的误会是"到底升了没有"，
//     有时间戳的记录比一句"已是最新"更可信。

const RESULT_TEXT = { never: '还没查过', ok: '正常', partial: '部分失败', error: '失败' };
const RESULT_TONE = { never: 'wait', ok: 'on', partial: 'wait', error: 'off' };

function fmtTime(ts) {
  if (!ts) return '—';
  try { return new Date(Number(ts)).toLocaleString('zh-CN', { hour12: false }); } catch { return '—'; }
}

const badge = (tone, text) => `<span class="badge badge-${tone}">${text}</span>`;

export async function mount(root, ctx) {
  return render(root, ctx, { page: true });
}

export async function mountPanel(root, ctx) {
  return render(root, ctx, { page: false });
}

async function render(root, ctx, { page }) {
  const { api, esc, toast } = ctx;

  // 页面骨架：只放一个容器，内容统一由 paint() 填，避免"按钮被重绘冲掉"
  if (page) {
    root.innerHTML = `<div class="card" style="padding:18px 20px">
      <div class="row" style="align-items:center;gap:8px">
        <h3 style="margin:0">自动更新</h3>
        <span style="flex:1"></span>
        <span id="au-tip" class="muted" style="font-size:12px"></span>
      </div>
      <p class="muted" style="font-size:13px;margin:6px 0 0">
        插件自更新：下载 → 校验 sha256 → 备份 → 覆盖 → 热重载，失败自动回滚。
      </p>
      <div id="au-body"><p class="muted" style="font-size:13px;margin-top:12px">读取状态…</p></div>
    </div>`;
  } else {
    root.innerHTML = ctx.panelShell('update-agent', '自动更新', '<div id="au-body"><p class="muted">读取状态…</p></div>');
    ctx.bindPanelClose?.(root);
  }

  const body = () => root.querySelector('#au-body') || root;

  function toolbarHtml(s) {
    const standby = s?.mode === 'standby';
    return `<div class="row" style="gap:8px;margin:12px 0 0;flex-wrap:wrap">
      <button class="btn primary" id="au-check">立即检查</button>
      <button class="btn" id="au-apply-now">立即更新</button>
      ${standby ? '<span class="muted" style="font-size:12px">本机由内核更新器负责，这里的手动检查会转交给它</span>' : ''}
    </div>`;
  }

  function statusHtml(s) {
    if (!s) return '<p class="muted" style="font-size:13px">状态读不到（插件可能刚装载，刷新页面再试）</p>';
    const standby = s.mode === 'standby';
    const modeLine = standby
      ? `${badge('wait', '待命')} 本机内核已内置自动更新，由它负责；本插件不抢同一个目录。`
      : `${badge('on', '自运行')} 由本插件负责下载、校验、覆盖、热重载。`;

    const pendingRows = (s.pending || []).map((p) => `
      <div class="row" style="gap:8px;font-size:13px;padding:3px 0;flex-wrap:wrap">
        <code>${esc(p.id)}</code>
        <span class="muted">${esc(p.from || '未装')} → <b>${esc(p.to)}</b></span>
        ${p.note ? `<span class="muted" style="font-size:12px">${esc(p.note)}</span>` : ''}
      </div>`).join('');

    const appliedRows = (s.recentApplied || []).map((a) => `
      <div class="row" style="gap:8px;font-size:12.5px;padding:2px 0;flex-wrap:wrap">
        ${badge(a.ok ? 'on' : 'off', a.ok ? '完成' : '失败')}
        <code>${esc(a.id)}</code>
        <span class="muted">${esc(a.from || '未装')} → ${esc(a.to)}</span>
        <span class="muted" style="font-size:11.5px">${esc(fmtTime(a.at))}</span>
        ${a.error ? `<span style="font-size:11.5px;color:#c33">${esc(a.error)}</span>` : ''}
      </div>`).join('');

    return `
      <div style="margin-top:10px;padding:9px 12px;border-radius:8px;background:rgba(127,127,127,.09);font-size:13px">
        ${modeLine}
      </div>
      <div class="row" style="gap:14px;margin-top:10px;flex-wrap:wrap;align-items:center;font-size:13px">
        <span>上次检查：<b>${esc(fmtTime(s.lastCheckAt))}</b></span>
        <span>结果：${badge(RESULT_TONE[s.lastResult] || 'wait', RESULT_TEXT[s.lastResult] || s.lastResult)}</span>
        <span class="muted">更新范围 ${(s.only || []).length} 个</span>
        <span class="muted">间隔 ${esc(s.intervalMinutes)} 分钟</span>
        <span class="muted">自动装 ${s.autoApply ? '开' : '关'}</span>
      </div>
      ${s.lastError ? `<p style="font-size:12px;margin:6px 0 0;color:#c33">最近错误：${esc(s.lastError)}</p>` : ''}
      <p class="muted" style="font-size:12px;margin:6px 0 0">更新源：<code>${esc(s.source || '—')}</code></p>

      <div style="margin-top:14px">
        <b style="font-size:13px">待更新</b>
        ${pendingRows || '<p class="muted" style="font-size:12.5px;margin:4px 0 0">没有待更新的插件。</p>'}
        ${(s.ignored || []).length
          ? `<p class="muted" style="font-size:12px;margin:6px 0 0">
              另有 ${s.ignored.length} 个插件有新版，但不在更新名单里，未处理：<code>${esc(s.ignored.join(', '))}</code>
             </p>`
          : ''}
        ${(s.unknown || []).length
          ? `<p class="muted" style="font-size:12px;margin:6px 0 0">
              名单里还有 ${s.unknown.length} 个插件本机没装：<code>${esc(s.unknown.join(', '))}</code>
              —— 勾上「名单里没装的也自动装上」就会补装。
             </p>`
          : ''}
      </div>
      <div style="margin-top:12px">
        <b style="font-size:13px">最近更新</b>
        ${appliedRows || '<p class="muted" style="font-size:12.5px;margin:4px 0 0">这段时间还没有更新记录。</p>'}
      </div>`;
  }

  function settingsHtml(s) {
    if (!s) return '';
    return `<div style="margin-top:16px;padding-top:14px;border-top:1px solid rgba(128,128,128,.18)">
      <b style="font-size:13px">设置</b>
      <div class="row" style="gap:14px;margin-top:8px;flex-wrap:wrap;align-items:center;font-size:13px">
        <label style="display:inline-flex;gap:6px;align-items:center">
          <input type="checkbox" id="au-on" ${s.enabled ? 'checked' : ''}> 启用自动更新</label>
        <label style="display:inline-flex;gap:6px;align-items:center">
          <input type="checkbox" id="au-apply" ${s.autoApply ? 'checked' : ''}> 发现新版自动安装</label>
        <label style="display:inline-flex;gap:6px;align-items:center">
          <input type="checkbox" id="au-missing" ${s.installMissing ? 'checked' : ''}> 名单里没装的也自动装上</label>
        <label style="display:inline-flex;gap:6px;align-items:center">
          <input type="checkbox" id="au-prefer" ${s.preferSelf ? 'checked' : ''}> 本插件强制接管</label>
        <label style="display:inline-flex;gap:6px;align-items:center">
          间隔 <input id="au-min" type="number" min="0" max="1440" value="${esc(s.intervalMinutes)}" style="width:70px"> 分钟</label>
      </div>
      <div class="field" style="margin-top:10px">
        <label style="font-size:13px"><b>更新源</b>
          <span class="muted" style="font-size:12px">一行一个，按顺序回退；指向本机时会自动改走 127.0.0.1</span></label>
        <textarea id="au-src" rows="2" style="width:100%;font-family:ui-monospace,monospace;font-size:12px">${esc((s.sources || []).join('\n'))}</textarea>
      </div>
      <div class="field" style="margin-top:10px">
        <label style="font-size:13px"><b>更新名单</b>
          <span class="muted" style="font-size:12px">一行一个插件 id；不在名单里的插件即使有新版也不动（本插件自身始终可更新）</span></label>
        <textarea id="au-only" rows="3" style="width:100%;font-family:ui-monospace,monospace;font-size:12px">${esc((s.only || []).join('\n'))}</textarea>
      </div>
      <div class="row" style="gap:8px;margin-top:10px"><button class="btn primary" id="au-save">保存设置</button></div>
    </div>`;
  }

  function bind() {
    const on = (sel, ev, fn) => { const el = root.querySelector(sel); if (el) el.addEventListener(ev, fn); };
    const tip = (t) => { const el = root.querySelector('#au-tip'); if (el) el.textContent = t; };

    on('#au-check', 'click', async (e) => {
      e.preventDefault();
      tip('正在检查…');
      try {
        const r = await api('/api/plugins/update-agent/check', { method: 'POST', body: {} });
        if (r.ok === false) toast?.(r.error || '检查失败');
        else if ((r.applied || []).length) toast?.(`已更新 ${r.applied.filter((a) => a.ok).length} 个插件`);
        else if ((r.pending || []).length) toast?.(`发现 ${r.pending.length} 个可更新`);
        else toast?.('已是最新');
      } catch (err) {
        toast?.('检查失败：' + err.message);
      }
      tip('');
      await paint();
    });

    on('#au-apply-now', 'click', async (e) => {
      e.preventDefault();
      tip('正在更新…');
      try {
        const r = await api('/api/plugins/update-agent/apply', { method: 'POST', body: {} });
        if (r.ok === false) toast?.(r.error || '更新失败');
        else toast?.(`已处理 ${(r.applied || []).filter((a) => a.ok).length} 个插件`);
      } catch (err) {
        toast?.('更新失败：' + err.message);
      }
      tip('');
      await paint();
    });

    on('#au-save', 'click', async (e) => {
      e.preventDefault();
      try {
        await api('/api/plugins/update-agent/config', {
          method: 'POST',
          body: {
            enabled: root.querySelector('#au-on')?.checked === true,
            autoApply: root.querySelector('#au-apply')?.checked === true,
            installMissing: root.querySelector('#au-missing')?.checked === true,
            preferSelf: root.querySelector('#au-prefer')?.checked === true,
            intervalMinutes: Number(root.querySelector('#au-min')?.value || 30),
            source: root.querySelector('#au-src')?.value || '',
            only: root.querySelector('#au-only')?.value || ''
          }
        });
        toast?.('已保存');
      } catch (err) {
        toast?.('保存失败：' + err.message);
      }
      await paint();
    });
  }

  async function paint() {
    let s = null;
    try {
      s = await api('/api/plugins/update-agent/status');
    } catch (e) {
      toast?.('读取状态失败：' + e.message);
    }
    body().innerHTML = toolbarHtml(s) + statusHtml(s) + settingsHtml(s);
    bind();
  }

  await paint();
}
