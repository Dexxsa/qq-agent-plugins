// ══════════════════════════════════════════════════════════════
//  daily-news · 面板
// ══════════════════════════════════════════════════════════════
//
//  一块面板回答四个问题：
//    ① 下次什么时候推、推到哪？（状态行 + 目标列表）
//    ② 抓到的新闻长什么样？（「预览」直接把当轮消息原样贴出来）
//    ③ 通道通不通？（「立即推送」真发一轮，结果逐目标列出）
//    ④ 之前推没推成？（历史，含抓取/发送失败原因）

export async function mountPanel(box, ctx) {
  const { $, api, esc, toast, panelShell, bindPanelClose, savePluginConfig } = ctx;

  let data = null;
  const load = async () => {
    try {
      const r = await api('/api/plugins/daily-news/status');
      if (r && r.ok !== false) data = r;
    } catch (e) {
      toast('读取状态失败：' + e.message);
    }
    return data;
  };

  await load();
  const c = data?.config || {};
  const s = data?.state || {};
  const fmt = (ts) => (ts ? new Date(ts).toLocaleString('zh-CN', { hour12: false }) : '—');
  const allSources = data?.sources || [
    { id: '60s', label: '每天60秒读懂世界', emoji: '📰' },
    { id: 'weibo', label: '微博热搜', emoji: '🔥' },
    { id: 'zhihu', label: '知乎热榜', emoji: '💡' },
    { id: 'toutiao', label: '头条热榜', emoji: '📺' }
  ];
  const chosen = Array.isArray(c.sources) ? c.sources : ['60s'];

  box.innerHTML = panelShell('daily-news', '每日新闻', `
    <p class="muted" style="font-size:13px;margin:0">
      每天定点把热点新闻推进群/私聊。默认源是「每天60秒读懂世界」（15 条要闻 + 小贴士），
      可以再勾选微博/知乎/头条榜单；勾「AI 糅合」会把所有源合成一段早报（走内核模型，不占额外密钥）。
      错过时刻 <b>${esc(c.catchUpMin ?? 30)} 分钟内自动补推</b>；对话里问「今天有什么新闻」模型也能现场抓。
    </p>

    <div style="margin-top:14px;padding:12px;border-radius:8px;background:rgba(128,128,128,.08)">
      <div class="row" style="align-items:center;gap:10px;flex-wrap:wrap">
        <span style="font-size:13px">状态：
          ${c.enabled === false
            ? '<span style="color:#d9534f;font-weight:600">已停用</span>'
            : `<span style="color:#4a9d5f;font-weight:600">运行中</span>`}
        </span>
        <span class="muted" style="font-size:12px" id="dn-next">${c.enabled === false ? '—' : `下次推送：${esc(data?.nextPushAt || '—')}`}</span>
        <span class="muted" style="font-size:12px">今天已推：${esc((s.pushedToday || []).join('、') || '还没有')}</span>
        <span class="spacer" style="flex:1"></span>
        <button class="btn tiny" id="dn-preview">预览内容</button>
        <button class="btn tiny" id="dn-push">立即推送</button>
      </div>
      <div class="muted" style="font-size:12px;margin-top:8px" id="dn-tip">
        累计推送 ${Number(s.pushes) || 0} 轮 · 抓取失败 ${Number(s.fetchFailures) || 0} 次 · 最后推送：${esc(fmt(s.lastPushAt))}
        ${s.lastError ? `· 最近错误：${esc(String(s.lastError).slice(0, 120))}` : ''}
      </div>
    </div>

    <div class="field" style="margin-top:14px">
      <label>推送目标 <span class="muted" style="font-size:12px">每行一个：群填 group:群号，私聊填 private:QQ号</span></label>
      <textarea id="dn-targets" rows="3" style="width:100%;font-family:monospace" placeholder="group:1127063335&#10;private:3198685728">${esc((c.targets || []).join('\n'))}</textarea>
    </div>

    <div class="row" style="gap:12px;margin-top:10px;flex-wrap:wrap;align-items:flex-end">
      <div class="field" style="margin:0">
        <label>推送时刻 <span class="muted" style="font-size:12px">逗号分隔，可多个</span></label>
        <input id="dn-times" style="width:150px" value="${esc((c.pushTimes || ['08:00']).join(', '))}">
      </div>
      <div class="field" style="margin:0">
        <label>错过补推（分钟）</label>
        <input id="dn-catchup" style="width:90px" value="${esc(c.catchUpMin ?? 30)}">
      </div>
      <div class="field" style="margin:0">
        <label>每源条数</label>
        <input id="dn-max" style="width:70px" value="${esc(c.maxPerSource ?? 8)}">
      </div>
      <div class="field" style="margin:0">
        <label>目标间隔（毫秒）</label>
        <input id="dn-gap" style="width:90px" value="${esc(c.targetGapMs ?? 2000)}">
      </div>
    </div>

    <div class="row" style="gap:14px;margin-top:12px;flex-wrap:wrap;align-items:center">
      <b style="font-size:13px">订阅来源：</b>
      ${allSources.map((src) => `
        <label style="font-size:13px;display:inline-flex;gap:5px;align-items:center">
          <input type="checkbox" class="dn-src" value="${esc(src.id)}" ${chosen.includes(src.id) ? 'checked' : ''}>
          ${esc(src.emoji)} ${esc(src.label)}
        </label>`).join('')}
    </div>

    <div class="row" style="gap:14px;margin-top:10px;flex-wrap:wrap;align-items:center">
      <label class="muted" style="font-size:12px;display:inline-flex;gap:6px;align-items:center">
        <input type="checkbox" id="dn-llm" ${c.llmDigest === true ? 'checked' : ''}> AI 糅合成一段早报（失败自动退回拼接）
      </label>
      <label class="muted" style="font-size:12px;display:inline-flex;gap:6px;align-items:center">
        <input type="checkbox" id="dn-enabled" ${c.enabled !== false ? 'checked' : ''}> 启用定时推送
      </label>
    </div>
    <div class="field" style="margin-top:8px">
      <label>早报风格 <span class="muted" style="font-size:12px">仅 AI 糅合时生效</span></label>
      <input id="dn-style" style="width:100%" value="${esc(c.llmStyle || '')}" placeholder="简明早报，口吻轻松，正文 300 字以内，保留关键数字">
    </div>

    <div class="row" style="gap:8px;margin-top:14px;align-items:center">
      <button class="btn" id="dn-save">保存配置</button>
      <button class="btn tiny" id="dn-refresh">刷新状态</button>
      <span class="muted" style="font-size:12px" id="dn-save-tip"></span>
    </div>

    <div id="dn-preview-box" style="display:none;margin-top:14px;padding-top:12px;border-top:1px solid rgba(128,128,128,.18)">
      <b style="font-size:13px">预览（当前会推送的消息原文）</b>
      <div id="dn-preview-body" class="muted" style="font-size:12px;margin-top:6px"></div>
    </div>

    <div style="margin-top:16px;padding-top:14px;border-top:1px solid rgba(128,128,128,.18)">
      <div class="row" style="align-items:center;gap:8px">
        <b style="font-size:13px">推送记录</b>
        <span class="spacer" style="flex:1"></span>
        <button class="btn tiny" id="dn-clear">清空</button>
      </div>
      <div id="dn-history" style="margin-top:8px"></div>
    </div>
  `);

  bindPanelClose(box);

  // ── 历史 ───────────────────────────────────────────────────
  const renderHistory = () => {
    const el = $('#dn-history');
    if (!el) return;
    const list = Array.isArray(data?.history) ? data.history : [];
    if (!list.length) {
      el.innerHTML = '<div class="muted" style="font-size:12px">还没有记录。点「预览」能先看内容，点「立即推送」真发一轮。</div>';
      return;
    }
    el.innerHTML = list.slice(0, 12).map((x) => `
      <div style="font-size:12px;line-height:1.7">
        <span class="muted">${esc(fmt(x.ts))}</span>
        · <b>${esc(x.kind === 'scheduled' ? '定时' : x.kind === 'manual' ? '手动' : x.kind || '推送')}</b>
        · <span style="color:${x.ok ? '#4a9d5f' : '#d9534f'}">${x.ok ? '成功' : '失败'}</span>
        ${x.detail ? `<span class="muted">· ${esc(String(x.detail).slice(0, 160))}</span>` : ''}
      </div>`).join('');
  };

  const refresh = async () => {
    await load();
    const st = data?.state || {};
    const cfgNow = data?.config || {};
    const tip = $('#dn-tip');
    if (tip) {
      tip.textContent = `累计推送 ${st.pushes || 0} 轮 · 抓取失败 ${st.fetchFailures || 0} 次 · 最后推送：${fmt(st.lastPushAt)}`
        + (st.lastError ? ` · 最近错误：${String(st.lastError).slice(0, 120)}` : '');
    }
    const next = $('#dn-next');
    if (next) next.textContent = cfgNow.enabled === false ? '—' : `下次推送：${data?.nextPushAt || '—'}`;
    renderHistory();
  };

  // ── 事件 ───────────────────────────────────────────────────
  $('#dn-preview')?.addEventListener('click', async () => {
    const btn = $('#dn-preview');
    const wrap = $('#dn-preview-box');
    const body = $('#dn-preview-body');
    btn.disabled = true;
    btn.textContent = '抓取中…';
    try {
      const r = await api('/api/plugins/daily-news/preview');
      wrap.style.display = 'block';
      if (r?.ok) {
        body.innerHTML = r.messages.map((m) => `<pre style="white-space:pre-wrap;font-size:12px;margin:6px 0;padding:8px;border-radius:6px;background:rgba(128,128,128,.1);color:#ddd">${esc(m)}</pre>`).join('')
          + (r.errors?.length ? `<div style="color:#d9534f;font-size:12px">${esc(r.errors.join('；'))}</div>` : '');
      } else {
        body.innerHTML = `<span style="color:#d9534f">抓取失败：${esc(r?.error || '未知原因')}</span>`;
      }
    } catch (e) {
      wrap.style.display = 'block';
      body.innerHTML = `<span style="color:#d9534f">抓取失败：${esc(e.message)}</span>`;
    } finally {
      btn.disabled = false;
      btn.textContent = '预览内容';
    }
  });

  $('#dn-push')?.addEventListener('click', async () => {
    const btn = $('#dn-push');
    btn.disabled = true;
    btn.textContent = '推送中…';
    try {
      const r = await api('/api/plugins/daily-news/push', { method: 'POST', body: {} });
      if (r?.ok) {
        toast('已推送给全部目标');
      } else {
        const fails = (r?.results || []).filter((x) => !x.ok).map((x) => `${x.chatKey}：${x.error}`).join('；');
        toast('有失败目标：' + (fails || r?.error || '未知原因').slice(0, 200));
      }
      await refresh();
    } catch (e) {
      toast('推送失败：' + e.message);
      await refresh();
    } finally {
      btn.disabled = false;
      btn.textContent = '立即推送';
    }
  });

  $('#dn-clear')?.addEventListener('click', async () => {
    try {
      await api('/api/plugins/daily-news/clear', { method: 'POST', body: {} });
      await refresh();
    } catch (e) {
      toast('清空失败：' + e.message);
    }
  });

  $('#dn-refresh')?.addEventListener('click', refresh);

  $('#dn-save')?.addEventListener('click', async () => {
    const tip = $('#dn-save-tip');
    const num = (sel, dflt, min, max) => {
      const v = Number($(sel)?.value);
      if (!Number.isFinite(v)) return dflt;
      return Math.min(max, Math.max(min, v));
    };
    const patch = {
      enabled: Boolean($('#dn-enabled')?.checked),
      targets: ($('#dn-targets')?.value || '').split('\n').map((s) => s.trim()).filter(Boolean),
      pushTimes: ($('#dn-times')?.value || '').split(',').map((s) => s.trim()).filter(Boolean),
      catchUpMin: num('#dn-catchup', 30, 0, 720),
      maxPerSource: num('#dn-max', 8, 3, 20),
      targetGapMs: num('#dn-gap', 2000, 500, 60000),
      sources: Array.from(document.querySelectorAll('.dn-src:checked')).map((el) => el.value),
      llmDigest: Boolean($('#dn-llm')?.checked),
      llmStyle: ($('#dn-style')?.value || '').trim()
    };
    if (!patch.sources.length) {
      toast('至少勾一个来源');
      return;
    }
    if (!patch.pushTimes.length) {
      toast('至少填一个推送时刻（HH:MM）');
      return;
    }
    try {
      await savePluginConfig('daily-news', patch);
      tip.textContent = '已保存，下一轮判定（20 秒内）生效。';
      toast('已保存');
      await refresh();
    } catch (e) {
      tip.textContent = '保存失败：' + e.message;
      toast('保存失败：' + e.message);
    }
  });

  renderHistory();
}
