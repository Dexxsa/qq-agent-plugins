// ══════════════════════════════════════════════════════════════
//  daily-news · 每日热点新闻推送
// ══════════════════════════════════════════════════════════════
//
//  行为约定：
//    ① 到点推送：pushTimes 里每个 HH:MM 各推一轮，按「日期+时刻」去重，
//       一天内同一时刻绝不重发；错过时刻 catchUpMin 分钟内会补推
//       （机器人重启/掉线刚好跨过 08:00 的场景）；
//    ② 多来源自动降级：主域 60s.viki.moe 拿不到就换镜像 60s-api.viki.moe，
//       单个源失败不影响其它源；全部失败才算这轮失败，下一 tick 重试（最多 3 次）；
//    ③ 发送走内核 SendQueue（ctx.sender.sendTextBatch），自带真人化间隔
//       和限频；多个目标之间再垫 targetGapMs，避免同一秒戳所有群；
//    ④ llmDigest 开着时把所有源糅成一段早报（走 ctx.chatCompletion，
//       不碰密钥）；模型失败/超时自动退回纯拼接，推送不因此中断；
//    ⑤ 顺手注册 fetch_hot_news 工具：对话里「今天有什么新闻」模型可现场抓。
import fs from 'node:fs';

// 60s API 家族：同一套接口两个域，主域挂了换镜像
const API_HOSTS = ['https://60s.viki.moe', 'https://60s-api.viki.moe'];

// 订阅源定义：id → { label, emoji, path }
//   60s    → 每天60秒读懂世界（人工精选 15 条 + 小贴士，每日一更）
//   weibo  → 微博热搜（分钟级）
//   zhihu  → 知乎热榜
//   toutiao→ 头条热榜
const SOURCES = {
  '60s': { label: '每天60秒读懂世界', emoji: '📰', path: '/v2/60s' },
  weibo: { label: '微博热搜', emoji: '🔥', path: '/v2/weibo' },
  zhihu: { label: '知乎热榜', emoji: '💡', path: '/v2/zhihu' },
  toutiao: { label: '头条热榜', emoji: '📺', path: '/v2/toutiao' }
};

const MAX_HISTORY = 40;
const MAX_RETRY_PER_ROUND = 3;

function nowText(ts = Date.now()) {
  return new Date(ts).toLocaleString('zh-CN', { hour12: false });
}

/** 本地日期 YYYY-MM-DD（推送去重按天算，用服务器本地时区） */
function dateKey(d = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/** 当前 HH:MM */
function hhmm(d = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getHours())}:${p(d.getMinutes())}`;
}

/** 校验用户填的时刻串：08:00 / 8:5 → 08:00；不合法返回 null */
function normTime(s) {
  const m = String(s || '').trim().match(/^(\d{1,2}):(\d{1,2})$/);
  if (!m) return null;
  const h = Number(m[1]);
  const min = Number(m[2]);
  if (h > 23 || min > 59) return null;
  return `${String(h).padStart(2, '0')}:${String(min).padStart(2, '0')}`;
}

/** now 相对 t（HH:MM）过去了几分钟；t 在未来返回负数 */
function minutesSince(t, now = new Date()) {
  const [h, m] = t.split(':').map(Number);
  const target = new Date(now);
  target.setHours(h, m, 0, 0);
  return (now - target) / 60000;
}

/** 热度数值转人类可读：1137174 → 113.7万 */
function fmtHot(v) {
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0) return '';
  if (n >= 10000) return `${(n / 10000).toFixed(1).replace(/\.0$/, '')}万`;
  return String(n);
}

// ── 抓取 ───────────────────────────────────────────────────────

/** 带域名降级的 GET JSON：一个域名超时/非 200 才换下一个 */
async function fetchJson(pathname, timeoutMs = 12000) {
  let lastErr = '';
  for (const base of API_HOSTS) {
    try {
      const res = await fetch(base + pathname, {
        headers: { 'accept': 'application/json' },
        signal: AbortSignal.timeout(timeoutMs)
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const j = await res.json();
      if (j && j.code === 200 && j.data != null) return j.data;
      throw new Error(j?.message ? String(j.message).slice(0, 80) : '接口返回为空');
    } catch (e) {
      lastErr = String(e?.message ?? e);
    }
  }
  throw new Error(lastErr || '所有域名都不可达');
}

/**
 * 抓一个源，归一化成 { id, label, emoji, date?, tip?, items: [{title, hot, url}] }。
 * 单源失败抛错，由调用方决定跳过还是整轮重试。
 */
async function fetchSource(id) {
  const def = SOURCES[id];
  if (!def) throw new Error(`未知来源：${id}`);
  const data = await fetchJson(def.path);

  if (id === '60s') {
    const news = Array.isArray(data.news) ? data.news : [];
    if (!news.length) throw new Error('60s 接口今日没有新闻');
    return {
      id,
      label: def.label,
      emoji: def.emoji,
      date: String(data.date || ''),
      week: String(data.day_of_week || ''),
      lunar: String(data.lunar_date || ''),
      tip: String(data.tip || ''),
      items: news.map((s) => ({ title: String(s || '').trim(), hot: '', url: '' })).filter((x) => x.title)
    };
  }

  const list = Array.isArray(data) ? data : [];
  if (!list.length) throw new Error(`${def.label}接口返回为空`);
  return {
    id,
    label: def.label,
    emoji: def.emoji,
    items: list.map((x) => ({
      title: String(x?.title || '').trim(),
      hot: fmtHot(x?.hot_value),
      url: String(x?.link || x?.url || '')
    })).filter((x) => x.title)
  };
}

// ── 渲染 ───────────────────────────────────────────────────────

/** 一个源 → 一条消息（纯文本，QQ 气泡友好；发的时候 SendQueue 还会做清洗切分） */
function renderSource(brief, maxItems) {
  const items = brief.items.slice(0, maxItems);
  const lines = [];
  if (brief.id === '60s') {
    const head = [brief.date, brief.week, brief.lunar].filter(Boolean).join(' ');
    lines.push(`📰 今日要闻 · 每天60秒读懂世界${head ? `（${head}）` : ''}`);
    items.forEach((it, i) => lines.push(`${i + 1}. ${it.title}`));
    if (brief.tip) lines.push(``, `💡 小贴士：${brief.tip}`);
  } else {
    lines.push(`${brief.emoji} ${brief.label} Top ${items.length}`);
    items.forEach((it, i) => lines.push(`${i + 1}. ${it.title}${it.hot ? `（${it.hot}）` : ''}`));
  }
  return lines.join('\n');
}

/** 全部源 → 待发消息数组（一个源一条气泡） */
function renderAll(briefs, maxItems) {
  return briefs.map((b) => renderSource(b, maxItems));
}

/** 把多源糅成一段早报（走内核模型通道）。失败抛错，调用方退回纯拼接。 */
async function llmDigest(ctx, briefs, maxItems, style) {
  const material = briefs.map((b) => {
    const items = b.items.slice(0, maxItems).map((it) => it.title + (it.hot ? `（热度${it.hot}）` : '')).join('\n');
    return `【${b.label}】\n${items}`;
  }).join('\n\n');

  const out = await ctx.chatCompletion({
    messages: [
      {
        role: 'system',
        content: `你是一名早报编辑。把用户给的多路热点素材糅成一条适合发在 QQ 群的早报：${style}。直接输出早报正文，不要任何前言、标题符号或解释；分条时用「1. 2.」编号；不同来源的内容可以合并同类项，去重明显重复的条目；文末单独一行以「——」开头附一句来源汇总（如「—— 以上来自 每天60秒读懂世界 / 微博热搜」）。`
      },
      { role: 'user', content: material }
    ],
    signal: AbortSignal.timeout(45000)
  });
  const text = String(out?.message?.content || '').trim();
  if (!text) throw new Error('模型返回了空正文');
  return text;
}

// ── 插件主体 ───────────────────────────────────────────────────

// 源级缓存：同一轮里工具/预览/推送常接连触发，不必反复打接口；
// 抓取失败时拿 30 分钟内的陈旧缓存兜底（60s 是日更内容，热榜晚几分钟无伤大雅），
// 两个都没有才真正报错。
const CACHE_TTL = 10 * 60000;
const STALE_OK = 30 * 60000;

export async function activate(ctx) {
  const log = (...a) => { try { ctx.log(...a); } catch { /* 日志失败不影响推送 */ } };
  const cache = new Map();   // sourceId → { at, brief }

  const getSource = async (id) => {
    const hit = cache.get(id);
    if (hit && Date.now() - hit.at < CACHE_TTL) return hit.brief;
    try {
      const brief = await fetchSource(id);
      cache.set(id, { at: Date.now(), brief });
      return brief;
    } catch (e) {
      if (hit && Date.now() - hit.at < STALE_OK) {
        log(`${SOURCES[id]?.label || id} 抓取失败，用 ${Math.round((Date.now() - hit.at) / 60000)} 分钟前的缓存顶上`);
        return hit.brief;
      }
      throw e;
    }
  };

  const readCfg = () => {
    const c = ctx.config.get() || {};
    const times = (Array.isArray(c.pushTimes) ? c.pushTimes : [c.pushTimes])
      .map((t) => normTime(t)).filter(Boolean);
    const sources = (Array.isArray(c.sources) ? c.sources : [c.sources])
      .map((s) => String(s || '').trim()).filter((s) => SOURCES[s]);
    return {
      enabled: c.enabled !== false,
      pushTimes: times.length ? Array.from(new Set(times)).sort() : ['08:00'],
      catchUpMin: Math.max(0, Number(c.catchUpMin) ?? 30),
      targets: (Array.isArray(c.targets) ? c.targets : [])
        .map((t) => String(t || '').trim()).filter(Boolean),
      sources: sources.length ? Array.from(new Set(sources)) : ['60s'],
      maxPerSource: Math.min(20, Math.max(3, Number(c.maxPerSource) || 8)),
      llmDigest: c.llmDigest === true,
      llmStyle: String(c.llmStyle || '').trim() || '简明早报，口吻轻松，正文 300 字以内，保留关键数字',
      targetGapMs: Math.min(60000, Math.max(500, Number(c.targetGapMs) || 2000))
    };
  };

  // ── 状态（落盘） ─────────────────────────────────────────────
  const state = {
    pushes: 0,            // 成功轮数（至少一个目标发出）
    fetchFailures: 0,     // 整轮抓取失败次数
    lastPushAt: 0,
    lastError: '',
    pushed: {}            // "2026-10-24": ["08:00"] 已推过的日期+时刻
  };
  let history = [];

  const stateFile = ctx.data.file('state.json');
  try {
    const saved = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
    if (saved && typeof saved === 'object') {
      for (const k of ['pushes', 'fetchFailures', 'lastPushAt', 'lastError']) {
        if (saved[k] !== undefined) state[k] = saved[k];
      }
      if (saved.pushed && typeof saved.pushed === 'object') state.pushed = saved.pushed;
      if (Array.isArray(saved.history)) history = saved.history.slice(0, MAX_HISTORY);
    }
  } catch { /* 首次运行没有存档 */ }

  const persist = () => {
    try {
      // pushed 只留最近 7 天，防无限膨胀
      const weekAgo = Date.now() - 7 * 86400000;
      for (const day of Object.keys(state.pushed)) {
        if (new Date(day + 'T00:00:00').getTime() < weekAgo) delete state.pushed[day];
      }
      fs.writeFileSync(stateFile, JSON.stringify({
        pushes: state.pushes,
        fetchFailures: state.fetchFailures,
        lastPushAt: state.lastPushAt,
        lastError: state.lastError,
        pushed: state.pushed,
        history
      }, null, 1));
    } catch (e) {
      log('状态落盘失败：', e?.message ?? e);
    }
  };

  const note = (entry) => {
    history.unshift({ ts: Date.now(), ...entry });
    if (history.length > MAX_HISTORY) history.length = MAX_HISTORY;
    persist();
  };

  /** 算今天还没推、且在补推窗口内的时刻 */
  const dueTimes = (cfg) => {
    const today = dateKey();
    const done = state.pushed[today] || [];
    const now = new Date();
    return cfg.pushTimes.filter((t) => {
      const passed = minutesSince(t, now);
      return !done.includes(t) && passed >= 0 && passed <= cfg.catchUpMin;
    });
  };

  /** 算面板展示用的「下次推送时刻」（今天下一个未过的时刻，否则明天第一个） */
  const nextPushAt = (cfg) => {
    const now = new Date();
    for (const t of cfg.pushTimes) {
      if (minutesSince(t, now) < 0) return `${dateKey(now)} ${t}`;
    }
    const tomorrow = new Date(now.getTime() + 86400000);
    return `${dateKey(tomorrow)} ${cfg.pushTimes[0] || '08:00'}`;
  };

  // ── 抓取 + 组装一轮消息 ─────────────────────────────────────
  let building = false;
  const buildMessages = async (cfg, opts = {}) => {
    // 传了来源但全都不认识（如模型代传了 baidu）→ 回退订阅源，别整轮失败
    let ids = Array.isArray(opts.sources) ? opts.sources.filter((s) => SOURCES[s]) : [];
    if (!ids.length) ids = cfg.sources;
    const briefs = [];
    const errors = [];
    for (const id of ids) {
      try {
        briefs.push(await getSource(id));
      } catch (e) {
        errors.push(`${SOURCES[id]?.label || id}：${String(e?.message ?? e).slice(0, 120)}`);
      }
    }
    if (!briefs.length) throw new Error(errors.join('；') || '没有任何可用来源');

    let messages;
    if (cfg.llmDigest && briefs.length > 0) {
      try {
        messages = [await llmDigest(ctx, briefs, cfg.maxPerSource, cfg.llmStyle)];
      } catch (e) {
        log('AI 糅合失败，退回纯拼接：', e?.message ?? e);
        errors.push(`AI 糅合失败已退回拼接（${String(e?.message ?? e).slice(0, 80)}）`);
        messages = renderAll(briefs, cfg.maxPerSource);
      }
    } else {
      messages = renderAll(briefs, cfg.maxPerSource);
    }
    return { messages, briefs, errors };
  };

  // ── 推送一轮 ────────────────────────────────────────────────
  const pushRound = async (opts = {}) => {
    const cfg = readCfg();
    const targets = (Array.isArray(opts.targets) && opts.targets.length)
      ? opts.targets.map((t) => String(t).trim()).filter(Boolean)
      : cfg.targets;
    if (!targets.length) {
      const reason = '未配置推送目标（面板里填 group:群号 / private:QQ号）';
      note({ kind: opts.kind || 'push', ok: false, detail: reason });
      return { ok: false, error: reason };
    }

    let built;
    try {
      built = await buildMessages(cfg, opts);
    } catch (e) {
      state.fetchFailures += 1;
      state.lastError = String(e?.message ?? e);
      note({ kind: opts.kind || 'push', ok: false, detail: '抓取失败：' + state.lastError.slice(0, 180) });
      persist();
      throw Object.assign(new Error(state.lastError), { fetchFailed: true });
    }

    const results = [];
    let anyOk = false;
    for (let i = 0; i < targets.length; i++) {
      const chatKey = targets[i];
      // 先在本层校验格式，别让裸数字（少了 group:/private: 前缀）只换来一句「非法会话 key」
      if (!/^(group|private):\d+$/.test(chatKey)) {
        results.push({ chatKey, ok: false, error: '目标格式不对：要 group:群号 或 private:QQ号（注意冒号是英文的）' });
        continue;
      }
      if (i > 0) await new Promise((r) => setTimeout(r, cfg.targetGapMs));
      try {
        const r = await ctx.sender.sendTextBatch(chatKey, built.messages, {});
        anyOk = true;
        results.push({ chatKey, ok: true, bubbles: r?.sent?.length ?? built.messages.length });
      } catch (e) {
        results.push({ chatKey, ok: false, error: String(e?.message ?? e).slice(0, 160) });
      }
    }

    if (anyOk) {
      state.pushes += 1;
      state.lastPushAt = Date.now();
      state.lastError = '';
    } else {
      state.lastError = results.map((r) => r.error).filter(Boolean).join('；');
    }
    note({
      kind: opts.kind || 'push',
      ok: anyOk,
      detail: `${targets.length} 个目标，来源 ${built.briefs.map((b) => b.label).join('/')}`
        + (built.errors.length ? `；${built.errors.join('；').slice(0, 120)}` : '')
        + (!anyOk && state.lastError ? `；发送失败：${state.lastError.slice(0, 120)}` : '')
    });
    persist();
    return { ok: anyOk, error: anyOk ? '' : (state.lastError || '全部目标发送失败，见 results'), results, briefs: built.briefs };
  };

  // ── 定时循环：每 20 秒看一眼是否到点 ────────────────────────
  const retryCount = {};   // "2026-10-24 08:00" → 已重试次数（仅内存）
  const stopTimer = ctx.scheduler.every(20000, async () => {
    const cfg = readCfg();
    if (!cfg.enabled) return;
    if (!cfg.targets.length) return;   // 没配目标就不推，也不标记（配好即可补推）
    if (building) return;
    for (const t of dueTimes(cfg)) {
      const key = `${dateKey()} ${t}`;
      if ((retryCount[key] || 0) >= MAX_RETRY_PER_ROUND) continue;
      building = true;
      let r = null;
      let err = '';
      try {
        r = await pushRound({ kind: 'scheduled' });
      } catch (e) {
        err = String(e?.message ?? e);   // 抓取整轮失败
      } finally {
        building = false;
      }
      // 抓取和发送都成功（至少一个目标发出）才标记完成，否则吃掉重试额度再试
      if (r?.ok) {
        state.pushed[dateKey()] = Array.from(new Set([...(state.pushed[dateKey()] || []), t]));
        persist();
        delete retryCount[key];
        log(`已推送 ${key}`);
      } else {
        retryCount[key] = (retryCount[key] || 0) + 1;
        log(`推送失败（${key}，第 ${retryCount[key]}/${MAX_RETRY_PER_ROUND} 次）：${err || '发送失败见历史'}`);
      }
    }
  });

  // ── 工具：模型在对话里随时抓热点 ────────────────────────────
  ctx.tools.register({
    name: 'fetch_hot_news',
    description: '抓取当前热点新闻榜单。sources 可选：60s=每天60秒读懂世界（每日要闻，最适合作早报）、weibo=微博热搜、zhihu=知乎热榜、toutiao=头条热榜；不传则用插件订阅源。limit 为每个来源的条数（默认 8，最大 20）。',
    parameters: {
      type: 'object',
      properties: {
        sources: {
          type: 'array',
          items: { type: 'string', enum: Object.keys(SOURCES) },
          description: '要抓的来源列表'
        },
        limit: { type: 'number', description: '每个来源最多几条' }
      },
      required: []
    },
    execute: async (args = {}) => {
      const cfg = readCfg();
      const limit = Math.min(20, Math.max(3, Number(args.limit) || cfg.maxPerSource));
      try {
        const built = await buildMessages(cfg, { sources: args.sources });
        const texts = built.briefs.map((b) => renderSource(b, limit));
        return {
          ok: true,
          text: texts.join('\n\n'),
          sources: built.briefs.map((b) => ({ id: b.id, label: b.label, count: Math.min(b.items.length, limit) })),
          errors: built.errors
        };
      } catch (e) {
        return { ok: false, error: String(e?.message ?? e) };
      }
    }
  });

  // ── HTTP 接口（面板后端） ────────────────────────────────────
  ctx.http.route('GET', '/status', async () => {
    const cfg = readCfg();
    return {
      ok: true,
      state: {
        pushes: state.pushes,
        fetchFailures: state.fetchFailures,
        lastPushAt: state.lastPushAt,
        lastError: state.lastError,
        pushedToday: state.pushed[dateKey()] || []
      },
      config: cfg,
      sources: Object.entries(SOURCES).map(([id, s]) => ({ id, label: s.label, emoji: s.emoji })),
      nextPushAt: cfg.enabled ? nextPushAt(cfg) : '',
      history
    };
  });

  // 预览：只抓取渲染，不发送（面板「预览」按钮 / ?sources=60s,weibo）
  ctx.http.route('GET', '/preview', async (req, body, url) => {
    const cfg = readCfg();
    const wanted = String(url?.searchParams?.get('sources') || '')
      .split(',').map((s) => s.trim()).filter(Boolean);
    try {
      const built = await buildMessages(cfg, { sources: wanted });
      return { ok: true, messages: built.messages, errors: built.errors };
    } catch (e) {
      return { ok: false, error: String(e?.message ?? e) };
    }
  });

  // 手动推送：默认发配置里的目标；body.targets 可临时覆盖
  ctx.http.route('POST', '/push', async (req, body = {}) => {
    try {
      const r = await pushRound({ kind: 'manual', targets: body.targets });
      return { ok: r.ok, error: r.error || '', results: r.results };
    } catch (e) {
      return { ok: false, error: String(e?.message ?? e) };
    }
  });

  ctx.http.route('POST', '/clear', async () => {
    history = [];
    persist();
    return { ok: true };
  });

  log(`已启用：每天 ${readCfg().pushTimes.join('、')} 推送 ${readCfg().sources.map((s) => SOURCES[s].label).join('、')}`);

  return {
    dispose() {
      stopTimer?.();
    }
  };
}
